# -*- coding: utf-8 -*-
"""三方方案对比图（问题2）：总费用对比 / z 敏感性 / 计划购电量 vs 实际需求。"""
import sys, os, io, json, re
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'code'))
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from common_q2 import load_all, DT, FIG_DIR, RES_DIR

_CAND = ['Microsoft YaHei', 'SimHei', 'Noto Sans CJK SC']
_avail = {f.name for f in font_manager.fontManager.ttflist}
if any(c in _avail for c in _CAND):
    plt.rcParams['font.sans-serif'] = [next(c for c in _CAND if c in _avail)]
plt.rcParams['axes.unicode_minus'] = False
plt.rcParams['font.size'] = 11
plt.rcParams['axes.grid'] = True
plt.rcParams['grid.alpha'] = 0.3


def _save(fig, name):
    for ext in ('png', 'pdf'):
        fig.savefig(os.path.join(FIG_DIR, '%s.%s' % (name, ext)), dpi=300, bbox_inches='tight')
    plt.close(fig)
    print('figure ->', name)


# ---- 数据 ----
with open(os.path.join(RES_DIR, 'q2_summary_global.json'), encoding='utf-8') as f:
    mine = json.load(f)
my_cost = mine['total_cost_yuan']

GEM_ORIG_COST = 16117108.40          # Gemini 原始（修复后）
GEM_MA7_COST = 15885974.0            # Gemini 第一代改进（ma7 预测 + z=0.71）
GEM_BEST_COST = 14043614.65          # Gemini 最优改进（lag-7 预测 + z=0.45）

# ---- 图 A：三方案总费用对比 ----
fig, ax = plt.subplots(figsize=(9.2, 4.3))
labels = ['本文方案\n(完全信息·全局优化)', 'Gemini 最优\n(lag-7 预测)', 'Gemini 第一代\n(滑动均值预测)', 'Gemini 原始\n(修复后)']
vals = [my_cost, GEM_BEST_COST, GEM_MA7_COST, GEM_ORIG_COST]
colors = ['#2980b9', '#27ae60', '#e67e22', '#95a5a6']
bars = ax.bar(range(4), vals, width=0.6, color=colors)
for b, v in zip(bars, vals):
    ax.annotate('%.1f 万元' % (v / 1e4), (b.get_x() + b.get_width() / 2, v),
                textcoords='offset points', xytext=(0, 4), ha='center', fontsize=9)
ax.axhline(my_cost, color='#2980b9', ls='--', lw=1.1)
ax.annotate('信息价值 ≈ %.0f 万元（%.1f%%）'
            % ((GEM_BEST_COST - my_cost) / 1e4, (GEM_BEST_COST - my_cost) / GEM_BEST_COST * 100),
            xy=(0.55, (my_cost + GEM_ORIG_COST) / 2), fontsize=9.5, color='#c0392b')
ax.annotate('预测器改进\n省 %.0f 万元' % ((GEM_ORIG_COST - GEM_BEST_COST) / 1e4),
            xy=(1.5, 1.72e7), fontsize=9, color='#1e8449', ha='center')
ax.set_xticks(range(4)); ax.set_xticklabels(labels, fontsize=9)
ax.set_ylabel('保存期购电总费用 (元)')
ax.set_ylim(0, max(vals) * 1.2)
ax.set_title('图A  问题2 各方案购电总费用对比（2025.2.1–12.31，334 天）')
_save(fig, 'cmpA_cost')

# ---- 图 B：z 敏感性 ----
zs, qs, costs, em = [], [], [], []
p = os.path.join(RES_DIR, 'q2_gemini_lag7.txt')
if os.path.exists(p):
    for line in io.open(p, encoding='utf-8'):
        m = re.match(r'\s*([\d.]+)\s+(\d+)\s+(\d+)\s+(\d+)', line)
        if m:
            zs.append(float(m.group(1))); qs.append('')
            costs.append(float(m.group(4))); em.append(float(m.group(3)))
if zs:
    fig, ax = plt.subplots(figsize=(8.8, 4.3))
    ax.plot(zs, [c / 1e4 for c in costs], 'o-', color='#27ae60', lw=1.8, label='购电总费用（lag-7 预测器）')
    bz = zs[int(np.argmin(costs))]
    ax.plot([bz], [min(costs) / 1e4], '*', color='#c0392b', ms=16,
            label='实测最优 z = %.2f' % bz)
    ax.axhline(15885974 / 1e4, color='#e67e22', ls='--', lw=1.4,
               label='第一代（滑动均值预测）15 886 万元'.replace('15 886', '1 588.6'))
    ax.axhline(12227244 / 1e4, color='#2980b9', ls=':', lw=1.4, label='完全信息下界 1 222.7 万元')
    ax.set_xlabel('保守分位数系数 $z$')
    ax.set_ylabel('购电总费用 (万元)')
    ax.legend(fontsize=8.5)
    ax2 = ax.twinx()
    ax2.plot(zs, em, 's--', color='#8e44ad', lw=1.3, label='紧急购电量')
    ax2.set_ylabel('全年紧急购电量 (kWh)', color='#8e44ad')
    ax2.tick_params(axis='y', colors='#8e44ad'); ax2.grid(False)
    ax2.legend(fontsize=9, loc='center right')
    ax.set_title('图B  lag-7 预测器下 z 的敏感性（预测器改进带来主要增益）')
    _save(fig, 'cmpB_z')

# ---- 图 C：计划购电量 vs 实际需求 ----
price, dates, load, pv = load_all()
actual_need = (load[31:].sum() - pv[31:].sum()) * DT          # 净负荷总量（不含储能损耗/弃光）
my_buy = mine['total_plan_buy_kWh']
fig, ax = plt.subplots(figsize=(8.2, 4.0))
names = ['实际净需求\n(负荷−光伏)', '本文方案\n(全局优化)', 'Gemini 最优\n(lag-7)', 'Gemini 原始\n(修复后)']
vals = [actual_need, my_buy, 21437121.38, 25225812.06]
colors = ['#7f8c8d', '#2980b9', '#27ae60', '#95a5a6']
bars = ax.bar(range(4), vals, width=0.6, color=colors)
for b, v in zip(bars, vals):
    ax.annotate('%.0f 万 kWh' % (v / 1e4), (b.get_x() + b.get_width() / 2, v),
                textcoords='offset points', xytext=(0, 4), ha='center', fontsize=9)
ax.set_xticks(range(4)); ax.set_xticklabels(names, fontsize=9)
ax.set_ylabel('计划购电量 (kWh)')
ax.set_ylim(0, max(vals) * 1.18)
ax.annotate('Gemini 原始多买约 %.0f 万 kWh\n（预测残差大 → 保守裕度过量）'
            % ((25225812.06 - actual_need) / 1e4), xy=(2.5, 2.62e7),
            fontsize=9, color='#c0392b', ha='center')
ax.set_title('图C  计划购电量与实际净需求对比')
_save(fig, 'cmpC_planbuy')
print('compare figures done')
