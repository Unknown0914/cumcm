# -*- coding: utf-8 -*-
"""
q2_gemini_v2.py —— Gemini 路线的第二代改进：「场景化两阶段随机规划」

与第一代改进（q2_gemini_improved.py，用"分位数法"粗略权衡）的区别：

  第一代（分位数法）：
      日前  min Σ c(t)·E_plan(t)
            s.t. E_plan + E_dis − E_ch ≥ fc_net·Δt  （fc_net = 净负荷的 z 分位预测）
      第二代（场景法，本文件）：
      日前  min Σ c(t)·E_plan(t) + (1/|Ω|) Σ_{ω∈Ω} [日内场景 ω 的最优成本]
            s.t. 对每个场景 ω：
                    G_ω − C_ω + D_ω − CU_ω = load_ω·Δt − pv_ω·Δt
                    S_ω(t) = S_ω(t−1) + η_c·C_ω − D_ω/η_d
                    U_ω(t) ≥ G_ω(t) − E_plan(t)          ← 第一阶段决策 E_plan 贯穿所有场景
                    0 ≤ C_ω,D_ω ≤ ΔE_max ; 0 ≤ CU_ω ≤ pv_ω·Δt ; 1200 ≤ S_ω ≤ 10800

  · 场景 Ω 取「最近 S 天（不含当天）的实测负荷/光伏」—— 只用历史信息，无未来泄露；
  · 由于目标函数显式包含"给定 E_plan 后期望的紧急购电成本"，
    **最优的保守程度由模型自动决定，无需人工选取分位数 z**；
  · 这正是报童/分位数法的严格推广：分位数法是本模型在"单场景 + 正态假设"下的近似解。

日内执行仍与第一代一致：E_plan 固定后，用**当天实测值**求解最优储能调度
（最小化紧急购电费用），储能状态跨天连续传递。
"""
import os
import sys
import io
import time
import json
import csv
import argparse

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

import numpy as np
from scipy.sparse import coo_matrix
from scipy.optimize import linprog
from common_q2 import (load_all, DT, NT, E_INIT, E_MIN, E_MAX, P_MAX, ETA_C, ETA_D,
                       RES_DIR, SAVE_START, KEY_DATES, TABLE1_CLOCKS, clock_to_t)

DELTA_E_MAX = P_MAX * DT

# ----- 日内（第二阶段）变量分块 -----
G, C, D, CU, S, U = 0, NT, 2 * NT, 3 * NT, 4 * NT, 5 * NT
NV_S = 6 * NT


def solve_two_stage(price, scen_load, scen_pv, soc_init):
    """两阶段随机规划：返回第一阶段最优计划购电量 E_plan(144)。"""
    S_n = len(scen_load)
    nv = NT + S_n * NV_S
    c = np.zeros(nv)
    c[0:NT] = price                                    # 第一阶段：计划购电费
    W = 1.0 / S_n
    for k in range(S_n):
        base = NT + k * NV_S
        c[base + U:base + U + NT] = W * 5.0 * price    # 各场景的期望紧急购电费

    rows, cols, vals = [], [], []
    beq = np.zeros(2 * S_n * NT)
    r = 0
    for k in range(S_n):
        base = NT + k * NV_S
        lk = scen_load[k] * DT
        pk = scen_pv[k] * DT
        for t in range(NT):                       # 平衡：G − C + D − CU = load − pv
            rows += [r, r, r, r]
            cols += [base + G + t, base + C + t, base + D + t, base + CU + t]
            vals += [1.0, -1.0, 1.0, -1.0]
            beq[r] = lk[t] - pk[t]
            r += 1
        for t in range(NT):                       # 动态
            rows += [r, r, r]
            cols += [base + S + t, base + C + t, base + D + t]
            vals += [1.0, -ETA_C, 1.0 / ETA_D]
            if t > 0:
                rows.append(r); cols.append(base + S + t - 1); vals.append(-1.0)
            beq[r] = soc_init if t == 0 else 0.0
            r += 1
    # 不等式：U_ω(t) ≥ G_ω(t) − E_plan(t)  →  −U + G − E_plan ≤ 0
    n_ub = S_n * NT
    rows_ub, cols_ub, vals_ub = [], [], []
    ru = 0
    for k in range(S_n):
        base = NT + k * NV_S
        for t in range(NT):
            rows_ub += [ru, ru, ru]
            cols_ub += [base + U + t, base + G + t, t]
            vals_ub += [-1.0, 1.0, -1.0]
            ru += 1
    A_eq = coo_matrix((vals, (rows, cols)), shape=(r, nv)).tocsr()
    A_ub = coo_matrix((vals_ub, (rows_ub, cols_ub)), shape=(n_ub, nv)).tocsr()
    b_ub = np.zeros(n_ub)

    bounds = [(0.0, None)] * NT                                  # E_plan
    for k in range(S_n):
        bounds += ([(0.0, None)] * NT                            # G
                   + [(0.0, DELTA_E_MAX)] * NT                   # C
                   + [(0.0, DELTA_E_MAX)] * NT                   # D
                   + [(0.0, float(scen_pv[k][t] * DT)) for t in range(NT)]   # CU
                   + [(E_MIN, E_MAX)] * NT                       # S
                   + [(0.0, None)] * NT)                         # U
    res = linprog(c, A_eq=A_eq, b_eq=beq, A_ub=A_ub, b_ub=b_ub,
                  bounds=bounds, method='highs')
    assert res.success, res.message
    return np.maximum(0.0, res.x[:NT])


def solve_intraday(price, load_act, pv_act, plan_buy, init_soc):
    """日内最优执行（同第一代改进）：给定 E_plan 与实测值，最小化紧急购电费用。"""
    nv = NV_S
    c = np.zeros(nv)
    c[U:U + NT] = 5.0 * price
    rows, cols, vals = [], [], []
    beq = np.zeros(2 * NT)
    r = 0
    for t in range(NT):
        rows += [r, r, r, r]
        cols += [G + t, C + t, D + t, CU + t]
        vals += [1.0, -1.0, 1.0, -1.0]
        beq[r] = load_act[t] * DT - pv_act[t] * DT
        r += 1
    for t in range(NT):
        rows += [r, r, r]
        cols += [S + t, C + t, D + t]
        vals += [1.0, -ETA_C, 1.0 / ETA_D]
        if t > 0:
            rows.append(r); cols.append(S + t - 1); vals.append(-1.0)
        beq[r] = init_soc if t == 0 else 0.0
        r += 1
    rows_ub, cols_ub, vals_ub = [], [], []
    for t in range(NT):
        rows_ub += [t, t]
        cols_ub += [G + t, U + t]
        vals_ub += [1.0, -1.0]
    A_eq = coo_matrix((vals, (rows, cols)), shape=(2 * NT, nv)).tocsr()
    A_ub = coo_matrix((vals_ub, (rows_ub, cols_ub)), shape=(NT, nv)).tocsr()
    b_ub = np.asarray(plan_buy, float)
    bounds = ([(0.0, None)] * NT + [(0.0, DELTA_E_MAX)] * NT + [(0.0, DELTA_E_MAX)] * NT
              + [(0.0, float(pv_act[t] * DT)) for t in range(NT)]
              + [(E_MIN, E_MAX)] * NT + [(0.0, None)] * NT)
    res = linprog(c, A_eq=A_eq, b_eq=beq, A_ub=A_ub, b_ub=b_ub,
                  bounds=bounds, method='highs')
    assert res.success, res.message
    x = res.x
    return x[U:U + NT], x[C:C + NT], x[D:D + NT], x[CU:CU + NT], x[S:S + NT], x[G:G + NT]


def run(jan_days=31, n_scen=20, verbose=True):
    price, dates, load, pv = load_all()
    days_total = load.shape[0]
    soc = E_INIT

    def one_day(d):
        s = max(0, d - n_scen)
        sl = load[s:d] if d > s else load[max(0, d - 1):d]
        sp = pv[s:d] if d > s else pv[max(0, d - 1):d]
        if len(sl) == 0:                       # 预热期首日：无历史 → 用当天实测
            sl, sp = load[d:d + 1], pv[d:d + 1]
        plan = solve_two_stage(price, sl, sp, soc)
        return solve_intraday(price, load[d], pv[d], plan, soc), plan

    for d in range(jan_days):                  # 1 月预热
        (_, _, _, _, S, _), _ = one_day(d)
        soc = float(S[-1])

    recs = []
    t0 = time.time()
    for d in range(jan_days, days_total):
        (urg, ch, dis, curt, S, gro), plan = one_day(d)
        plan_cost = float((price * plan).sum())
        urg_cost = float((5.0 * price * urg).sum())
        recs.append({
            'day': d, 'plan_kWh': plan, 'em_kWh': urg, 'ch_kWh': ch, 'dis_kWh': dis,
            'curt_kWh': curt, 'E_kWh': S, 'E0': soc, 'E_T': float(S[-1]),
            'plan_buy_kWh': float(plan.sum()), 'em_buy_kWh': float(urg.sum()),
            'ch_kWh_sum': float(ch.sum()), 'dis_kWh_sum': float(dis.sum()),
            'curtail_kWh_sum': float(curt.sum()),
            'plan_cost': plan_cost, 'em_cost': urg_cost, 'total_cost': plan_cost + urg_cost,
        })
        soc = float(S[-1])
        if verbose and (d - jan_days + 1) % 60 == 0:
            print('  已完成 %d / %d 天' % (d - jan_days + 1, days_total - jan_days))
    el = time.time() - t0
    if verbose:
        print('全年两阶段随机规划完成，用时 %.1f 秒' % el)
    return price, dates, load, pv, recs, el


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--scen', type=int, default=20, help='场景数（默认 20）')
    ap.add_argument('--tag', type=str, default='gemini_v2')
    args = ap.parse_args()

    price, dates, load, pv, recs, el = run(n_scen=args.scen)
    tot = lambda k: sum(r[k] for r in recs)
    em_days = sum(1 for r in recs if r['em_buy_kWh'] > 1e-6)
    cur_days = sum(1 for r in recs if r['curtail_kWh_sum'] > 1e-6)
    pv_tot = pv[31:].sum() * DT
    print()
    print('=' * 96)
    print('Gemini 路线 v2（场景化两阶段随机规划，%d 场景）：%s ~ %s，共 %d 天'
          % (args.scen, str(dates[31])[:10], str(dates[-1])[:10], len(recs)))
    print('=' * 96)
    print('计划购电量 %.2f kWh | 计划购电费 %.2f 元' % (tot('plan_buy_kWh'), tot('plan_cost')))
    print('紧急购电量 %.2f kWh | 紧急购电费 %.2f 元 | 触发天数 %d'
          % (tot('em_buy_kWh'), tot('em_cost'), em_days))
    print('购电总费用 %.2f 元' % tot('total_cost'))
    print('储能充电 %.2f kWh | 放电 %.2f kWh' % (tot('ch_kWh_sum'), tot('dis_kWh_sum')))
    print('弃光 %.2f kWh（%d 天）| 光伏消纳率 %.2f%%'
          % (tot('curtail_kWh_sum'), cur_days, 100 * (1 - tot('curtail_kWh_sum') / pv_tot)))

    summary = {
        'model': 'two-stage stochastic (scenario-based)', 'n_scen': args.scen,
        'days': len(recs), 'solve_seconds': round(el, 1),
        'total_plan_buy_kWh': tot('plan_buy_kWh'), 'total_plan_cost': tot('plan_cost'),
        'total_emergency_kWh': tot('em_buy_kWh'), 'total_emergency_cost': tot('em_cost'),
        'total_cost': tot('total_cost'), 'emergency_days': em_days,
        'total_charge_kWh': tot('ch_kWh_sum'), 'total_discharge_kWh': tot('dis_kWh_sum'),
        'total_curtail_kWh': tot('curtail_kWh_sum'), 'curtail_days': cur_days,
        'pv_utilization': 1 - tot('curtail_kWh_sum') / pv_tot,
    }
    with open(os.path.join(RES_DIR, 'q2_%s_summary.json' % args.tag), 'w', encoding='utf-8') as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)
    with open(os.path.join(RES_DIR, 'q2_%s_daily.csv' % args.tag), 'w', newline='',
              encoding='utf-8-sig') as f:
        w = csv.writer(f)
        w.writerow(['日期', '计划购电量_kWh', '紧急购电量_kWh', '计划购电费_元', '紧急购电费_元',
                    '总费用_元', '充电_kWh', '放电_kWh', '弃光_kWh', '0:00储电量', '24:00储电量'])
        for i, r in enumerate(recs):
            w.writerow([str(dates[31 + i])[:10], '%.2f' % r['plan_buy_kWh'],
                        '%.2f' % r['em_buy_kWh'], '%.2f' % r['plan_cost'],
                        '%.2f' % r['em_cost'], '%.2f' % r['total_cost'],
                        '%.2f' % r['ch_kWh_sum'], '%.2f' % r['dis_kWh_sum'],
                        '%.2f' % r['curtail_kWh_sum'], '%.2f' % r['E0'], '%.2f' % r['E_T']])
    print('written results/q2_%s_summary.json / _daily.csv' % args.tag)


if __name__ == '__main__':
    main()
