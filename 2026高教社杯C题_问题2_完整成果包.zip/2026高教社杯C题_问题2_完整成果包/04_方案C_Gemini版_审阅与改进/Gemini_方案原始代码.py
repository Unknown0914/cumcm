# -*- coding: utf-8 -*-
"""2026 CUMCM C题 问题2 —— Gemini 版原始代码逐字复现

来源：D:\\download\\C题_问题二_最优解答与完整代码.pdf（Gemini，10 页，第 4--9 页代码块）

模型：报童临界分位数（α*=80%）→ 滚动分位数预测 → 日前 MILP（含 0-1 充放互斥）
      → 日内实际执行仿真（出现缺额则紧急购电）→ 1 月预热 → result2.xlsx 导出

本文件除以下"仅为能运行"的必要改动外，与原文代码一致：
  1) 附件路径改为绝对路径；
  2) 输出文件写到 results/ 子目录；
  3) 增加 --days 参数与审计输出（否则全年 365 次 MILP 耗时过长）；不改变任何建模逻辑。
"""
import os
import sys
import io
import argparse
import time
import traceback

import numpy as np
import pandas as pd
import openpyxl
import pulp

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
OUT = os.path.join(ROOT, 'results')
os.makedirs(OUT, exist_ok=True)

# ------------------------------------------------------------------------------
# 1. 物理参数与常量定义 (来自附录1与题干)
# ------------------------------------------------------------------------------
DT = 1.0 / 6.0
NUM_STEPS = 144
BATT_CAP_MAX = 12000.0
BATT_S_MIN = 1200.0
BATT_S_MAX = 10800.0
BATT_P_MAX = 5000.0
DELTA_E_MAX = BATT_P_MAX * DT
ETA_CH = 0.90
ETA_DIS = 0.90
FILE_ATT1 = r'C:\Users\35941\Desktop\C题\附件\附件1.xlsx'
FILE_ATT2 = r'C:\Users\35941\Desktop\C题\附件\附件2.xlsx'
FILE_RES2 = r'C:\Users\35941\Desktop\C题\附件\附件5\result2.xlsx'

# 是否启用“预热期首日兜底”修复；用 --no-fix 置 False 可复现原始崩溃
FIX_DAY0 = True


# ------------------------------------------------------------------------------
# 2. 数据读取与矩阵构建
# ------------------------------------------------------------------------------
def load_all_data():
    df_price = pd.read_excel(FILE_ATT1)
    prices = df_price['电价'].values[:NUM_STEPS].astype(float)
    df_load_raw = pd.read_excel(FILE_ATT2, sheet_name='小区负载')
    df_pv_raw = pd.read_excel(FILE_ATT2, sheet_name='光伏发电实际功率')
    dates = pd.to_datetime(df_load_raw.iloc[:, 0]).dt.strftime('%Y-%m-%d').tolist()
    loads = df_load_raw.iloc[:, 1:NUM_STEPS + 1].values.astype(float)
    pvs = df_pv_raw.iloc[:, 1:NUM_STEPS + 1].values.astype(float)
    return prices, dates, loads, pvs


# ------------------------------------------------------------------------------
# 3. 日前保守分位数预测 (结合报童临界分位数 80%)
# ------------------------------------------------------------------------------
def forecast_day_ahead(day_idx, loads, pvs, lookback=7, quantile_factor=0.84):
    start_idx = max(0, day_idx - lookback)
    hist_loads = loads[start_idx:day_idx]
    hist_pvs = pvs[start_idx:day_idx]
    # 【最小修复】预热期第 0 天没有任何历史数据，原代码此处产生 NaN 并导致 PuLP 崩溃
    # （Cannot add/subtract NaN/inf values）。此处退化为使用当天的实测值作为"预测"，
    # 仅用于推进 1 月预热期的储能状态，不影响 2 月 1 日之后的任何结果。
    # 用 --no-fix 可关闭该修复，以复现原始代码的崩溃。
    if len(hist_loads) == 0:
        if not FIX_DAY0:
            return (np.full(NUM_STEPS, np.nan), np.full(NUM_STEPS, np.nan))   # 原始行为
        return loads[day_idx].copy(), pvs[day_idx].copy()
    mean_load = np.mean(hist_loads, axis=0)
    std_load = np.std(hist_loads, axis=0) if len(hist_loads) > 1 else np.zeros(NUM_STEPS)
    mean_pv = np.mean(hist_pvs, axis=0)
    std_pv = np.std(hist_pvs, axis=0) if len(hist_pvs) > 1 else np.zeros(NUM_STEPS)
    # 负荷上浮，光伏下浮构建 80% 置信区间安全裕度
    robust_load = mean_load + quantile_factor * std_load
    robust_pv = np.maximum(0.0, mean_pv - quantile_factor * std_pv)
    return robust_load, robust_pv


# ------------------------------------------------------------------------------
# 4. 日前计划购电 MILP 规划优化
# ------------------------------------------------------------------------------
def optimize_day_ahead(prices, fc_load, fc_pv, init_soc):
    prob = pulp.LpProblem("DayAhead_Plan", pulp.LpMinimize)
    E_plan = [pulp.LpVariable(f"E_plan_{t}", lowBound=0) for t in range(NUM_STEPS)]
    E_ch = [pulp.LpVariable(f"E_ch_{t}", lowBound=0, upBound=DELTA_E_MAX) for t in range(NUM_STEPS)]
    E_dis = [pulp.LpVariable(f"E_dis_{t}", lowBound=0, upBound=DELTA_E_MAX) for t in range(NUM_STEPS)]
    u_ch = [pulp.LpVariable(f"u_ch_{t}", cat=pulp.LpBinary) for t in range(NUM_STEPS)]
    u_dis = [pulp.LpVariable(f"u_dis_{t}", cat=pulp.LpBinary) for t in range(NUM_STEPS)]
    S = [pulp.LpVariable(f"S_{t}", lowBound=BATT_S_MIN, upBound=BATT_S_MAX) for t in range(NUM_STEPS)]

    # 目标函数：计划购电费用最小
    prob += pulp.lpSum([prices[t] * E_plan[t] for t in range(NUM_STEPS)])

    for t in range(NUM_STEPS):
        prob += E_ch[t] <= DELTA_E_MAX * u_ch[t]
        prob += E_dis[t] <= DELTA_E_MAX * u_dis[t]
        prob += u_ch[t] + u_dis[t] <= 1
        prev_s = init_soc if t == 0 else S[t - 1]
        prob += S[t] == prev_s + ETA_CH * E_ch[t] - (1.0 / ETA_DIS) * E_dis[t]
        prob += E_plan[t] + fc_pv[t] * DT + E_dis[t] >= fc_load[t] * DT + E_ch[t]

    solver = pulp.PULP_CBC_CMD(msg=False, timeLimit=15)
    prob.solve(solver)
    plan_sol = np.array([pulp.value(E_plan[t]) for t in range(NUM_STEPS)])
    return np.maximum(0.0, plan_sol)


# ------------------------------------------------------------------------------
# 5. 日内真实调度与紧急购电仿真
# ------------------------------------------------------------------------------
def simulate_intraday(actual_load, actual_pv, plan_buy, init_s):
    s_curr = init_s
    e_ch_arr = np.zeros(NUM_STEPS)
    e_dis_arr = np.zeros(NUM_STEPS)
    e_urg_arr = np.zeros(NUM_STEPS)
    s_trajectory = np.zeros(NUM_STEPS)

    for t in range(NUM_STEPS):
        load_energy = actual_load[t] * DT
        pv_energy = actual_pv[t] * DT
        net_shortage = load_energy - pv_energy - plan_buy[t]

        if net_shortage > 1e-6:
            max_possible_dis = min(DELTA_E_MAX, (s_curr - BATT_S_MIN) * ETA_DIS)
            e_dis = min(max_possible_dis, net_shortage)
            e_ch = 0.0
            urg_need = net_shortage - e_dis
            e_urg = max(0.0, urg_need)
            s_curr -= (e_dis / ETA_DIS)
        else:
            surplus = -net_shortage
            max_possible_ch = min(DELTA_E_MAX, (BATT_S_MAX - s_curr) / ETA_CH)
            e_ch = min(max_possible_ch, surplus)
            e_dis = 0.0
            e_urg = 0.0
            s_curr += (e_ch * ETA_CH)

        e_ch_arr[t] = e_ch
        e_dis_arr[t] = e_dis
        e_urg_arr[t] = e_urg
        s_trajectory[t] = s_curr

    return e_ch_arr, e_dis_arr, e_urg_arr, s_trajectory


# ------------------------------------------------------------------------------
# 6. 时间段格式化与连续时区合并
# ------------------------------------------------------------------------------
def step_to_time_str(idx):
    minutes = idx * 10
    h = minutes // 60
    m = minutes % 60
    return f"{h:02d}:{m:02d}"


def merge_urgent_intervals(e_urg_arr):
    intervals = []
    in_block = False
    start_step = 0
    total_val = 0.0

    for t in range(NUM_STEPS):
        if e_urg_arr[t] > 1e-4:
            if not in_block:
                in_block = True
                start_step = t
                total_val = e_urg_arr[t]
            else:
                total_val += e_urg_arr[t]
        else:
            if in_block:
                intervals.append((f"{step_to_time_str(start_step)}-{step_to_time_str(t)}",
                                  round(total_val, 2)))
                in_block = False
                total_val = 0.0
    if in_block:
        intervals.append((f"{step_to_time_str(start_step)}-24:00", round(total_val, 2)))
    return intervals


# ------------------------------------------------------------------------------
# 7. 主执行流程与 result2.xlsx 规范写入
# ------------------------------------------------------------------------------
def solve_problem_2(days=None, jan_days=31, write_excel=True):
    prices, dates, loads, pvs = load_all_data()
    current_soc = 6000.0          # 2025.1.1 0:00 初始基准

    # 1 月份预热期滚动推进
    for d in range(jan_days):
        fc_l, fc_pv = forecast_day_ahead(d, loads, pvs)
        plan_buy = optimize_day_ahead(prices, fc_l, fc_pv, current_soc)
        _, _, _, s_traj = simulate_intraday(loads[d], pvs[d], plan_buy, current_soc)
        current_soc = s_traj[-1]

    all_plan_records = []
    all_bat_records = []
    all_urg_records = []
    total_days = len(dates) if days is None else min(len(dates), jan_days + days)

    for d in range(jan_days, total_days):
        date_str = dates[d]
        fc_l, fc_pv = forecast_day_ahead(d, loads, pvs)
        plan_buy = optimize_day_ahead(prices, fc_l, fc_pv, current_soc)
        e_ch, e_dis, e_urg, s_traj = simulate_intraday(loads[d], pvs[d], plan_buy, current_soc)

        day_buy_sum = np.sum(plan_buy)
        day_cost_sum = np.sum(plan_buy * prices)
        all_plan_records.append([date_str] + list(np.round(plan_buy, 2))
                                + [round(day_buy_sum, 2), round(day_cost_sum, 2)])

        soc_0 = current_soc
        soc_24 = s_traj[-1]
        block_records = []
        for b in range(6):
            b_ch = np.sum(e_ch[b * 24:(b + 1) * 24])
            b_dis = np.sum(e_dis[b * 24:(b + 1) * 24])
            block_records.append((round(b_ch, 2), round(b_dis, 2)))
        all_bat_records.append((date_str, block_records, round(soc_0, 2), round(soc_24, 2)))

        urg_intervals = merge_urgent_intervals(e_urg)
        all_urg_records.append((date_str, urg_intervals))
        current_soc = soc_24

    if not write_excel:
        return all_plan_records, all_bat_records, all_urg_records

    # 写入 Excel 模板
    wb = openpyxl.load_workbook(FILE_RES2)
    # 1. 计划购电量
    ws_plan = wb['计划购电量']
    for r_idx, row_vals in enumerate(all_plan_records, start=2):
        for c_idx, val in enumerate(row_vals, start=1):
            ws_plan.cell(row=r_idx, column=c_idx, value=val)
    # 2. 充放电量
    ws_bat = wb['充放电量']
    for r in range(2, ws_bat.max_row + 1):
        for c in range(1, 7):
            ws_bat.cell(r, c, value=None)
    cur_row = 2
    time_labels = ["0:00-4:00", "4:00-8:00", "8:00-12:00", "12:00-16:00", "16:00-20:00", "20:00-24:00"]
    for date_str, blocks, s0, s24 in all_bat_records:
        for b_idx in range(6):
            if b_idx == 0:
                ws_bat.cell(cur_row, 1, value=date_str)
                ws_bat.cell(cur_row, 5, value="00:00:00")
                ws_bat.cell(cur_row, 6, value=s0)
            elif b_idx == 1:
                ws_bat.cell(cur_row, 5, value="24:00")
                ws_bat.cell(cur_row, 6, value=s24)
            ws_bat.cell(cur_row, 2, value=time_labels[b_idx])
            ws_bat.cell(cur_row, 3, value=blocks[b_idx][0])
            ws_bat.cell(cur_row, 4, value=blocks[b_idx][1])
            cur_row += 1
    # 3. 紧急购电量
    ws_urg = wb['紧急购电量']
    for r in range(2, ws_urg.max_row + 1):
        for c in range(1, 4):
            ws_urg.cell(r, c, value=None)
    cur_u_row = 2
    for date_str, intervals in all_urg_records:
        if not intervals:
            ws_urg.cell(cur_u_row, 1, value=date_str)
            ws_urg.cell(cur_u_row, 2, value="无")
            ws_urg.cell(cur_u_row, 3, value=0.0)
            cur_u_row += 1
        else:
            first = True
            for span_str, val in intervals:
                if first:
                    ws_urg.cell(cur_u_row, 1, value=date_str)
                    first = False
                ws_urg.cell(cur_u_row, 2, value=span_str)
                ws_urg.cell(cur_u_row, 3, value=val)
                cur_u_row += 1
    out_path = os.path.join(OUT, 'gemini_original_result2.xlsx')
    wb.save(out_path)
    print('已写出:', out_path)
    return all_plan_records, all_bat_records, all_urg_records


if __name__ == '__main__':
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
    ap = argparse.ArgumentParser()
    ap.add_argument('--days', type=int, default=3, help='预热 31 天之后，再仿真多少天（默认 3 天做快速验证）')
    ap.add_argument('--write-excel', action='store_true')
    ap.add_argument('--no-fix', action='store_true',
                    help='关闭首日兜底修复，复现原始代码的 NaN 崩溃')
    args = ap.parse_args()
    if args.no_fix:
        globals()['FIX_DAY0'] = False
        print('[已关闭首日兜底修复，将复现原始崩溃]')

    t0 = time.time()
    try:
        plan_recs, bat_recs, urg_recs = solve_problem_2(days=args.days,
                                                        write_excel=args.write_excel)
        el = time.time() - t0
        print('=' * 78)
        print('Gemini 原始代码运行完成，耗时 %.1f 秒' % el)
        print('=' * 78)
        n_urg = sum(1 for _, iv in urg_recs if iv)
        tot_urg = sum(v for _, iv in urg_recs for _, v in iv)
        tot_plan = sum(r[-2] for r in plan_recs)
        tot_cost = sum(r[-1] for r in plan_recs)
        avg_price = tot_cost / tot_plan if tot_plan else 0.0
        em_cost_est = tot_urg * 5 * avg_price
        print('审计追加：紧急购电 %.2f kWh；按平均电价 %.4f 元/kWh 估算紧急购电费约 %.2f 元'
              % (tot_urg, avg_price, em_cost_est))
        print('审计追加：计划购电费 %.2f 元，估算总费用 %.2f 元'
              % (tot_cost, tot_cost + em_cost_est))
        print('仿真天数 %d；计划购电合计 %.2f kWh；计划购电费合计 %.2f 元'
              % (len(plan_recs), tot_plan, tot_cost))
        print('出现紧急购电的天数 %d；紧急购电量合计 %.2f kWh' % (n_urg, tot_urg))
        print()
        print('前 3 天明细：')
        for i, (pr, br, ur) in enumerate(zip(plan_recs[:3], bat_recs[:3], urg_recs[:3])):
            print('  [%s] 计划购电 %.2f kWh，费用 %.2f 元；SOC %.2f -> %.2f'
                  % (pr[0], pr[-2], pr[-1], br[2], br[3]))
            if ur[1]:
                for span, val in ur[1][:4]:
                    print('      紧急购电 %s : %.2f kWh' % (span, val))
            else:
                print('      无紧急购电')
    except Exception:
        print('=' * 78)
        print('Gemini 原始代码运行失败：')
        print('=' * 78)
        traceback.print_exc()
