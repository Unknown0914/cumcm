# -*- coding: utf-8 -*-
"""Gemini 路线 v2（场景化两阶段随机规划）：场景数敏感性。"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'code'))
from q2_gemini_v2 import run

print('=' * 104)
print('Gemini 路线 v2：两阶段随机规划的场景数敏感性')
print('=' * 104)
print('%8s %16s %16s %14s %14s %14s %12s' %
      ('场景数', '计划购电(kWh)', '计划购电费(元)', '紧急购电(kWh)', '紧急购电费(元)', '总费用(元)', '弃光(kWh)'))
rows = []
for ns in [10, 20, 30]:
    price, dates, load, pv, recs, el = run(n_scen=ns, verbose=False)
    tot = lambda k: sum(r[k] for r in recs)
    rows.append((ns, tot('total_cost'), el))
    print('%8d %16.0f %16.0f %14.0f %14.0f %14.0f %12.0f'
          % (ns, tot('plan_buy_kWh'), tot('plan_cost'), tot('em_buy_kWh'),
             tot('em_cost'), tot('total_cost'), tot('curtail_kWh_sum')))
print()
for ns, c, el in rows:
    print('  场景数 %2d：总费用 %.0f 元，耗时 %.1f 秒' % (ns, c, el))
best = min(rows, key=lambda x: x[1])
print('最优场景数 = %d，总费用 %.0f 元' % (best[0], best[1]))
