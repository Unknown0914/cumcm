# -*- coding: utf-8 -*-
"""lag-7 预测器：分位数系数 z 与残差窗口的细粒度寻优。"""
import sys, os
HERE = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'code')
sys.path.insert(0, HERE)
import numpy as np
from common_q2 import load_all, DT, NT
import q2_gemini_improved as G

price, dates, load, pv = load_all()


def make_fc(z, win):
    def fc(day_idx, loads, pvs, lookback=7, z=None, _z=z, _w=win):
        if day_idx < 7:
            return loads[day_idx] - pvs[day_idx]
        n = loads - pvs
        base = n[day_idx - 7]
        s = max(7, day_idx - _w)
        res = n[s:day_idx] - n[s - 7:day_idx - 7]
        sd = res.std(axis=0) if len(res) > 1 else np.zeros(NT)
        return base + _z * sd
    return fc


def eval_fc(z, win):
    orig = G.forecast_day_ahead
    G.forecast_day_ahead = make_fc(z, win)
    try:
        _, _, _, _, recs, _ = G.run(z=z, verbose=False)
    finally:
        G.forecast_day_ahead = orig
    tot = lambda k: sum(r[k] for r in recs)
    return tot('total_cost'), tot('plan_buy_kWh'), tot('em_buy_kWh')


print('=' * 100)
print('lag-7 预测器：z 细搜（残差窗口 win=30 天）')
print('=' * 100)
print('%10s %16s %16s %16s' % ('z', '计划购电(kWh)', '紧急购电(kWh)', '总费用(元)'))
best = (None, 1e18)
for z in [0.0, 0.15, 0.25, 0.35, 0.40, 0.45, 0.55]:
    c, b, e = eval_fc(z, 30)
    if c < best[1]:
        best = (z, c)
    print('%10.2f %16.0f %16.0f %16.0f' % (z, b, e, c))
print('最优 z=%.2f → %.0f 元' % best)

print()
print('=' * 100)
print('残差窗口 win 的影响（z=%.2f）' % best[0])
print('=' * 100)
print('%10s %16s %16s %16s' % ('win', '计划购电(kWh)', '紧急购电(kWh)', '总费用(元)'))
for w in [10, 20, 30, 60, 120]:
    c, b, e = eval_fc(best[0], w)
    print('%10d %16.0f %16.0f %16.0f' % (w, b, e, c))
