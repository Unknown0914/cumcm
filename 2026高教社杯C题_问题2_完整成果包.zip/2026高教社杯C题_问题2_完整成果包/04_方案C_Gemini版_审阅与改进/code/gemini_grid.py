# -*- coding: utf-8 -*-
"""Gemini 路线（分位数法）：历史窗口 lookback 与分位数系数 z 的联合寻优。"""
import sys, os, io
HERE = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'code')
sys.path.insert(0, HERE)
from q2_gemini_improved import run

print('=' * 100)
print('Gemini 路线（分位数法）：lookback × z 联合寻优（保存期 334 天总费用，单位元）')
print('=' * 100)
zs = [0.55, 0.60, 0.65, 0.6745, 0.70, 0.75]
lbs = [3, 5, 7, 10, 14]
header = '%10s' % 'lookback'
for z in zs:
    header += '%12.4f' % z
print(header)
best = (None, None, 1e18)
for lb in lbs:
    line = '%10d' % lb
    for z in zs:
        price, dates, load, pv, recs, el = run(z=z, lookback=lb, verbose=False)
        c = sum(r['total_cost'] for r in recs)
        if c < best[2]:
            best = (lb, z, c)
        line += '%12.0f' % c
    print(line)
print()
print('最优组合：lookback=%d, z=%.4f，总费用 %.0f 元' % best)
