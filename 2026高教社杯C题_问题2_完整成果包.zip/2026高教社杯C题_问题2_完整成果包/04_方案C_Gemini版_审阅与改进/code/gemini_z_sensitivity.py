# -*- coding: utf-8 -*-
"""Gemini 路线改进版：报童分位数系数 z 的敏感性（检验 80% 分位是否真的最优）。"""
import sys, os, io
HERE = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'code')
sys.path.insert(0, HERE)
from q2_gemini_improved import run

print('=' * 108)
print('Gemini 路线（改进版）：保守分位数系数 z 的敏感性')
print('=' * 108)
print('%8s %8s %16s %16s %14s %14s %14s %12s'
      % ('z', '分位数', '计划购电(kWh)', '计划购电费(元)', '紧急购电(kWh)',
         '紧急购电费(元)', '总费用(元)', '弃光(kWh)'))
rows = []
for z in [0.0, 0.3, 0.5, 0.6745, 0.8416, 1.0, 1.2816]:
    price, dates, load, pv, recs, el = run(z=z, verbose=False)
    tot = lambda k: sum(r[k] for r in recs)
    q = {0.0: '50%', 0.3: '61.8%', 0.5: '69.1%', 0.6745: '75%',
         0.8416: '80%', 1.0: '84.1%', 1.2816: '90%'}[z]
    rows.append((z, tot('total_cost')))
    print('%8.4f %8s %16.0f %16.0f %14.0f %14.0f %14.0f %12.0f'
          % (z, q, tot('plan_buy_kWh'), tot('plan_cost'), tot('em_buy_kWh'),
             tot('em_cost'), tot('total_cost'), tot('curtail_kWh_sum')))
best = min(rows, key=lambda x: x[1])
print()
print('最优 z = %.4f，总费用 %.0f 元' % best)
print('z=0.8416（报童理论 80%% 分位）总费用 %.0f 元' % dict(rows)[0.8416])
