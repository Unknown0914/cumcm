# -*- coding: utf-8 -*-
"""
利用"周内模式"改进预测器 —— Gemini 路线的关键增益点。

发现：附件2 的负载存在极强周内结构（周五、周六日均负载仅约其他日的 63%）。
      "前 7 天滚动均值"会把周五/周六的低负载与其余日的高负载混在一起，
      造成预测残差偏大、保守裕度过量、计划购电量虚高。

改进：把预测基准由"前 k 天均值"改为"上周同一天（lag-7）"，并用历史残差
      （net[i] − net[i−7]）的标准差给出分位数裕度：
          fc(t) = net_{d−7}(t) + z · std( net_i(t) − net_{i−7}(t) )
      同样只用历史数据，无未来信息泄露。
"""
import sys, os, io
HERE = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'code')
sys.path.insert(0, HERE)
import numpy as np
from common_q2 import load_all, DT, NT, E_INIT, E_MIN, E_MAX, P_MAX
import q2_gemini_improved as G

price, dates, load, pv = load_all()
net = load - pv

# ---- 三种预测器的残差尺度对比（前瞻验证，仅用于估值，不用于仿真） ----
print('=' * 92)
print('预测残差尺度对比（逐时段标准差的中位数，kW）')
print('=' * 92)
rows = []
for d in range(31, 365):
    a = net[max(0, d - 7):d].mean(axis=0)
    rows.append(net[d] - a)
print('  前7天均值预测       残差σ中位 %.1f kW' % np.median(np.std(np.array(rows), axis=0)))
rows = []
for d in range(38, 365):
    base = net[d - 7]
    s = max(7, d - 30)
    res_hist = net[s:d] - net[s - 7:d - 7]
    sd = res_hist.std(axis=0)
    rows.append(net[d] - (base + 0.71 * sd))
print('  lag-7 + z·σ_残差    残差σ中位 %.1f kW' % np.median(np.std(np.array(rows), axis=0)))
rows = []
for d in range(38, 365):
    rows.append(net[d] - net[d - 7])
print('  纯 lag-7 预测       残差σ中位 %.1f kW' % np.median(np.std(np.array(rows), axis=0)))


# ---- 用 lag-7 预测器替换 Gemini 路线改进版的预测函数，重跑全年 ----
def forecast_weekly(day_idx, loads, pvs, lookback=30, z=0.71):
    if day_idx < 7:
        return loads[day_idx] - pvs[day_idx]
    n = loads - pvs
    base = n[day_idx - 7]
    s = max(7, day_idx - lookback)
    res = n[s:day_idx] - n[s - 7:day_idx - 7]
    sd = res.std(axis=0) if len(res) > 1 else np.zeros(NT)
    return base + z * sd


print()
print('=' * 92)
print('全年仿真对比（保存期 334 天）')
print('=' * 92)
print('%22s %16s %14s %14s %14s %12s' %
      ('预测器', '计划购电(kWh)', '紧急购电(kWh)', '计划购电费(元)', '紧急购电费(元)', '总费用(元)'))

results = {}
# 基线：前 7 天滚动均值 + z 分位
for z in (0.71,):
    _, _, _, _, recs, _ = G.run(z=z, lookback=7, verbose=False)
    tot = lambda k: sum(r[k] for r in recs)
    results['ma7_z%.2f' % z] = tot('total_cost')
    print('%22s %16.0f %14.0f %14.0f %14.0f %12.0f'
          % ('前7天均值+%.2fσ' % z, tot('plan_buy_kWh'), tot('em_buy_kWh'),
             tot('plan_cost'), tot('em_cost'), tot('total_cost')))

# 改进：lag-7 基准 + 残差分位
for z in (0.4, 0.6, 0.71, 0.85):
    orig = G.forecast_day_ahead
    G.forecast_day_ahead = lambda d, L, P, lookback=7, z=z, _f=forecast_weekly: _f(d, L, P, z=z)
    _, _, _, _, recs, _ = G.run(z=z, verbose=False)
    G.forecast_day_ahead = orig
    tot = lambda k: sum(r[k] for r in recs)
    results['lag7_z%.2f' % z] = tot('total_cost')
    print('%22s %16.0f %14.0f %14.0f %14.0f %12.0f'
          % ('lag7+%.2fσ残差' % z, tot('plan_buy_kWh'), tot('em_buy_kWh'),
             tot('plan_cost'), tot('em_cost'), tot('total_cost')))

best = min(results.items(), key=lambda kv: kv[1])
print()
print('最优：%s，总费用 %.0f 元（完全信息基准 12 227 244 元）' % (best[0], best[1]))
