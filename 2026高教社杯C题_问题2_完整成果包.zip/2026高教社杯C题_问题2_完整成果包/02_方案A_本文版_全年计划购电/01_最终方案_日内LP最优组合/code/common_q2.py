# -*- coding: utf-8 -*-
"""
common_q2.py —— 2026 高教社杯 C 题 问题2 公共模块

路径、物理参数、附件1/附件2 读取与时段约定工具。

时段约定（沿用问题1，见问题1 报告 §3.2）：
  附件1 的 144 个采样时刻为 0:10, 0:20, ..., 24:00，附件2 的 144 个数据列与之逐一对应；
  第 t 个采样点的功率代表区间 [10(t-1), 10t) 分钟内的平均功率，即采样时刻是区间的**右端点**。
  于是 t=1 -> 0:00-0:10，t=61 -> 10:00-10:10，t=144 -> 23:50-24:00。
"""
import os
import pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
DATA_DIR = os.path.join(ROOT, 'data')
FIG_DIR = os.path.join(ROOT, 'figures')
OUT_DIR = os.path.join(ROOT, 'output')
RES_DIR = os.path.join(ROOT, 'results')
for _d in (DATA_DIR, FIG_DIR, OUT_DIR, RES_DIR):
    os.makedirs(_d, exist_ok=True)

SRC1 = r'C:\Users\35941\Desktop\C题\附件\附件1.xlsx'
SRC2 = r'C:\Users\35941\Desktop\C题\附件\附件2.xlsx'
TPL_RESULT2 = r'C:\Users\35941\Desktop\C题\附件\附件5\result2.xlsx'

# ---------------- 物理参数（附录1） ----------------
DT = 1.0 / 6.0            # 时段长度 h
NT = 144                  # 每天时段数
E_INIT = 6000.0           # 2025-01-01 0:00 初始储电量 kWh
E_MIN = 1200.0
E_MAX = 10800.0
P_MAX = 5000.0
ETA_C = 0.9
ETA_D = 0.9

SAVE_START = pd.Timestamp('2025-02-01')     # 结果保存起始日（题目要求 2025.2.1-12.31）
KEY_DATES = [pd.Timestamp('2025-03-20'), pd.Timestamp('2025-06-21'),
             pd.Timestamp('2025-09-23'), pd.Timestamp('2025-12-21')]

TABLE1_CLOCKS = ['10:00', '12:00', '14:00', '16:00', '18:00', '20:00']


def fmt_clock(minutes):
    """距 0:00 的分钟数 -> 标签（1440 -> '0:00+1'）。"""
    day, rem = divmod(int(minutes), 1440)
    hh, mm = divmod(rem, 60)
    return '%d:%02d' % (hh, mm) + ('+1' if day == 1 else '')


def t_to_interval(t):
    """时段 t（1-based）对应的 10 分钟区间标签，如 61 -> '10:00-10:10'。"""
    return '%s-%s' % (fmt_clock(10 * (t - 1)), fmt_clock(10 * t))


def clock_to_t(label):
    """区间左端点标签 -> 时段号，如 '10:00' -> 61。"""
    hh, mm = label.split(':')
    minutes = int(hh) * 60 + int(mm)
    assert minutes % 10 == 0 and 0 <= minutes < 1440, label
    return minutes // 10 + 1


def load_price(path=SRC1):
    """读取附件1 的电价曲线（144 个时段，元/kWh）。"""
    df = pd.read_excel(path)
    price = pd.to_numeric(df['电价'], errors='raise').to_numpy(float)
    assert len(price) == NT, len(price)
    return price


def load_year(sheet):
    """读取附件2 某工作表，返回 (日期数组, 数据矩阵 365×144)。"""
    df = pd.read_excel(SRC2, sheet_name=sheet)
    dates = pd.to_datetime(df.iloc[:, 0]).to_numpy()
    vals = df.iloc[:, 1:1 + NT].apply(pd.to_numeric, errors='raise').to_numpy(float)
    assert vals.shape == (365, NT), vals.shape
    return dates, vals


def load_all():
    """一次性读取附件1 电价与附件2 全年负载、光伏。"""
    price = load_price()
    dates, load = load_year('小区负载')
    dates2, pv = load_year('光伏发电实际功率')
    assert (dates == dates2).all()
    return price, dates, load, pv


if __name__ == '__main__':
    import sys, io
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
    import numpy as np
    price, dates, load, pv = load_all()
    print('电价范围 [%.4f, %.4f] 元/kWh' % (price.min(), price.max()))
    print('日期范围', pd.Timestamp(dates[0]).date(), '~', pd.Timestamp(dates[-1]).date(), '共', len(dates), '天')
    print('负载范围 [%.2f, %.2f] kW' % (load.min(), load.max()))
    print('光伏范围 [%.2f, %.2f] kW' % (pv.min(), pv.max()))
    net = load - pv
    print('净负荷范围 [%.2f, %.2f] kW' % (net.min(), net.max()))
    sur = np.clip(-net, 0, None).sum(axis=1) * DT
    print('光伏富余总量全年 %.2f kWh；富余 > 0 的天数 %d' % (sur.sum(), int((sur > 1e-6).sum())))
    print('单日最大富余 %.2f kWh' % sur.max())
