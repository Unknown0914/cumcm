# -*- coding: utf-8 -*-
"""
forecast_analysis.py —— 预测器精度分析（问题2/3 共用的基础）

目的：题面四问都没有给出"负载预报"，问题2 也没有给光伏预报（附件2 只有实际功率）。
      因此制定当天计划时必须用**历史数据外推**。本脚本用附件2 全年实测数据，
      实测各候选预测器的精度，用数据决定用哪一个。

候选预测器（预测第 d 天、第 t 时段）：
  lag1        前一天同时段                 P = X[d-1, t]
  lag7        上周同一天同时段（考虑周内结构） P = X[d-7, t]
  ma7         前 7 天滑动均值               P = mean(X[d-7:d, t])
  ma30        前 30 天滑动均值              P = mean(X[d-30:d, t])
  lag7_clim   上周同一天 + 全历史同时段偏差均值修正
被预测对象：负载 load / 光伏 pv / 净负荷 net = load - pv

指标：MAE（平均绝对误差，kW）、RMSE、σ（残差标准差）、偏差 bias。
"""
import os, sys, io, json, csv
sys.stdout.reconfigure(encoding='utf-8', errors='replace')
import numpy as np
import pandas as pd

DESK = r'C:\Users\35941\Desktop'
AD = os.path.join(DESK, 'C题', '附件')
OUT = os.path.join(DESK, 'cumcm2026C_q2', 'results')
NT = 144


def load_series():
    dfL = pd.read_excel(os.path.join(AD, '附件2.xlsx'), sheet_name='小区负载', index_col=0)
    dfV = pd.read_excel(os.path.join(AD, '附件2.xlsx'), sheet_name='光伏发电实际功率', index_col=0)
    L = dfL.iloc[:, :NT].to_numpy(float)
    V = dfV.iloc[:, :NT].to_numpy(float)
    dates = pd.to_datetime(dfL.index)
    return dates, L, V


def predictors(X, d, warm=30):
    """返回各预测器对第 d 天的预测（长度 NT）。要求 d >= warm。"""
    out = {}
    out['lag1'] = X[d - 1].copy()
    if d >= 7:
        out['lag7'] = X[d - 7].copy()
    else:
        out['lag7'] = np.nan
    out['ma7'] = X[max(0, d - 7):d].mean(axis=0)
    out['ma30'] = X[max(0, d - 30):d].mean(axis=0)
    # lag7 + 全历史同时段偏差均值修正
    if d >= 7:
        hist = X[:d]
        base = hist.mean(axis=0)
        out['lag7_clim'] = X[d - 7] + (base - np.roll(base, 0)) * 0.0  # 占位，下面重算
        # 用 d-7 之前所有同星期几样本的偏差均值
        idx = [k for k in range(max(0, d - 7 * 8), d - 7, 7) if k >= 0]
        idx = list(range(max(0, d - 7 * 8), d - 7, 7))
        if idx:
            dev = np.mean([X[k] - X[k - 7] for k in idx if k - 7 >= 0], axis=0) \
                if any(k - 7 >= 0 for k in idx) else np.zeros(NT)
            out['lag7_clim'] = X[d - 7] + dev
    return out


def evaluate(X, name, warm=30):
    rows = []
    for d in range(warm, len(X)):
        preds = predictors(X, d, warm)
        act = X[d]
        for k, p in preds.items():
            if p is None or np.all(np.isnan(p)):
                continue
            e = p - act
            rows.append((d, k, float(np.abs(e).mean()), float(np.sqrt((e ** 2).mean())),
                         float(e.std()), float(e.mean())))
    df = pd.DataFrame(rows, columns=['d', 'method', 'MAE', 'RMSE', 'sigma', 'bias'])
    g = df.groupby('method')[['MAE', 'RMSE', 'sigma', 'bias']].mean().round(2)
    g = g.sort_values('MAE')
    print('\n===== 被预测量：%s =====' % name)
    print(g.to_string())
    return g, df


def weekly_structure(L, V, dates):
    """周内结构证据：各星期几的日均负载/光伏。"""
    print('\n===== 周内结构（各星期几的日均值）=====')
    dow = pd.Series(dates).dt.dayofweek.to_numpy()
    names = ['周一', '周二', '周三', '周四', '周五', '周六', '周日']
    print('%-6s %12s %12s %12s' % ('星期', '负载kWh', '光伏kWh', '净负荷kWh'))
    for k in range(7):
        m = dow == k
        print('%-6s %12.0f %12.0f %12.0f' % (
            names[k], L[m].sum() * 1 / 6, V[m].sum() / 6, (L[m] - V[m]).sum() / 6))


def main():
    os.makedirs(OUT, exist_ok=True)
    dates, L, V = load_series()
    print('数据: %d 天 × %d 时段' % L.shape)
    print('负载范围 [%.1f, %.1f] kW | 光伏范围 [%.1f, %.1f] kW'
          % (L.min(), L.max(), V.min(), V.max()))
    weekly_structure(L, V, dates)

    res = {}
    for X, nm in ((L, '小区负载'), (V, '光伏发电'), (L - V, '净负荷 load-pv')):
        g, df = evaluate(X, nm)
        res[nm] = g
        g.to_csv(os.path.join(OUT, 'fc_analysis_%s.csv' % nm.replace(' ', '_')
                              .replace('=', '').replace('-', '_')),
                 encoding='utf-8-sig')

    # 汇总输出
    with io.open(os.path.join(OUT, 'q2_forecast_analysis.txt'), 'w', encoding='utf-8') as f:
        f.write('预测器精度分析（附件2 全年实测，2025-01-01 ~ 12-31）\n')
        f.write('=' * 72 + '\n')
        dow = pd.Series(dates).dt.dayofweek.to_numpy()
        names = ['周一', '周二', '周三', '周四', '周五', '周六', '周日']
        f.write('\n周内结构（各星期几日均电量 kWh）：\n')
        f.write('%-6s %14s %14s %14s\n' % ('星期', '负载', '光伏', '净负荷'))
        for k in range(7):
            m = dow == k
            f.write('%-6s %14.0f %14.0f %14.0f\n' % (
                names[k], L[m].sum() / 6, V[m].sum() / 6, (L[m] - V[m]).sum() / 6))
        for nm, g in res.items():
            f.write('\n被预测量：%s\n' % nm)
            f.write(g.to_string() + '\n')
    print('\n已写出 results/q2_forecast_analysis.txt')


if __name__ == '__main__':
    main()
