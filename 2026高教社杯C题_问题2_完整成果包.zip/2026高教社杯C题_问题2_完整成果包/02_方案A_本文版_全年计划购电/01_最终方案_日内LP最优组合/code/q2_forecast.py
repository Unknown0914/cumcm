# -*- coding: utf-8 -*-
"""
q2_forecast.py —— 问题2「预测版」：当天数据不可知，须用历史外推

题面依据：
  · 问题2 原文只提「附件1 的电价和附件2 中的数据」，**不含任何“预报”字样**；
  · 附件2 给出的是「小区负载」与「光伏发电**实际**功率」（全年实测历史）；
  · 问题2 明确写了「如果低于负载，需向外网紧急购电…5 倍电价」以及
    「除紧急购电费用外，其他时间段的购电费用均按**计划购电量**计算」——
    这两句只有在“计划基于预测、实际会偏离”时才成立。
  ⇒ 计划必须用历史数据外推，执行时用实际值对账，缺额走紧急购电。

预测器（由 forecast_analysis.py 实测选定）：
  · 负载：lag-7（上周同一天，MAE 176.7 kW）——负载有强周内结构（周五/周六仅 63%）
  · 光伏：ma7（前 7 天滑动均值，MAE 153.2 kW）——光伏无周内结构
  · 净需求 = 负载预测 − 光伏预测 + z·σ_t（z 为安全裕度，σ_t 为逐时段残差标准差）

费用（题面）：F = Σ c_t·P_t（计划量全额） + Σ 5·c_t·em_t（紧急购电）
"""
import os, sys, io, json, argparse, time
sys.stdout.reconfigure(encoding='utf-8', errors='replace')
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import numpy as np
import pandas as pd
from scipy.optimize import linprog
from common_q2 import (DT, NT, E_INIT, E_MIN, E_MAX, P_MAX, ETA_C, ETA_D,
                       SAVE_START, RES_DIR, load_price, load_year)

EM_K = 5.0          # 紧急购电电价倍数


# ==================== 预测 ====================
def build_forecast(L, V, lag=7, ma=7, mode='split'):
    """返回逐日预测（kW 单位，与 L/V 一致）。

    mode='split' : 负载 lag-7、光伏 ma7，分开预测（本文方案）
    mode='net'   : 对净负荷 (L-V) 直接做 lag-7（Gemini 路线）
    """
    if mode == 'net':
        NET = L - V
        Lp = np.zeros_like(L); Vp = np.zeros_like(V)
        for d in range(L.shape[0]):
            base = NET[d - lag] if d >= lag else (NET[:d].mean(axis=0) if d > 0 else NET[d])
            Lp[d] = np.maximum(base, 0.0); Vp[d] = 0.0     # 全部记在“负载侧”，净额等价
        return Lp, Vp
    n = L.shape[0]
    Lp = np.zeros_like(L); Vp = np.zeros_like(V)
    for d in range(n):
        if d >= lag:
            Lp[d] = L[d - lag]
        else:
            Lp[d] = L[:d].mean(axis=0) if d > 0 else L[d]
        lo = max(0, d - ma)
        Vp[d] = V[lo:d].mean(axis=0) if d > 0 else V[d]
    return Lp, Vp


def rolling_sigma(L, V, Lp, Vp, win=60):
    """逐日、逐时段的残差标准差 σ_t（只用 d 之前的数据）。"""
    n = L.shape[0]
    sig = np.zeros((n, L.shape[1]))
    for d in range(n):
        lo = max(0, d - win)
        if d - lo < 5:
            sig[d] = np.full(L.shape[1], 1.0) * 50.0
        else:
            e = (Lp[lo:d] - L[lo:d]) - (Vp[lo:d] - V[lo:d])
            sig[d] = e.std(axis=0)
    return sig


# ==================== 计划 LP ====================
def solve_plan(price, D, E0, pv_sur=None):
    E0 = float(min(max(E0, E_MIN), E_MAX))      # 保护：上一天末值可能在界外
    """min Σ c·P  s.t. P + dis − ch + curt = D，储能动态，边界。D 为需求电量(kWh)。"""
    n = NT
    nv = 5 * n                      # [P, ch, dis, curt, E]
    P, C, Dv, CU, E = 0, n, 2 * n, 3 * n, 4 * n
    c = np.zeros(nv); c[P:P + n] = price * DT
    A_eq, b_eq = [], []
    for k in range(n):
        row = np.zeros(nv)
        row[P + k] = 1.0; row[Dv + k] = 1.0; row[C + k] = -1.0; row[CU + k] = -1.0
        A_eq.append(row); b_eq.append(D[k])
    for k in range(n):
        row = np.zeros(nv)
        row[E + k] = 1.0
        if k > 0:
            row[E + k - 1] = -1.0
        row[C + k] = -ETA_C
        row[Dv + k] = 1.0 / ETA_D
        A_eq.append(row)
        b_eq.append(E0 if k == 0 else 0.0)
    # 变量均为 kWh（电量），故充放上界为 P_MAX*DT
    bounds = ([(0.0, None)] * n + [(0.0, P_MAX * DT)] * n + [(0.0, P_MAX * DT)] * n
              + [(0.0, float(pv_sur[k]) if pv_sur is not None else 1e6)
                 for k in range(n)]
              + [(E_MIN, E_MAX)] * n)
    res = linprog(c, A_eq=np.array(A_eq), b_eq=np.array(b_eq), bounds=bounds,
                  method='highs')
    if not res.success:
        raise RuntimeError('LP 失败: ' + res.message)
    z = res.x
    return z[P:P + n], z[C:C + n], z[Dv:Dv + n], z[CU:CU + n], z[E:E + n]


# ==================== 执行 ====================
def execute_plan(L_act, V_act, P_plan, ch_plan, dis_plan, E0):
    """按计划执行：储能沿用 LP 规划的充放动作（这是 0:00 已定的计划的一部分），
    实际光伏/负载与预测的偏差由“弃光（光伏富余部分）”或“紧急购电”吸收。

    ★ 关键：不能让执行层用“实际需求 − 计划购电”重新决定储能动作——
      因为 LP 的 P 已经扣除了储能贡献（P = D − dis + ch），
      再算一次等于把储能贡献重复扣减，导致储能白忙、大量电量白付。
    """
    E0 = float(min(max(E0, E_MIN), E_MAX))     # 保护：初值必须在界内
    ch = np.array(ch_plan, float); dis = np.array(dis_plan, float)
    em = np.zeros(NT); curt = np.zeros(NT); E = np.zeros(NT)
    bal = P_plan + V_act * DT + dis - L_act * DT - ch   # kWh；>0 供给多余
    pv_sur = np.maximum(0.0, (V_act - L_act) * DT)
    curt = np.maximum(0.0, np.minimum(bal, pv_sur))
    em = np.maximum(0.0, -bal)
    e = E0
    for t in range(NT):
        e += ch[t] * ETA_C - dis[t] / ETA_D
        E[t] = e
    return em, ch, dis, curt, E, e


def execute_intraday_lp(price, L_act, V_act, plan_buy, E0):
    """日内 LP（闭环执行，Gemini 路线的核心贡献）：
    计划购电量已锁定不变，但储能**每时段最优使用**以最小化 5 倍紧急购电费。

        min Σ 5c·U
        s.t. G − C + D − CU = L·Δt − V·Δt
             U ≥ G − E_plan, U ≥ 0
             S(t) = S(t−1) + η_c·C − D/η_d
    比“按计划执行”（开环）省 5.0%–8.7%。
    """
    G, C, D, CU, S, U = 0, NT, 2 * NT, 3 * NT, 4 * NT, 5 * NT
    nv = 6 * NT
    c = np.zeros(nv); c[U:U + NT] = EM_K * price
    A_eq, b_eq = [], []
    for t in range(NT):
        row = np.zeros(nv)
        row[G + t] = 1.0; row[C + t] = -1.0; row[D + t] = 1.0; row[CU + t] = -1.0
        A_eq.append(row); b_eq.append(L_act[t] * DT - V_act[t] * DT)
    for t in range(NT):
        row = np.zeros(nv)
        row[S + t] = 1.0
        if t > 0: row[S + t - 1] = -1.0
        row[C + t] = -ETA_C; row[D + t] = 1.0 / ETA_D
        A_eq.append(row); b_eq.append(E0 if t == 0 else 0.0)
    A_ub, b_ub = [], []
    for t in range(NT):
        row = np.zeros(nv)
        row[G + t] = 1.0; row[U + t] = -1.0
        A_ub.append(row); b_ub.append(float(plan_buy[t]))
    DE = P_MAX * DT
    bounds = ([(0.0, None)] * NT + [(0.0, DE)] * NT + [(0.0, DE)] * NT
              + [(0.0, float(V_act[t] * DT)) for t in range(NT)]
              + [(E_MIN, E_MAX)] * NT + [(0.0, None)] * NT)
    res = linprog(c, A_ub=np.array(A_ub), b_ub=np.array(b_ub),
                  A_eq=np.array(A_eq), b_eq=np.array(b_eq), bounds=bounds, method='highs')
    if not res.success:
        raise RuntimeError('日内 LP 失败: ' + res.message)
    x = res.x
    return x[U:U + NT], x[C:C + NT], x[D:D + NT], x[CU:CU + NT], x[S:S + NT], float(x[S + NT - 1])


def execute_greedy(L_act, V_act, P_plan, E0):
    """贪婪执行（对照）：储能实时响应偏差。"""
    ch = np.zeros(NT); dis = np.zeros(NT); curt = np.zeros(NT); em = np.zeros(NT)
    E = np.zeros(NT)
    e = E0
    for t in range(NT):
        net = (L_act[t] - V_act[t]) * DT - P_plan[t]
        if net > 1e-9:
            max_dis = min(P_MAX * DT, max(0.0, e - E_MIN) * ETA_D)
            d = min(max_dis, net)
            dis[t] = d; em[t] = net - d
            e -= d / ETA_D
        else:
            surplus = -net
            max_ch = min(P_MAX * DT, (E_MAX - e) / ETA_C)
            cg = min(max_ch, surplus)
            ch[t] = cg
            pv_sur = max(0.0, (V_act[t] - L_act[t]) * DT)
            curt[t] = min(surplus - cg, pv_sur)
            e += cg * ETA_C
        E[t] = e
    return em, ch, dis, curt, E, e


# ==================== 全年 ====================
def run(price, L, V, z=0.0, lag=7, ma=7, sig_win=60, verbose=True, fc='split',
        exec_mode='intraday'):
    Lp, Vp = build_forecast(L, V, lag, ma, mode=fc)
    sig = rolling_sigma(L, V, Lp, Vp, sig_win)
    soc = E_INIT
    recs = []
    for d in range(L.shape[0]):
        D = (Lp[d] - Vp[d]) * DT + z * sig[d] * DT   # kW -> kWh（可为负=光伏富余）
        Dpv_sur = np.maximum(0.0, (Vp[d] - Lp[d]) * DT)   # 预测的光伏富余
        try:
            P, ch_p, dis_p, curt_p, E_p = solve_plan(price, D, soc, Dpv_sur)
        except RuntimeError as ex:
            print('  LP 不可行: day=%d soc=%.2f | D min/max=%.2f/%.2f'
                  % (d, soc, D.min(), D.max()))
            raise
        if exec_mode == 'intraday':
            em, ch, dis, curt, E, soc = execute_intraday_lp(price, L[d], V[d], P, soc)
            soc = float(min(max(soc, E_MIN), E_MAX))
        else:
            em, ch, dis, curt, E, soc = execute_plan(L[d], V[d], P, ch_p, dis_p, soc)
            soc = float(min(max(soc, E_MIN), E_MAX))
        recs.append(dict(P=P, em=em, ch=ch, dis=dis, curt=curt, E=E, e_end=soc,
                         plan_cost=float((P * price).sum()),   # P 已是 kWh，勿再乘 DT
                         em_cost=float((EM_K * price * em).sum())))
        if verbose and (d + 1) % 100 == 0:
            print('  已推演 %d / %d 天' % (d + 1, L.shape[0]))
    return recs, (Lp, Vp, sig)


def summarize(recs, dates):
    idx = [i for i, d in enumerate(dates) if pd.Timestamp(d) >= SAVE_START]
    g = lambda k: float(sum(recs[i][k] for i in idx))
    pc, ec = g('plan_cost'), g('em_cost')
    return {'days': len(idx),
            'plan_kWh': float(sum(recs[i]['P'].sum() for i in idx)),
            'plan_cost': pc, 'em_cost': ec, 'total_cost': pc + ec,
            'em_kWh': float(sum(recs[i]['em'].sum() for i in idx)),
            'curt_kWh': float(sum(recs[i]['curt'].sum() for i in idx)),
            'charge_kWh': float(sum(recs[i]['ch'].sum() for i in idx)),
            'discharge_kWh': float(sum(recs[i]['dis'].sum() for i in idx)),
            'em_days': int(sum(1 for i in idx if recs[i]['em'].sum() > 1e-6))}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--z', type=float, default=0.45, help='安全裕度分位数系数（日内LP 下实测最优 0.45）')
    ap.add_argument('--lag', type=int, default=7)
    ap.add_argument('--ma', type=int, default=7)
    ap.add_argument('--exec', choices=['intraday', 'plan'], default='intraday',
                    help='intraday=日内LP闭环（默认，最优）；plan=按计划开环')
    ap.add_argument('--fc', choices=['split', 'net'], default='split',
                    help='split=负载lag7+光伏ma7（本文）；net=净负荷lag7（Gemini 式）')
    ap.add_argument('--tag', default=None)
    args = ap.parse_args()
    tag = args.tag or ('fc_z%.2f' % args.z)

    price = load_price()
    dates, L = load_year('小区负载')
    _, V = load_year('光伏发电实际功率')
    print('数据 %d 天 | 预测器 负载=lag%d 光伏=ma%d | 安全裕度 z=%.4f'
          % (L.shape[0], args.lag, args.ma, args.z))
    t0 = time.time()
    recs, _ = run(price, L, V, z=args.z, lag=args.lag, ma=args.ma, fc=args.fc,
                 exec_mode=args.exec)
    s = summarize(recs, dates)
    s['z'] = args.z; s['lag'] = args.lag; s['ma'] = args.ma; s['fc'] = args.fc
    s['exec'] = args.exec
    s['seconds'] = round(time.time() - t0, 1)
    print('\n统计期 %d 天（%s ~ %s）' % (s['days'],
          pd.Timestamp(dates[0]).date(), pd.Timestamp(dates[-1]).date()))
    print('计划购电 %.2f kWh（费用 %.2f 元）' % (s['plan_kWh'], s['plan_cost']))
    print('紧急购电 %.2f kWh（费用 %.2f 元，%d 天有无紧急购电）'
          % (s['em_kWh'], s['em_cost'], s['em_days']))
    print('总费用 %.2f 元 | 弃光 %.2f kWh | 充 %.2f / 放 %.2f kWh | 耗时 %.1f s'
          % (s['total_cost'], s['curt_kWh'], s['charge_kWh'], s['discharge_kWh'],
             s['seconds']))
    os.makedirs(RES_DIR, exist_ok=True)
    json.dump(s, io.open(os.path.join(RES_DIR, 'q2_%s.json' % tag), 'w',
                         encoding='utf-8'), ensure_ascii=False, indent=2)
    print('已写出 results/q2_%s.json' % tag)
    return s


if __name__ == '__main__':
    main()
