# -*- coding: utf-8 -*-
"""
cmp_exec.py —— 对比“执行层”两种做法对问题2 的影响（预测器与 z 固定为最优）

执行方式 A（本文当前）：按计划执行 —— 储能沿用 0:00 计划的充放动作，
    实际与预测的偏差由弃光/紧急购电吸收（开环）。
执行方式 B（Gemini 路线）：日内 LP —— 计划购电量固定，但储能**每时段重新最优使用**，
    以最小化紧急购电费（闭环）。
两者的共同前提：实际购电可以小于计划量（费用照计划结算），
    只有实际必需购电超出计划的部分才按 5 倍电价。
"""
import os, sys, io, json, glob
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.stdout.reconfigure(encoding='utf-8', errors='replace')
import numpy as np
from scipy.optimize import linprog
from common_q2 import (DT, NT, E_INIT, E_MIN, E_MAX, P_MAX, ETA_C, ETA_D, SAVE_START,
                       RES_DIR, load_price, load_year)
from q2_forecast import build_forecast, rolling_sigma, solve_plan

EM_K = 5.0
DE = P_MAX * DT          # 单时段最大充/放电量 (kWh)


def execute_intraday_lp(price, L_act, V_act, plan_buy, E0):
    """日内 LP：计划购电量固定，储能最优使用以最小化 Σ5c·U（U = 超出计划的实际购电）。"""
    G, C, D, CU, S, U = 0, NT, 2 * NT, 3 * NT, 4 * NT, 5 * NT
    nv = 6 * NT
    c = np.zeros(nv); c[U:U + NT] = EM_K * price

    A_eq, b_eq = [], []
    for t in range(NT):                     # G − C + D − CU = L·Δt − V·Δt
        row = np.zeros(nv)
        row[G + t] = 1.0; row[C + t] = -1.0; row[D + t] = 1.0; row[CU + t] = -1.0
        A_eq.append(row); b_eq.append(L_act[t] * DT - V_act[t] * DT)
    for t in range(NT):                     # 储能动态
        row = np.zeros(nv)
        row[S + t] = 1.0
        if t > 0:
            row[S + t - 1] = -1.0
        row[C + t] = -ETA_C; row[D + t] = 1.0 / ETA_D
        A_eq.append(row); b_eq.append(E0 if t == 0 else 0.0)

    A_ub, b_ub = [], []
    for t in range(NT):                     # U + plan − G ≥ 0 → G − U ≤ plan
        row = np.zeros(nv)
        row[G + t] = 1.0; row[U + t] = -1.0
        A_ub.append(row); b_ub.append(float(plan_buy[t]))

    bounds = ([(0.0, None)] * NT + [(0.0, DE)] * NT + [(0.0, DE)] * NT
              + [(0.0, float(V_act[t] * DT)) for t in range(NT)]
              + [(E_MIN, E_MAX)] * NT + [(0.0, None)] * NT)
    res = linprog(c, A_ub=np.array(A_ub), b_ub=np.array(b_ub),
                  A_eq=np.array(A_eq), b_eq=np.array(b_eq), bounds=bounds, method='highs')
    if not res.success:
        raise RuntimeError('日内 LP 失败: ' + res.message)
    x = res.x
    return x[U:U + NT], x[C:C + NT], x[D:D + NT], x[CU:CU + NT], x[S:S + NT]


def run(price, L, V, z, fc='split', exec_mode='plan', sig_win=60, lag=7, ma=7):
    Lp, Vp = build_forecast(L, V, lag, ma, mode=fc)
    sig = rolling_sigma(L, V, Lp, Vp, sig_win)
    soc = E_INIT
    recs = []
    for d in range(L.shape[0]):
        D = (Lp[d] - Vp[d]) * DT + z * sig[d] * DT
        Dpv = np.maximum(0.0, (Vp[d] - Lp[d]) * DT)
        P, ch_p, dis_p, curt_p, E_p = solve_plan(price, D, soc, Dpv)
        if exec_mode == 'intraday':
            em, ch, dis, curt, E = execute_intraday_lp(price, L[d], V[d], P, soc)
            soc = float(min(max(E[-1], E_MIN), E_MAX))
        else:
            from q2_forecast import execute_plan
            em, ch, dis, curt, E, soc = execute_plan(L[d], V[d], P, ch_p, dis_p, soc)
            soc = float(min(max(soc, E_MIN), E_MAX))
        recs.append(dict(P=P, em=em, ch=ch, dis=dis, curt=curt, E=E,
                         plan_cost=float((P * price).sum()),
                         em_cost=float((EM_K * price * em).sum())))
    return recs


def summarize(recs, dates):
    idx = [i for i, d in enumerate(dates) if __import__('pandas').Timestamp(d) >= SAVE_START]
    f = lambda k: float(sum(recs[i][k] for i in idx))
    return dict(total_cost=f('plan_cost') + f('em_cost'), plan_cost=f('plan_cost'),
                em_cost=f('em_cost'), plan_kWh=float(sum(recs[i]['P'].sum() for i in idx)),
                em_kWh=float(sum(recs[i]['em'].sum() for i in idx)),
                curt_kWh=float(sum(recs[i]['curt'].sum() for i in idx)))


def main():
    price = load_price()
    dates, L = load_year('小区负载')
    _, V = load_year('光伏发电实际功率')
    out = {}
    for mode, lbl in (('plan', '执行A 按计划（储能沿用计划动作）'),
                      ('intraday', '执行B 日内LP（储能每时段最优）')):
        for fc in ('split', 'net'):
            for z in (0.45, 0.8416):
                r = run(price, L, V, z, fc=fc, exec_mode=mode)
                s = summarize(r, dates)
                key = '%s|%s|%.4f' % (mode, fc, z)
                out[key] = s
                print('%-38s %-6s z=%.4f | 计划 %.0f kWh / %.0f 元 | 紧急 %.0f kWh / %.0f 元 | 总 %.2f 元'
                      % (lbl, fc, z, s['plan_kWh'], s['plan_cost'], s['em_kWh'], s['em_cost'],
                         s['total_cost']))
    json.dump(out, io.open(os.path.join(RES_DIR, 'q2_exec_compare.json'), 'w',
                           encoding='utf-8'), ensure_ascii=False, indent=2)
    print('\n已写出 results/q2_exec_compare.json')


if __name__ == '__main__':
    main()
