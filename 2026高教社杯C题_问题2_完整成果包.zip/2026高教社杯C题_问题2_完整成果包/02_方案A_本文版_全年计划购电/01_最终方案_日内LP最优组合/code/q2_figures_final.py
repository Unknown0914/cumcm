# -*- coding: utf-8 -*-
"""
q2_figures_final.py —— 问题2 最终方案（日内 LP 最优组合）的论文级图，共 8 张。

图1  电价与净负荷曲线（全年平均 + 单日样例）
图2  全年逐日购电量与费用（计划量 / 紧急购电量 / 日费用）
图3  储能储电量全年轨迹与充放电量月度分布
图4  弃光与紧急购电的月度分布
图5  指定日期（3.20 / 6.21）逐时段调度时序
图6  预测器精度对比（周内结构 + 5 种预测器 MAE/σ）
图7  执行层与预测器的 4×2 全因子对比
图8  安全裕度 z 敏感性（两种执行方式）
"""
import os, sys, io, json
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import rcParams
from common_q2 import (DT, NT, E_INIT, E_MIN, E_MAX, P_MAX, ETA_C, ETA_D, SAVE_START,
                       KEY_DATES, RES_DIR, OUT_DIR, load_price, load_year)
from q2_forecast import build_forecast, rolling_sigma, solve_plan, execute_intraday_lp

rcParams['font.sans-serif'] = ['Microsoft YaHei', 'SimHei', 'DejaVu Sans']
rcParams['axes.unicode_minus'] = False
rcParams['font.size'] = 10.5
rcParams['axes.grid'] = True
rcParams['grid.alpha'] = 0.3
C = {'price': '#C44E52', 'load': '#4C72B0', 'pv': '#E8A33D', 'net': '#8172B2',
     'soc': '#55A868', 'plan': '#4C72B0', 'em': '#C44E52', 'curt': '#E8A33D',
     'g1': '#4C72B0', 'g2': '#C44E52', 'g3': '#55A868', 'g4': '#8172B2'}
FIG = os.path.join(os.path.dirname(HERE), 'figures')
os.makedirs(FIG, exist_ok=True)
Z_BEST = 0.45


def save(fig, nm):
    for ext in ('pdf', 'png'):
        fig.savefig(os.path.join(FIG, '%s.%s' % (nm, ext)), dpi=300, bbox_inches='tight')
    plt.close(fig)
    print('  ->', nm)


def run_full(price, L, V, z=Z_BEST):
    """最终方案：逐日推演，返回逐时段明细。"""
    Lp, Vp = build_forecast(L, V, mode='split')
    sig = rolling_sigma(L, V, Lp, Vp, 60)
    soc = E_INIT
    recs = []
    for d in range(L.shape[0]):
        D = (Lp[d] - Vp[d]) * DT + z * sig[d] * DT
        Dpv = np.maximum(0.0, (Vp[d] - Lp[d]) * DT)
        P, ch_p, dis_p, curt_p, Ep = solve_plan(price, D, soc, Dpv)
        em, ch, dis, curt, E, s2 = execute_intraday_lp(price, L[d], V[d], P, soc)
        soc = float(min(max(s2, E_MIN), E_MAX))
        recs.append(dict(P=P, em=em, ch=ch, dis=dis, curt=curt, E=E,
                         plan_cost=float((P * price).sum()),
                         em_cost=float((5.0 * price * em).sum()),
                         Lp=Lp[d], Vp=Vp[d]))
    return recs, (Lp, Vp, sig)


def main():
    price = load_price()
    dates, L = load_year('小区负载')
    _, V = load_year('光伏发电实际功率')
    print('推演最终方案…')
    recs, aux = run_full(price, L, V)
    idx = [i for i, d in enumerate(dates) if __import__('pandas').Timestamp(d) >= SAVE_START]
    day = np.arange(len(idx))
    hr = np.arange(NT) * DT
    hr_ts = ((np.arange(NT) + 1) * DT) % 24

    g = lambda k: np.array([recs[i][k] for i in idx])
    P = g('P'); em = g('em'); ch = g('ch'); dis = g('dis'); curt = g('curt')
    E = g('E'); pc = np.array([recs[i]['plan_cost'] for i in idx])
    ec = np.array([recs[i]['em_cost'] for i in idx])

    # ============ 图1 电价与净负荷 ============
    net_avg = (L[idx] - V[idx]).mean(axis=0)
    L_avg = L[idx].mean(axis=0); V_avg = V[idx].mean(axis=0)
    fig, ax1 = plt.subplots(figsize=(9.6, 4.2))
    ax1.step(hr_ts, price, where='post', color=C['price'], lw=1.6, label='电价')
    ax1.set_xlabel('时刻 (h)'); ax1.set_ylabel('电价 (元/kWh)', color=C['price'])
    ax1.set_xlim(0, 24); ax1.set_xticks(np.arange(0, 25, 2))
    ax2 = ax1.twinx(); ax2.grid(False)
    ax2.fill_between(hr_ts, 0, net_avg, color=C['net'], alpha=0.25, label='净负荷（负载−光伏）')
    ax2.plot(hr_ts, net_avg, color=C['net'], lw=1.5)
    ax2.axhline(0, color='gray', lw=0.8, ls='--')
    ax2.set_ylabel('净负荷 (kW)')
    h1, l1 = ax1.get_legend_handles_labels(); h2, l2 = ax2.get_legend_handles_labels()
    ax1.legend(h1 + h2, l1 + l2, loc='upper left', fontsize=9)
    ax1.set_title('图1  全年平均电价与净负荷曲线（334 天平均）')
    save(fig, 'q2f_fig1_price_netload')

    # ============ 图2 全年逐日购电量与费用 ============
    dA = P.sum(axis=1) / 1e3; dE = em.sum(axis=1) / 1e3
    fig, (a1, a2) = plt.subplots(2, 1, figsize=(11, 6.0), sharex=True,
                                 gridspec_kw={'height_ratios': [1.25, 1]})
    a1.bar(day, dA, 1.0, color=C['plan'], alpha=0.75, label='计划购电量')
    a1.bar(day, dE, 1.0, bottom=dA, color=C['em'], alpha=0.9, label='紧急购电量')
    a1.set_ylabel('日购电量 (MWh)')
    a1.set_title('图2  全年逐日购电量与费用（2025-02-01 ~ 12-31，334 天）')
    a1.legend(fontsize=9)
    a2.plot(day, (pc + ec) / 1e4, lw=0.9, color=C['price'], label='日总费用')
    a2.plot(day, pc / 1e4, lw=0.9, color=C['plan'], alpha=0.8, label='计划购电费')
    a2.set_xlabel('天数序号（2025-02-01 起）'); a2.set_ylabel('费用 (万元)')
    a2.legend(fontsize=9)
    save(fig, 'q2f_fig2_daily_buy_cost')

    # ============ 图3 SOC 轨迹与充放电月度分布 ============
    fig, (a1, a2) = plt.subplots(1, 2, figsize=(12, 3.9))
    a1.plot(day, E.min(axis=1), lw=0.9, color=C['soc'], label='日最小储电量')
    a1.plot(day, E.max(axis=1), lw=0.9, color=C['soc'], alpha=0.6, label='日最大储电量')
    a1.axhline(E_MAX, color='gray', ls='-.', lw=1, label='上限 10800')
    a1.axhline(E_MIN, color='gray', ls='--', lw=1, label='下限 1200')
    a1.set_xlabel('天数序号'); a1.set_ylabel('储电量 (kWh)')
    a1.set_title('(a) 储能储电量全年轨迹'); a1.legend(fontsize=8)
    mon = np.array([__import__('pandas').Timestamp(dates[i]).month for i in idx])
    ms = list(range(2, 13))
    a2.bar(np.arange(len(ms)) - 0.2, [ch[mon == m].sum() / 1e3 for m in ms], 0.4,
           color=C['g3'], label='充电量')
    a2.bar(np.arange(len(ms)) + 0.2, [dis[mon == m].sum() / 1e3 for m in ms], 0.4,
           color=C['g4'], label='放电量')
    a2.set_xticks(np.arange(len(ms))); a2.set_xticklabels(['%d月' % m for m in ms], fontsize=8)
    a2.set_ylabel('电量 (MWh)'); a2.set_title('(b) 月度充放电量'); a2.legend(fontsize=8)
    save(fig, 'q2f_fig3_soc_cycle')

    # ============ 图4 弃光与紧急购电月度分布 ============
    fig, ax = plt.subplots(figsize=(9.8, 3.8))
    m_curt = [curt[mon == m].sum() / 1e3 for m in ms]
    m_em = [em[mon == m].sum() for m in ms]
    ax.bar(np.arange(len(ms)), m_curt, 0.6, color=C['curt'], label='弃光电量')
    ax.set_ylabel('弃光电量 (MWh)', color=C['curt'])
    ax.set_xticks(np.arange(len(ms))); ax.set_xticklabels(['%d月' % m for m in ms])
    ax2 = ax.twinx(); ax2.grid(False)
    ax2.plot(np.arange(len(ms)), m_em, 'o-', color=C['em'], label='紧急购电量')
    ax2.set_ylabel('紧急购电量 (kWh)', color=C['em'])
    h1, l1 = ax.get_legend_handles_labels(); h2, l2 = ax2.get_legend_handles_labels()
    ax.legend(h1 + h2, l1 + l2, loc='upper center', fontsize=9)
    ax.set_title('图4  弃光电量与紧急购电量的月度分布')
    save(fig, 'q2f_fig4_curt_em_monthly')

    # ============ 图5 指定日期时序 ============
    import pandas as pd
    for kd in (pd.Timestamp('2025-03-20'), pd.Timestamp('2025-06-21')):
        i = int(np.where(pd.to_datetime(dates) == kd)[0][0])
        r = recs[i]; rp = r['Lp']; rv = r['Vp']
        fig, (a1, a2) = plt.subplots(2, 1, figsize=(9.8, 5.6), sharex=True,
                                     gridspec_kw={'height_ratios': [1.05, 1.5]})
        a1.step(hr_ts, price, where='post', color=C['price'], lw=1.3, label='电价')
        a1.set_ylabel('电价 (元/kWh)', color=C['price'])
        a1.set_title('图5  指定日期 %s 的逐时段调度' % kd.date())
        a1b = a1.twinx(); a1b.grid(False)
        a1b.plot(hr_ts, L[i], color=C['load'], lw=1.2, label='负载')
        a1b.plot(hr_ts, V[i], color=C['pv'], lw=1.2, label='光伏实际')
        a1b.plot(hr_ts, rp * 6, color=C['net'], lw=1.1, ls='--', label='负载预测(lag-7)')
        a1b.plot(hr_ts, rv * 6, color=C['pv'], lw=1.0, ls=':', label='光伏预测(ma7)')
        a1b.set_ylabel('功率 (kW)')
        h1, l1 = a1.get_legend_handles_labels(); h2, l2 = a1b.get_legend_handles_labels()
        a1b.legend(h1 + h2, l1 + l2, loc='upper left', fontsize=8, ncol=2)
        a2.plot(hr_ts, r['P'], color=C['plan'], lw=1.4, label='计划购电量')
        a2.bar(hr_ts, r['em'], 0.14, color=C['em'], label='紧急购电量')
        a2.plot(hr_ts, r['ch'], color=C['g3'], lw=1.1, label='充电量')
        a2.plot(hr_ts, -r['dis'], color=C['g4'], lw=1.1, label='放电量（取负）')
        a2.axhline(0, color='gray', lw=0.8)
        a2.set_xlabel('时刻 (h)'); a2.set_ylabel('电量 (kWh)')
        a2.set_xlim(0, 24); a2.set_xticks(np.arange(0, 25, 2))
        a2.legend(fontsize=8, ncol=4, loc='upper center')
        save(fig, 'q2f_fig5_dispatch_%s' % kd.strftime('%m%d'))

    # ============ 图6 预测器精度 ============
    fc_txt = os.path.join(RES_DIR, 'q2_forecast_analysis.txt')
    dow = pd.Series(dates).dt.dayofweek.to_numpy()
    names = ['周一', '周二', '周三', '周四', '周五', '周六', '周日']
    fig, (a1, a2) = plt.subplots(1, 2, figsize=(12, 3.9))
    lv = [L[dow == k].sum() / 6 for k in range(7)]
    vv = [V[dow == k].sum() / 6 for k in range(7)]
    a1.bar(np.arange(7) - 0.2, lv, 0.4, color=C['load'], label='负载')
    a1.bar(np.arange(7) + 0.2, vv, 0.4, color=C['pv'], label='光伏')
    for k in (4, 5):
        a1.annotate('%.0f%%' % (100 * lv[k] / np.mean([lv[j] for j in (0, 1, 2, 3, 6)])),
                    (k - 0.2, lv[k]), textcoords='offset points', xytext=(0, 6),
                    ha='center', fontsize=9, color=C['em'])
    a1.set_xticks(np.arange(7)); a1.set_xticklabels(names)
    a1.set_ylabel('日均电量 (kWh)'); a1.set_title('(a) 周内结构：负载有、光伏无'); a1.legend(fontsize=9)
    meth = ['lag7', 'lag1', 'ma7', 'ma30']
    mA = [176.72, 653.80, 782.98, 791.69]      # 负载
    mP = [214.51, 185.05, 153.19, 225.37]      # 光伏
    x = np.arange(len(meth))
    a2.bar(x - 0.2, mA, 0.4, color=C['load'], label='负载预测')
    a2.bar(x + 0.2, mP, 0.4, color=C['pv'], label='光伏预测')
    for i in range(len(meth)):
        a2.text(i - 0.2, mA[i], '%.0f' % mA[i], ha='center', va='bottom', fontsize=8)
        a2.text(i + 0.2, mP[i], '%.0f' % mP[i], ha='center', va='bottom', fontsize=8)
    a2.set_xticks(x); a2.set_xticklabels(['lag-7', 'lag-1', 'ma7', 'ma30'])
    a2.set_ylabel('MAE (kW)'); a2.set_title('(b) 各预测器精度：负载用 lag-7、光伏用 ma7')
    a2.legend(fontsize=9)
    save(fig, 'q2f_fig6_forecast_accuracy')

    # ============ 图7 4×2 全因子对比 ============
    ex = json.load(io.open(os.path.join(RES_DIR, 'q2_exec_compare.json'), encoding='utf-8'))
    keys = [('plan|split|0.8416', '按计划\nsplit z=.8416'), ('plan|split|0.4500', '按计划\nsplit z=.45'),
            ('plan|net|0.4500', '按计划\nnet z=.45'),
            ('intraday|split|0.8416', '日内LP\nsplit z=.8416'),
            ('intraday|split|0.4500', '日内LP\nsplit z=.45'),
            ('intraday|net|0.4500', '日内LP\nnet z=.45')]
    ks = [k for k, _ in keys if k in ex]
    lbl = [d for k, d in keys if k in ex]
    fig, ax = plt.subplots(figsize=(11, 4.2))
    vals = [ex[k]['total_cost'] / 1e4 for k in ks]
    cols = [C['price'] if k.startswith('plan') else C['plan'] for k in ks]
    bars = ax.bar(np.arange(len(ks)), vals, 0.55, color=cols)
    for i, v in enumerate(vals):
        ax.text(i, v + 8, '%.1f' % v, ha='center', fontsize=9)
    best = int(np.argmin(vals))
    bars[best].set_color(C['g3']); bars[best].set_edgecolor('black'); bars[best].set_linewidth(1.6)
    ax.set_xticks(np.arange(len(ks))); ax.set_xticklabels(lbl, fontsize=8.5)
    ax.set_ylabel('总费用 (万元)')
    ax.set_title('图7  执行层 × 预测器 × z 的全因子对比（红=按计划开环，蓝=日内LP闭环，绿=最优）')
    save(fig, 'q2f_fig7_exec_compare')

    # ============ 图8 z 敏感性 ============
    fig, ax = plt.subplots(figsize=(7.4, 4.0))
    for mode, mk, col, name in (('plan', 's--', C['price'], '按计划执行（开环）'),
                                ('intraday', 'o-', C['plan'], '日内 LP（闭环）')):
        zs, ys = [], []
        for k, v in ex.items():
            if k.startswith(mode + '|split|'):
                zs.append(float(k.split('|')[2])); ys.append(v['total_cost'] / 1e4)
        if zs:
            o = np.argsort(zs)
            ax.plot(np.array(zs)[o], np.array(ys)[o], mk, color=col, lw=1.9, ms=7, label=name)
    ax.axvline(0.8416, color='gray', ls=':', lw=1.2)
    ax.text(0.8416, ax.get_ylim()[0], ' 报童理论 z=0.8416', fontsize=8, rotation=90,
            va='bottom', color='gray')
    ax.set_xlabel('安全裕度系数 z'); ax.set_ylabel('总费用 (万元)')
    ax.set_title('图8  安全裕度敏感性：最优 z 随执行方式而变')
    ax.legend(fontsize=9)
    save(fig, 'q2f_fig8_z_sensitivity')

    # 保存明细供后续使用
    np.savez_compressed(os.path.join(RES_DIR, 'q2_final_detail.npz'),
                        idx=np.array(idx), P=P, em=em, ch=ch, dis=dis, curt=curt, E=E)
    print('\n合计: 计划 %.0f kWh / %.0f 元 | 紧急 %.0f kWh / %.0f 元 | 总 %.2f 元'
          % (P.sum(), pc.sum(), em.sum(), ec.sum(), pc.sum() + ec.sum()))


if __name__ == '__main__':
    main()
