# -*- coding: utf-8 -*-
"""write_result2_fc.py —— 把问题2「预测版」结果按附件5 模板导出为 result2.xlsx。

模板结构（实测）：
  计划购电量  147 列 = 日期 + 144 时段 + 「全天购电量」「全天购电费」；335 行（1 表头 + 334 天）
  充放电量    每 6 行一天（0:00-4:00 … 20:00-24:00），日期仅写当天首行；储电量列写 00:00 / 24:00
  紧急购电量  每天 3 行，日期仅写当天首行
"""
import os, sys, io, copy
sys.stdout.reconfigure(encoding='utf-8', errors='replace')
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import numpy as np
import pandas as pd
import openpyxl
from common_q2 import (DT, NT, E_INIT, E_MIN, E_MAX, P_MAX, SAVE_START, OUT_DIR,
                       TPL_RESULT2, load_price, load_year)
from q2_forecast import build_forecast, rolling_sigma, solve_plan, execute_plan, summarize

EM_K = 5.0


def run_full(price, L, V, z, lag=7, ma=7, sig_win=60):
    Lp, Vp = build_forecast(L, V, lag, ma)
    sig = rolling_sigma(L, V, Lp, Vp, sig_win)
    soc = E_INIT
    recs = []
    for d in range(L.shape[0]):
        D = (Lp[d] - Vp[d]) * DT + z * sig[d] * DT
        Dpv = np.maximum(0.0, (Vp[d] - Lp[d]) * DT)
        P, ch_p, dis_p, curt_p, E_p = solve_plan(price, D, soc, Dpv)
        em, ch, dis, curt, E, soc = execute_plan(L[d], V[d], P, ch_p, dis_p, soc)
        soc = float(min(max(soc, E_MIN), E_MAX))
        recs.append(dict(P=P, ch=ch, dis=dis, curt=curt, em=em, E=E,
                         plan_cost=float((P * price).sum()),
                         em_cost=float((EM_K * price * em).sum())))
    return recs


def write_result2(recs, dates, path):
    idx = [i for i, d in enumerate(dates) if pd.Timestamp(d) >= SAVE_START]
    tpl = openpyxl.load_workbook(TPL_RESULT2)
    wb = openpyxl.Workbook()
    wb.remove(wb.active)

    # ---- 计划购电量 ----
    src = tpl['计划购电量']
    ws = wb.create_sheet('计划购电量')
    for c in range(1, src.max_column + 1):
        ws.cell(1, c).value = src.cell(1, c).value
    for r, i in enumerate(idx):
        ws.cell(r + 2, 1).value = pd.Timestamp(dates[i]).to_pydatetime()
        P = recs[i]['P']
        for t in range(NT):
            ws.cell(r + 2, 2 + t).value = round(float(P[t]), 4)
        ws.cell(r + 2, 146).value = round(float(P.sum()), 4)
        ws.cell(r + 2, 147).value = round(float(recs[i]['plan_cost'] + recs[i]['em_cost']), 4)

    # ---- 充放电量 ----
    src = tpl['充放电量']
    ws = wb.create_sheet('充放电量')
    for c in range(1, 7):
        ws.cell(1, c).value = src.cell(1, c).value
    r = 2
    for i in idx:
        ch, dis = recs[i]['ch'], recs[i]['dis']
        e0 = E_INIT if i == 0 else recs[idx[idx.index(i) - 1]]['E'][-1] if idx.index(i) > 0 else E_INIT
        # 上一保存日末值；跨过 1 月的第 1 天用上一天（i-1）的末值
        e0 = E_INIT if i == 0 else recs[i - 1]['E'][-1]
        ws.cell(r, 1).value = pd.Timestamp(dates[i]).to_pydatetime()
        for b in range(6):
            sl = slice(24 * b, 24 * b + 24)
            ws.cell(r + b, 2).value = '%d:00-%d:00' % (4 * b, 4 * (b + 1))
            ws.cell(r + b, 3).value = round(float(ch[sl].sum()), 4)
            ws.cell(r + b, 4).value = round(float(dis[sl].sum()), 4)
        ws.cell(r, 5).value = '00:00'
        ws.cell(r, 6).value = round(float(e0), 4)
        ws.cell(r + 1, 5).value = '24:00'
        ws.cell(r + 1, 6).value = round(float(recs[i]['E'][-1]), 4)
        r += 6

    # ---- 紧急购电量 ----
    src = tpl['紧急购电量']
    ws = wb.create_sheet('紧急购电量')
    for c in range(1, 4):
        ws.cell(1, c).value = src.cell(1, c).value

    def blocks(em, tol=1e-6):
        out, t = [], 0
        while t < NT:
            if em[t] > tol:
                s = t
                while t < NT and em[t] > tol:
                    t += 1
                out.append(('%d:%02d-%d:%02d' % (s // 6, s % 6 * 10, (t) // 6, (t) % 6 * 10),
                            float(em[s:t].sum())))
            else:
                t += 1
        return out

    r = 2
    for i in idx:
        bl = blocks(recs[i]['em'])
        ws.cell(r, 1).value = pd.Timestamp(dates[i]).to_pydatetime()
        if not bl:
            r += 1
            continue
        for k, (seg, q) in enumerate(bl):
            ws.cell(r + k, 2).value = seg
            ws.cell(r + k, 3).value = round(q, 4)
        r += max(1, len(bl))
    wb.save(path)
    return len(idx)


def main():
    price = load_price()
    dates, L = load_year('小区负载')
    _, V = load_year('光伏发电实际功率')
    z = 0.8416
    print('问题2 预测版（z=%.4f，负载 lag-7，光伏 ma7）' % z)
    recs = run_full(price, L, V, z)
    s = summarize(recs, dates)
    print('计划购电 %.0f kWh（%.2f 元）| 紧急 %.0f kWh（%.2f 元）| 总费用 %.2f 元'
          % (s['plan_kWh'], s['plan_cost'], s['em_kWh'], s['em_cost'], s['total_cost']))
    os.makedirs(OUT_DIR, exist_ok=True)
    path = os.path.join(OUT_DIR, 'result2.xlsx')
    n = write_result2(recs, dates, path)
    print('已写出 %s（%d 天）' % (path, n))


if __name__ == '__main__':
    main()
