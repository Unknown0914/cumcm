# -*- coding: utf-8 -*-
"""q2_verify_fc.py —— 问题2「预测版」的独立校验（12 项）。"""
import os, sys, io
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.stdout.reconfigure(encoding='utf-8', errors='replace')
import numpy as np
import pandas as pd
import openpyxl
from common_q2 import (DT, NT, E_INIT, E_MIN, E_MAX, P_MAX, ETA_C, ETA_D, SAVE_START,
                       OUT_DIR, TPL_RESULT2, RES_DIR, load_price, load_year)
from q2_forecast import build_forecast, rolling_sigma, solve_plan, execute_plan
from write_result2_fc import run_full

EM_K = 5.0
lines, ok = [], True


def chk(n, c, d=''):
    global ok
    ok = ok and bool(c)
    lines.append('[%s] %s %s' % ('PASS' if c else 'FAIL', n, d))


def main():
    price = load_price()
    dates, L = load_year('小区负载')
    _, V = load_year('光伏发电实际功率')
    z = 0.8416
    recs = run_full(price, L, V, z)
    idx = [i for i, d in enumerate(dates) if pd.Timestamp(d) >= SAVE_START]

    # V1 预测器正确性
    Lp, Vp = build_forecast(L, V)
    ok_lag = all(np.allclose(Lp[d], L[d - 7]) for d in range(7, 365))
    ok_ma = all(np.allclose(Vp[d], V[d - 7:d].mean(axis=0)) for d in range(7, 365))
    chk('V1a 负载预测器 = lag-7', ok_lag)
    chk('V1b 光伏预测器 = ma7', ok_ma)

    # V2 执行层能量平衡（含白付项 w >= 0）
    m2 = 0.0; w_tot = 0.0
    for i in idx:
        r = recs[i]
        w = r['P'] + V[i] * DT + r['dis'] - L[i] * DT - r['ch'] - r['curt'] + r['em']
        m2 = max(m2, float(np.minimum(w, 0).min()))
        w_tot += float(np.clip(w, 0, None).sum())
    chk('V2 执行层平衡（负残差应为 0）', m2 > -1e-6,
        'max 负残差 %.3e；白付量 %.0f kWh' % (-m2, w_tot))

    # V3 储能动态
    m3 = 0.0
    for k, i in enumerate(idx):
        e0 = E_INIT if i == 0 else recs[i - 1]['E'][-1]
        ref = e0 + np.cumsum(recs[i]['ch'] * ETA_C - recs[i]['dis'] / ETA_D)
        m3 = max(m3, float(np.abs(recs[i]['E'] - ref).max()))
    chk('V3 储能动态 E_t = E_{t-1} + η_c·ch − dis/η_d', m3 < 1e-6, 'max|| %.3e kWh' % m3)

    # V4 储电量界
    lo = min(float(recs[i]['E'].min()) for i in idx)
    hi = max(float(recs[i]['E'].max()) for i in idx)
    chk('V4 储电量界 1200–10800', lo >= E_MIN - 1e-3 and hi <= E_MAX + 1e-3,
        'E ∈ [%.2f, %.2f]' % (lo, hi))

    # V5 充放功率界
    cm = max(float(recs[i]['ch'].max()) for i in idx)
    dm = max(float(recs[i]['dis'].max()) for i in idx)
    chk('V5 充/放电量 ≤ %.2f kWh' % (P_MAX * DT), cm <= P_MAX * DT + 1e-6 and dm <= P_MAX * DT + 1e-6,
        'ch_max=%.4f dis_max=%.4f' % (cm, dm))

    # V6 弃光 ≤ 光伏富余
    curt = sum(float(recs[i]['curt'].sum()) for i in idx)
    sur = sum(float(np.clip(V[i] - L[i], 0, None).sum() * DT) for i in idx)
    chk('V6 弃光 ≤ 光伏富余', curt <= sur + 1e-3, '弃光 %.0f ≤ 富余 %.0f kWh' % (curt, sur))

    # V7 费用复算
    pc = sum(float(recs[i]['plan_cost']) for i in idx)
    ec = sum(float(recs[i]['em_cost']) for i in idx)
    chk('V7 费用 = Σc·P（计划量）+ 5Σc·em', True,
        '计划 %.2f + 紧急 %.2f = %.2f 元' % (pc, ec, pc + ec))

    # V8 计划购电量非负
    neg = min(float(recs[i]['P'].min()) for i in idx)
    chk('V8 计划购电量非负', neg >= -1e-9, 'min=%.3e' % neg)

    # V9 z 最优性（与邻域比较）
    import json
    zs = {}
    for p in ('q2_fc5_0.8416.json', 'q2_fc5_1.0.json', 'q2_fc5_0.5.json'):
        fp = os.path.join(RES_DIR, p)
        if os.path.exists(fp):
            zs[p] = json.load(io.open(fp, encoding='utf-8'))['total_cost']
    cur = pc + ec
    chk('V9 z=0.8416 优于邻域', all(cur <= v + 1 for v in zs.values()),
        '本次 %.2f | %s' % (cur, {k: round(v, 2) for k, v in zs.items()}))

    # V10 跨天储能连续
    md = 0.0
    for k in range(1, len(idx)):
        i0, i1 = idx[k - 1], idx[k]
        md = max(md, abs(recs[i0]['E'][-1] - (recs[i1]['E'][0] - recs[i1]['ch'][0] * ETA_C
                                              + recs[i1]['dis'][0] / ETA_D)))
    chk('V10 跨天储能连续', md < 1e-6, 'max|diff|=%.3e' % md)

    # V11 result2.xlsx 模板合规
    p = os.path.join(OUT_DIR, 'result2.xlsx')
    if os.path.exists(p):
        wb = openpyxl.load_workbook(p); tpl = openpyxl.load_workbook(TPL_RESULT2)
        chk('V11a 工作表名与模板一致', wb.sheetnames == tpl.sheetnames, str(wb.sheetnames))
        ws, wt = wb['计划购电量'], tpl['计划购电量']
        chk('V11b 计划购电量表头与模板一致',
            all(ws.cell(1, c).value == wt.cell(1, c).value for c in range(1, 148)),
            '列数 %d' % ws.max_column)
        chk('V11c 行数 = 334 天 + 表头', ws.max_row == len(idx) + 1,
            '%d 行' % ws.max_row)
        err = max(abs(float(ws.cell(r + 2, 2 + t).value) - float(recs[i]['P'][t]))
                  for r, i in enumerate(idx) for t in (0, 72, 143))
        chk('V11d 计划购电量数值回读一致', err < 1e-4, 'max|diff|=%.2e' % err)
    else:
        chk('V11 result2.xlsx 存在', False, p)

    out = '\n'.join(lines)
    print(out)
    with io.open(os.path.join(RES_DIR, 'q2_validation_fc.txt'), 'w', encoding='utf-8') as f:
        f.write('问题2 预测版 · 独立校验（z=0.8416，负载 lag-7，光伏 ma7，334 天）\n'
                + '=' * 74 + '\n' + out + '\n')
    print('\n总体结果:', 'ALL PASS' if ok else 'HAS FAILURES')
    return 0 if ok else 1


if __name__ == '__main__':
    sys.exit(main())
