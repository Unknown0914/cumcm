# -*- coding: utf-8 -*-
"""
q2_model.py —— 问题2 单日线性规划模型（可全年复用）

模型（第 d 天，t = 1..144，Δt = 1/6 h）：

  min  Σ_t c_t (b_t + 5·em_t) Δt
  s.t.
    (1) 功率平衡   b_t + em_t + (v_t - u_t) + f_t = L_t + g_t
    (2) 储能动态   E_t = E_{t-1} + η_c g_t Δt - f_t Δt / η_d ,   E_0 = given
    (3) 储电量界   1200 ≤ E_t ≤ 10800
    (4) 功率界     0 ≤ g_t, f_t ≤ 5000 ;  b_t, em_t ≥ 0 ;  0 ≤ u_t ≤ v_t
    (5) 口径开关   day_cycle=True 时追加 E_144 = E_0（日循环）；默认 False（跨天连续）

符号：b 计划购电、em 紧急购电、g 充电、f 放电、u 弃光、E 储电量。

对 DeepSeek 原方案的修正：
  R1 删除其 A_ub 中符号写反的"放电后不低于 Emin"约束（该约束要求
     f_t ≥ (E_{t-1}+1200)·0.9/Δt ≈ 38880 kW，与 0 ≤ f_t ≤ 5000 冲突，导致不可行）；
     储电量下界本就由 E_t 的 bounds 保证，该条纯属冗余。
  R2 引入弃光变量 u_t —— 全年 330 天存在光伏富余（单日最大 33 415 kWh，
     远超储能可吸收量 η_c(E_max-E_min)=8640 kWh），无弃光通道时模型必然不可行。
  R3 目标函数与紧急购电机制按原方案保留（5 倍电价惩罚）。
"""
import numpy as np
from scipy.optimize import linprog

from common_q2 import DT, NT, E_MIN, E_MAX, P_MAX, ETA_C, ETA_D

# 变量分块起始偏移
IDX_B, IDX_EM, IDX_G, IDX_F, IDX_U, IDX_E = 0, NT, 2 * NT, 3 * NT, 4 * NT, 5 * NT
NVAR = 6 * NT                      # 864
NROW_EQ = 2 * NT                   # 288（平衡 + 动态）
NROW_EQ_CYCLE = NROW_EQ + 1        # 289（含日循环）


class Q2Solver:
    """预构建 LP 结构、按日复用（每天只有 b_eq 的负载/光伏与初始电量变化）。"""

    def __init__(self, price, eta_c=ETA_C, eta_d=ETA_D, p_max=P_MAX,
                 e_min=E_MIN, e_max=E_MAX, buy_max=None,
                 em_penalty=5.0, allow_curtail=True):
        self.price = np.asarray(price, float)
        self.eta_c, self.eta_d = eta_c, eta_d
        self.p_max, self.e_min, self.e_max = p_max, e_min, e_max
        self.buy_max = buy_max
        self.em_penalty = em_penalty
        self.allow_curtail = allow_curtail
        self.T = len(self.price)
        assert self.T == NT

        # ---- 目标 ----
        self.c_obj = np.zeros(NVAR)
        self.c_obj[IDX_B:IDX_B + NT] = self.price * DT
        self.c_obj[IDX_EM:IDX_EM + NT] = em_penalty * self.price * DT

        # ---- 等式结构（与日期无关）----
        A = np.zeros((NROW_EQ_CYCLE, NVAR))
        for t in range(NT):            # 平衡: b + em - u + f - g = L - v
            A[t, IDX_B + t] = 1.0
            A[t, IDX_EM + t] = 1.0
            A[t, IDX_U + t] = -1.0
            A[t, IDX_F + t] = 1.0
            A[t, IDX_G + t] = -1.0
        for t in range(NT):            # 动态: E_t - E_{t-1} - η_c g Δt + f Δt/η_d = [E0]
            r = NT + t
            A[r, IDX_E + t] = 1.0
            if t > 0:
                A[r, IDX_E + t - 1] = -1.0
            A[r, IDX_G + t] = -eta_c * DT
            A[r, IDX_F + t] = DT / eta_d
        A[NROW_EQ, IDX_E + NT - 1] = 1.0          # 日循环: E_144 = E0（第 289 行）
        self.A_eq = A

        # ---- bounds（与日期无关）----
        self.bounds = (
            [(0.0, buy_max)] * NT                                   # b 计划购电
            + [(0.0, None)] * NT                                    # em 紧急购电
            + [(0.0, p_max)] * NT                                   # g 充电
            + [(0.0, p_max)] * NT                                   # f 放电
            + [(0.0, None)] * NT                                    # u 弃光（上界逐日按 v_t 设定）
            + [(e_min, e_max)] * NT                                 # E 储电量
        )

    def solve_day(self, load, pv, E0, day_cycle=False):
        """求解单日 LP，返回该日各项决策量（功率数组、kWh 数组）与统计。"""
        load = np.asarray(load, float)
        pv = np.asarray(pv, float)
        bounds = list(self.bounds)
        # 弃光上界按当日光伏设定
        uub = pv if self.allow_curtail else np.zeros(NT)
        bounds[IDX_U:IDX_U + NT] = [(0.0, float(uub[t])) for t in range(NT)]

        b_eq = np.zeros(NROW_EQ_CYCLE)
        b_eq[:NT] = load - pv
        b_eq[NT] = E0                       # 动态第一行的右端 = 当天 0:00 储电量
        b_eq[NROW_EQ] = E0                  # 日循环：E_144 = E0

        A_eq = self.A_eq[:NROW_EQ_CYCLE] if day_cycle else self.A_eq[:NROW_EQ]
        beq = b_eq[:NROW_EQ_CYCLE] if day_cycle else b_eq[:NROW_EQ]

        res = linprog(self.c_obj, A_eq=A_eq, b_eq=beq, bounds=bounds, method='highs')
        if not res.success:
            return {'success': False, 'message': res.message}
        x = res.x
        out = {
            'success': True,
            'buy_kW': x[IDX_B:IDX_B + NT],
            'em_kW': x[IDX_EM:IDX_EM + NT],
            'ch_kW': x[IDX_G:IDX_G + NT],
            'dis_kW': x[IDX_F:IDX_F + NT],
            'curtail_kW': x[IDX_U:IDX_U + NT],
            'E_kWh': x[IDX_E:IDX_E + NT],
        }
        for k in ('buy', 'em', 'ch', 'dis', 'curtail'):
            out[k + '_kWh'] = out[k + '_kW'] * DT
        out['plan_cost'] = float((self.price * out['buy_kW'] * DT).sum())
        out['em_cost'] = float((self.price * out['em_kW'] * DT).sum() * self.em_penalty)
        out['total_cost'] = out['plan_cost'] + out['em_cost']
        out['plan_buy_kWh'] = float(out['buy_kWh'].sum())
        out['em_buy_kWh'] = float(out['em_kWh'].sum())
        out['ch_kWh_sum'] = float(out['ch_kWh'].sum())
        out['dis_kWh_sum'] = float(out['dis_kWh'].sum())
        out['curtail_kWh_sum'] = float(out['curtail_kWh'].sum())
        out['E0'] = float(E0)
        out['E_T'] = float(out['E_kWh'][-1])
        return out


if __name__ == '__main__':
    import sys, io
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
    from common_q2 import load_all
    price, dates, load, pv = load_all()
    s = Q2Solver(price)
    r = s.solve_day(load[0], pv[0], 6000.0)
    print('第 1 天 (%s) 求解:', dates[0])
    print('  success =', r['success'])
    print('  计划购电量 %.4f kWh，紧急购电量 %.4f kWh，弃光 %.4f kWh'
          % (r['plan_buy_kWh'], r['em_buy_kWh'], r['curtail_kWh_sum']))
    print('  充电 %.4f kWh，放电 %.4f kWh，末储电量 %.4f kWh'
          % (r['ch_kWh_sum'], r['dis_kWh_sum'], r['E_T']))
    print('  总费用 %.4f 元' % r['total_cost'])
