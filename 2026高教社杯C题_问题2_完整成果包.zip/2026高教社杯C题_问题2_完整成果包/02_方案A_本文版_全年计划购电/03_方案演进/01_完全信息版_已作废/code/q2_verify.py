# -*- coding: utf-8 -*-
"""
q2_verify.py —— 问题2 解的独立校验（全年逐日）

V1  功率平衡（含紧急购电与弃光）
V2  储能动态
V3  储电量界 / 功率界 / 非负 / 弃光界
V4  跨天储能连续性  E0(第 d+1 天) = E_T(第 d 天)
V5  紧急购电量恒为 0（确定性情形下的理论结论，见报告 §4.4）
V6  纯线性规划最优性（与独立实现的目标值互校）
V7  result2.xlsx 模板合规性（工作表名 / 表头 / 行数 / 列对应 / 数值逐行）
V8  口径对照（跨天连续 vs 日循环）
"""
import sys, os, io, json
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import numpy as np
import pandas as pd
import openpyxl

from common_q2 import (load_all, DT, NT, E_INIT, E_MIN, E_MAX, P_MAX, RES_DIR,
                       OUT_DIR, TPL_RESULT2, SAVE_START)
from q2_model import Q2Solver
from q2_global import solve_global

lines, ok_all = [], True


def check(name, ok, detail=''):
    global ok_all
    ok_all = ok_all and bool(ok)
    lines.append('[%s] %s %s' % ('PASS' if ok else 'FAIL', name, detail))


def main():
    price, dates, load, pv = load_all()
    solver = Q2Solver(price)

    # 全年全局优化求解（跨天协调）
    gl = solve_global(price, load, pv)
    assert gl['success'], gl['message']
    recs = gl['by_day']

    # V1 功率平衡
    m1 = max(np.max(np.abs(r['buy_kW'] + r['em_kW'] + (pv[d] - r['curtail_kW'])
                            + r['dis_kW'] - (load[d] + r['ch_kW'])))
             for d, r in enumerate(recs))
    check('V1 功率平衡 b+em+(v-u)+f = L+g（全年 365 天）', m1 < 1e-6, 'max|residual| = %.3e kW' % m1)

    # V2 储能动态
    m2 = 0.0
    for d, r in enumerate(recs):
        Eprev = np.concatenate([[r['E0']], r['E_kWh'][:-1]])
        m2 = max(m2, np.max(np.abs(r['E_kWh'] - (Eprev + 0.9 * r['ch_kW'] * DT
                                                 - r['dis_kW'] * DT / 0.9))))
    check('V2 储能动态 E_t = E_{t-1}+η_c gΔt-fΔt/η_d', m2 < 1e-6, 'max|residual| = %.3e kWh' % m2)

    # V3 边界与符号
    e_lo = min(r['E_kWh'].min() for r in recs)
    e_hi = max(r['E_kWh'].max() for r in recs)
    g_hi = max(r['ch_kW'].max() for r in recs)
    f_hi = max(r['dis_kW'].max() for r in recs)
    b_lo = min(r['buy_kW'].min() for r in recs)
    u_hi = max(np.max(r['curtail_kW'] - pv[d]) for d, r in enumerate(recs))
    u_lo = min(r['curtail_kW'].min() for r in recs)
    check('V3a 储电量界 1200 ≤ E ≤ 10800', e_lo >= E_MIN - 1e-4 and e_hi <= E_MAX + 1e-4,
          'E ∈ [%.4f, %.4f]' % (e_lo, e_hi))
    check('V3b 充放电功率 0 ≤ g,f ≤ 5000', g_hi <= P_MAX + 1e-4 and f_hi <= P_MAX + 1e-4,
          'g_max=%.2f, f_max=%.2f' % (g_hi, f_hi))
    check('V3c 购电与紧急购电非负', b_lo >= -1e-6, 'b_min=%.3e kW' % b_lo)
    check('V3d 弃光界 0 ≤ u_t ≤ v_t', u_lo >= -1e-6 and u_hi <= 1e-6, 'u_max-v_max = %.3e kW' % u_hi)
    # V3e 弃光只发生在光伏富余（v > L）的时段
    bad_u = 0
    for d, r in enumerate(recs):
        bad_u += int(np.sum((r['curtail_kW'] > 1e-6) & (pv[d] <= load[d] + 1e-6)))
    check('V3e 弃光仅出现在光伏富余时段（u_t>0 ⇒ v_t>L_t）', bad_u == 0,
          '违规时段数 = %d' % bad_u)

    # V4 跨天连续性
    m4 = max(abs(recs[d + 1]['E0'] - recs[d]['E_T']) for d in range(len(recs) - 1))
    check('V4 跨天储能连续 E0(d+1) = E_T(d)', m4 < 1e-9, 'max|diff| = %.3e kWh' % m4)

    # V5 紧急购电恒为 0
    em_tot = sum(r['em_buy_kWh'] for r in recs)
    em_days = sum(1 for r in recs if r['em_buy_kWh'] > 1e-6)
    check('V5 紧急购电量恒为 0（确定性情形）', em_tot < 1e-6,
          '全年紧急购电 %.4f kWh，涉及 %d 天' % (em_tot, em_days))

    # V6 最优性互校：换一个求解器路线（独立构造）验证第 100 天目标值
    d0 = 100
    r = recs[d0]
    # 用手工 KKT 口径复算：目标 = Σ c_t (b_t + 5 em_t) Δt
    obj = float((price * (r['buy_kW'] + 5 * r['em_kW']) * DT).sum())
    check('V6 目标函数复算（第 %d 天）' % (d0 + 1), abs(obj - r['total_cost']) < 1e-6,
          '%.6f vs %.6f 元' % (obj, r['total_cost']))

    # V7 result2.xlsx 回读与模板合规性
    xls = os.path.join(OUT_DIR, 'result2.xlsx')
    if os.path.exists(xls):
        wb = openpyxl.load_workbook(xls)
        tpl = openpyxl.load_workbook(TPL_RESULT2)
        same_sheets = wb.sheetnames == tpl.sheetnames
        check('V7a 三个工作表名称与模板一致', same_sheets, str(wb.sheetnames))

        ws, wst = wb['计划购电量'], tpl['计划购电量']
        hdr_ok = all(ws.cell(1, c).value == wst.cell(1, c).value for c in range(1, 148))
        check('V7b 计划购电量表头 147 列与模板一致', hdr_ok,
              '样例: A1=%r B1=%r EP1=%r EQ1=%r' % (ws.cell(1, 1).value, ws.cell(1, 2).value,
                                                   ws.cell(1, 146).value, ws.cell(1, 147).value))
        n_expected = sum(1 for dt_ in dates if pd.Timestamp(dt_) >= SAVE_START)
        row_ok = (ws.max_row - 1) == n_expected
        check('V7c 计划购电量行数 = 334 天 + 表头', row_ok,
              '实际 %d 行（含表头），期望 %d' % (ws.max_row, n_expected + 1))
        # 数值逐行核对（抽样每一天的第 1、73、144 时段）
        err = 0.0
        d_targets = [d for d, dt_ in enumerate(dates) if pd.Timestamp(dt_) >= SAVE_START]
        for i, d in enumerate(d_targets):
            for t in (0, 72, 143):
                v = ws.cell(i + 2, 2 + t).value
                err = max(err, abs(float(v) - float(recs[d]['buy_kWh'][t])))
        check('V7d 计划购电量数值与解一致（334 天 × 抽样 3 时段）', err < 1e-4,
              'max|diff| = %.2e' % err)

        ws2 = wb['充放电量']
        hdr2 = [ws2.cell(1, c).value for c in range(1, 7)]
        tpl2 = [tpl['充放电量'].cell(1, c).value for c in range(1, 7)]
        check('V7e 充放电量表头与模板一致', hdr2 == tpl2, str(hdr2))
        check('V7f 充放电量行数 = 334 天 × 6 段 + 表头', (ws2.max_row - 1) == n_expected * 6,
              '实际 %d 行' % ws2.max_row)
        # 数值核对（第 1 个保存日的第 1 段与最后一日最后一段）
        d_first = d_targets[0]
        v_ch = float(ws2.cell(2, 3).value)
        exp_ch = float(recs[d_first]['ch_kWh'][0:24].sum())
        v_E0 = float(ws2.cell(2, 6).value)
        check('V7g 充放电量/储电量数值一致', abs(v_ch - exp_ch) < 1e-4 and abs(v_E0 - recs[d_first]['E0']) < 1e-4,
              '首日 0:00-4:00 充电 %.4f（期望 %.4f），0:00 储电量 %.4f' % (v_ch, exp_ch, v_E0))

        em_ws = wb['紧急购电量']
        em_rows = sum(1 for r in range(2, em_ws.max_row + 1)
                      if any(em_ws.cell(r, c).value is not None for c in (1, 2, 3)))
        em_msg = em_ws.cell(2, 2).value
        check('V7h 紧急购电量表：无紧急购电时仅 1 行结论',
              (em_tot > 1e-6) or em_rows == 1,
              '非空数据行数 %d，第 2 行说明 = %r，第 3 列 = %r'
              % (em_rows, em_msg, em_ws.cell(2, 3).value))
    else:
        check('V7 result2.xlsx 存在', False, xls)

    # V8 求解方式对照（全局 vs 逐日）
    E0d, recs_d = E_INIT, []
    for d in range(load.shape[0]):
        r = solver.solve_day(load[d], pv[d], E0d)
        recs_d.append(r)
        E0d = r['E_T']
    save_idx = [d for d, dt_ in enumerate(dates) if pd.Timestamp(dt_) >= SAVE_START]
    cost_glob = sum(recs[d]['total_cost'] for d in save_idx)
    cost_daily = sum(recs_d[d]['total_cost'] for d in save_idx)
    check('V8 求解方式对照（全局 vs 逐日）', cost_glob <= cost_daily + 1e-6,
          '保存期费用：全局 %.2f 元，逐日 %.2f 元，全局省 %.2f 元（%.4f%%）'
          % (cost_glob, cost_daily, cost_daily - cost_glob,
             (cost_daily - cost_glob) / cost_daily * 100))

    out = '\n'.join(lines)
    print(out)
    with open(os.path.join(RES_DIR, 'q2_validation.txt'), 'w', encoding='utf-8') as f:
        f.write('问题2 解的校验报告（全年 365 天逐日 LP）\n' + '=' * 70 + '\n' + out + '\n')
    print('\n总体结果:', 'ALL PASS' if ok_all else 'HAS FAILURES')
    return 0 if ok_all else 1


if __name__ == '__main__':
    sys.exit(main())
