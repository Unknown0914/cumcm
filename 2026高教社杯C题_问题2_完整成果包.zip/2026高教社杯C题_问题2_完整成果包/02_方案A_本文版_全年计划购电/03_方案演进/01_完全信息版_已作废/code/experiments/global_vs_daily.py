# -*- coding: utf-8 -*-
"""
global_vs_daily.py —— 检验"逐日近视优化"相对"全年全局优化"的损失

背景：逐日优化（每天末值自由）会让储能在每天结束时回到下界 1200 kWh，
      等价于把当天存量"清空"。但题目给出的附件 2 包含全年数据，
      从全年最优的角度看，储能应当跨天搬运（今天的光伏富余留到明天用），
      这需要把全年 365×144 个时段放在同一个 LP 里一起优化。

用法：
    python global_vs_daily.py --days 60
    python global_vs_daily.py --days 365
"""
import sys, os, io, argparse, time
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, '..', 'code'))
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

import numpy as np
from scipy.sparse import coo_matrix
from scipy.optimize import linprog
from common_q2 import load_all, DT, NT, E_INIT, E_MIN, E_MAX, P_MAX
from q2_model import Q2Solver


def global_lp(price, load, pv, days, e_end=None, time_limit=None):
    """全年（days 天）一次性优化的全局 LP。

    变量排布 [b(N), em(N), g(N), f(N), u(N), E(N)]，N = days*144；
    储电量 E 按全局时序展平，故跨天连续约束自动满足（E[i] 的前驱即 E[i-1]）。
    """
    T = NT
    N = T * days
    nv = 6 * N
    B, EM, G, F, U, E = 0, N, 2 * N, 3 * N, 4 * N, 5 * N
    lv = np.asarray(load[:days], float).ravel()
    vv = np.asarray(pv[:days], float).ravel()
    pr = np.tile(np.asarray(price, float), days)

    nr = 2 * N + (1 if e_end is not None else 0)
    rows, cols, vals = [], [], []
    beq = np.zeros(nr)
    for i in range(N):
        r = i                                    # 平衡
        rows += [r, r, r, r, r]
        cols += [B + i, EM + i, U + i, F + i, G + i]
        vals += [1.0, 1.0, -1.0, 1.0, -1.0]
        beq[r] = lv[i] - vv[i]
        r = N + i                                # 储能动态
        rows += [r, r, r]
        cols += [E + i, G + i, F + i]
        vals += [1.0, -0.9 * DT, DT / 0.9]
        if i > 0:
            rows.append(r); cols.append(E + i - 1); vals.append(-1.0)
        beq[r] = E_INIT if i == 0 else 0.0
    if e_end is not None:
        rows.append(2 * N); cols.append(E + N - 1); vals.append(1.0)
        beq[2 * N] = float(e_end)

    A = coo_matrix((vals, (rows, cols)), shape=(nr, nv)).tocsr()
    c = np.zeros(nv)
    c[B:B + N] = pr * DT
    c[EM:EM + N] = 5 * pr * DT
    bounds = ([(0.0, None)] * N + [(0.0, None)] * N
              + [(0.0, P_MAX)] * N + [(0.0, P_MAX)] * N
              + [(0.0, float(vv[i])) for i in range(N)]
              + [(E_MIN, E_MAX)] * N)
    opts = {'time_limit': time_limit, 'presolve': True} if time_limit else None
    t0 = time.time()
    res = linprog(c, A_eq=A, b_eq=beq, bounds=bounds, method='highs', options=opts)
    return res, time.time() - t0, N


def daily_lp(price, load, pv, days):
    """逐日优化（末值自由、跨天传递）作为对照。"""
    solver = Q2Solver(price)
    E0 = E_INIT
    cost = cur = em = buy = 0.0
    ch = dis = 0.0
    for d in range(days):
        r = solver.solve_day(load[d], pv[d], E0)
        assert r['success'], d
        E0 = r['E_T']
        cost += r['total_cost']; cur += r['curtail_kWh_sum']; em += r['em_buy_kWh']
        buy += r['plan_buy_kWh']; ch += r['ch_kWh_sum']; dis += r['dis_kWh_sum']
    return dict(cost=cost, curtail=cur, em=em, buy=buy, ch=ch, dis=dis)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--days', type=int, default=60)
    ap.add_argument('--e-end', type=float, default=None,
                    help='可选：要求最后一天 24:00 的储电量等于该值')
    ap.add_argument('--time-limit', type=float, default=None)
    args = ap.parse_args()

    price, dates, load, pv = load_all()
    days = args.days
    print('对比区间：%s ~ %s，共 %d 天' %
          (str(dates[0])[:10], str(dates[days - 1])[:10], days))

    dl = daily_lp(price, load, pv, days)
    print('\n[逐日优化]  总费用 %.2f 元 | 购电 %.2f kWh | 弃光 %.2f kWh | 紧急购电 %.2f kWh'
          % (dl['cost'], dl['buy'], dl['curtail'], dl['em']))

    res, el, N = global_lp(price, load, pv, days, e_end=args.e_end,
                           time_limit=args.time_limit)
    print('\n[全局优化]  变量数 %d，求解 %.1f 秒，状态=%s' % (6 * N, el, res.status))
    if not res.success:
        print('  求解未成功：', res.message)
        return
    x = res.x
    B, EM, U, F, G, E = 0, N, 4 * N, 3 * N, 2 * N, 5 * N
    b = x[B:B + N]; em = x[EM:EM + N]; u = x[U:U + N]
    f = x[F:F + N]; g = x[G:G + N]; Ev = x[E:E + N]
    pr = np.tile(price, days)
    vv = np.asarray(pv[:days], float).ravel()
    gc = float((pr * (b + 5 * em) * DT).sum())
    print('            总费用 %.2f 元 | 购电 %.2f kWh | 弃光 %.2f kWh | 紧急购电 %.2f kWh'
          % (gc, b.sum() * DT, u.sum() * DT, em.sum() * DT))
    print('            储能充电 %.2f kWh，放电 %.2f kWh，E 范围 [%.1f, %.1f]，末值 %.1f'
          % (g.sum() * DT, f.sum() * DT, Ev.min(), Ev.max(), Ev[-1]))
    print('\n【差异】全局比逐日省 %.2f 元（%.4f%%），弃光少 %.2f kWh（%.2f%%）'
          % (dl['cost'] - gc, (dl['cost'] - gc) / dl['cost'] * 100,
             dl['curtail'] - u.sum() * DT,
             (dl['curtail'] - u.sum() * DT) / dl['curtail'] * 100 if dl['curtail'] else 0))


if __name__ == '__main__':
    main()
