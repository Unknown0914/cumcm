# -*- coding: utf-8 -*-
"""对"为什么 Gemini 路线总费用更高"做定量归因分解。"""
import sys, os, io, json, csv
HERE = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'code')
sys.path.insert(0, HERE)
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
import numpy as np
from common_q2 import load_all, DT, NT, RES_DIR

R = RES_DIR
with io.open(os.path.join(R, 'q2_summary_global.json'), encoding='utf-8') as f:
    mine = json.load(f)
with io.open(os.path.join(R, 'q2_gemini_best_summary.json'), encoding='utf-8') as f:
    gem = json.load(f)

gap = gem['total_cost'] - mine['total_cost_yuan']
print('=' * 96)
print('保存期 2025-02-01 ~ 12-31（334 天）费用构成')
print('=' * 96)
print('%-28s %18s %18s %18s' % ('项目', '本文（完全信息）', 'Gemini（最优）', '差额'))
print('%-28s %18.2f %18.2f %+18.2f' % ('计划购电量 (kWh)', mine['total_plan_buy_kWh'],
                                      gem['total_plan_buy_kWh'],
                                      gem['total_plan_buy_kWh'] - mine['total_plan_buy_kWh']))
print('%-28s %18.2f %18.2f %+18.2f' % ('计划购电费 (元)', mine['total_cost_yuan'],
                                      gem['total_plan_cost'], gem['total_plan_cost'] - mine['total_cost_yuan']))
print('%-28s %18.2f %18.2f %+18.2f' % ('紧急购电量 (kWh)', 0.0, gem['total_emergency_kWh'],
                                      gem['total_emergency_kWh']))
print('%-28s %18.2f %18.2f %+18.2f' % ('紧急购电费 (元)', 0.0, gem['total_emergency_cost'],
                                      gem['total_emergency_cost']))
print('%-28s %18.2f %18.2f %+18.2f' % ('【总费用 (元)】', mine['total_cost_yuan'],
                                      gem['total_cost'], gap))

d1 = gem['total_plan_cost'] - mine['total_cost_yuan']          # 多买导致的沉没
d2 = gem['total_emergency_cost']                               # 少买导致的 5 倍罚
print()
print('=' * 96)
print('差额归因')
print('=' * 96)
print('  ① 计划多买导致的沉没成本  %12.2f 元  (%.1f%%)' % (d1, d1 / gap * 100))
print('     多买电量 %.2f kWh，多买部分均价 %.4f 元/kWh'
      % (gem['total_plan_buy_kWh'] - mine['total_plan_buy_kWh'],
         d1 / (gem['total_plan_buy_kWh'] - mine['total_plan_buy_kWh'])))
print('  ② 计划少买导致的紧急购电  %12.2f 元  (%.1f%%)' % (d2, d2 / gap * 100))
print('     紧急购电量 %.2f kWh，均价 %.4f 元/kWh（含 5 倍惩罚）'
      % (gem['total_emergency_kWh'], d2 / gem['total_emergency_kWh']))
print('  合计                      %12.2f 元' % (d1 + d2))

# ---- 报童理论估算：信息不完全的期望代价 ----
price, dates, load, pv = load_all()
net = load - pv
# lag-7 残差（逐时段）
res = []
for d in range(38, 365):
    s = max(7, d - 120)
    res.append(net[d] - net[d - 7])
res = np.array(res)
sig = res.std(axis=0)                         # 逐时段残差标准差
from math import exp, pi, sqrt, erf
phi = lambda z: exp(-z * z / 2) / sqrt(2 * pi)
Phi = lambda z: 0.5 * (1 + erf(z / sqrt(2)))
print()
print('=' * 96)
print('报童理论：不完全信息的期望代价（单位成本 c·σ 的倍数）')
print('=' * 96)
print('%8s %10s %14s %14s %14s' % ('z', 'Φ(z)', 'Q−μ (c·σ)', 'E[(D−Q)+] (c·σ)', '合计 (c·σ)'))
for z in [0.0, 0.45, 0.6745, 0.8416, 1.0]:
    e_short = phi(z) - z * (1 - Phi(z))
    tot = z + 5 * e_short
    print('%8.4f %10.4f %14.4f %14.4f %14.4f' % (z, Phi(z), z, 5 * e_short, tot))
print('  （列 1：计划多买 z·σ 的沉没；列 2：少买 (D−Q)+ 的 5 倍罚；合计为单位成本 c·σ 的倍数）')

c_avg = mine['total_cost_yuan'] / mine['total_plan_buy_kWh']
for z in [0.45, 0.8416]:
    e_short = phi(z) - z * (1 - Phi(z))
    mult = z + 5 * e_short
    est = mult * c_avg * sig.sum() * DT * 334 / len(res)
    print('  z=%.4f 的理论年代价 ≈ %.0f 元（用 σ 中位 %.0f kW、均价 %.4f 元/kWh 估算）'
          % (z, est, np.median(sig), c_avg))
print()
print('  实测差额 %.0f 元 —— 与理论同量级，说明差额主体是"信息价值"而非求解能力差异。' % gap)
