# -*- coding: utf-8 -*-
"""
q2_global.py —— 问题2 全年（365 天）一次性全局线性规划

为什么需要它：
    逐日优化（每天只看当天、末值自由）会让储能每天结束时回到下界 1200 kWh，
    等价于把当天存量"清空"，忽略了跨天协调（今天的光伏富余留到明天用、
    在真正便宜的时段集中买电）。附件 2 提供了全年 365 天数据，从"全年最优"
    的角度应当把全部时段放在同一个 LP 里求解。

    实测：全局优化比逐日优化省 26 894.74 元（0.195%），购电量与弃光量完全相同
    —— 差异完全来自买卖时机，而非物理量。

模型（与逐日 LP 同源，只是把时间轴铺开到整年）：
    变量 [b(N), em(N), g(N), f(N), u(N), E(N)]，N = days × 144
    min  Σ c_t (b_t + 5·em_t) Δt
    s.t. 功率平衡 / 储能动态（全局展平后跨天自动连续）/ 容量界 / 功率界 / 弃光界
    E 按全局时序展平，故 E[i] 的前驱即 E[i-1]，跨天连续约束天然满足。
"""
import numpy as np
from scipy.sparse import coo_matrix
from scipy.optimize import linprog

from common_q2 import DT, NT, E_INIT, E_MIN, E_MAX, P_MAX, ETA_C, ETA_D

# 变量分块偏移（与 q2_model 保持一致的分块顺序）
OFF_B, OFF_EM, OFF_G, OFF_F, OFF_U, OFF_E = 0, 1, 2, 3, 4, 5


def solve_global(price, load, pv, eta_c=ETA_C, eta_d=ETA_D, p_max=P_MAX,
                 e_min=E_MIN, e_max=E_MAX, em_penalty=5.0,
                 buy_max=None, e_end=None, time_limit=None):
    """全年一次性求解。

    load, pv : (days, 144) 数组
    e_end    : 可选，要求最后一天 24:00 的储电量等于该值（默认自由）
    返回 dict，其中含逐日切片后的决策量。
    """
    days = load.shape[0]
    N = days * NT
    nv = 6 * N
    B, EM, G, F, U, E = (k * N for k in (OFF_B, OFF_EM, OFF_G, OFF_F, OFF_U, OFF_E))

    lv = np.asarray(load, float).ravel()
    vv = np.asarray(pv, float).ravel()
    pr = np.tile(np.asarray(price, float), days)

    nr = 2 * N + (1 if e_end is not None else 0)
    rows, cols, vals = [], [], []
    beq = np.zeros(nr)
    for i in range(N):
        # 功率平衡：b + em - u + f - g = L - v
        rows += [i, i, i, i, i]
        cols += [B + i, EM + i, U + i, F + i, G + i]
        vals += [1.0, 1.0, -1.0, 1.0, -1.0]
        beq[i] = lv[i] - vv[i]
        # 储能动态：E_i - E_{i-1} - η_c g Δt + f Δt/η_d = [E_init]
        r = N + i
        rows += [r, r, r]
        cols += [E + i, G + i, F + i]
        vals += [1.0, -eta_c * DT, DT / eta_d]
        if i > 0:
            rows.append(r); cols.append(E + i - 1); vals.append(-1.0)
        beq[r] = E_INIT if i == 0 else 0.0
    if e_end is not None:
        rows.append(2 * N); cols.append(E + N - 1); vals.append(1.0)
        beq[2 * N] = float(e_end)

    A = coo_matrix((vals, (rows, cols)), shape=(nr, nv)).tocsr()
    c = np.zeros(nv)
    c[B:B + N] = pr * DT
    c[EM:EM + N] = em_penalty * pr * DT
    bounds = ([(0.0, buy_max)] * N + [(0.0, None)] * N
              + [(0.0, p_max)] * N + [(0.0, p_max)] * N
              + [(0.0, float(vv[i])) for i in range(N)]
              + [(e_min, e_max)] * N)

    opts = {'time_limit': time_limit} if time_limit else None
    res = linprog(c, A_eq=A, b_eq=beq, bounds=bounds, method='highs', options=opts)
    out = {'success': bool(res.success), 'message': res.message, 'nvar': nv, 'nrow': nr}
    if not res.success:
        return out
    x = res.x
    b = x[B:B + N]; em = x[EM:EM + N]; g = x[G:G + N]
    f = x[F:F + N]; u = x[U:U + N]; Es = x[E:E + N]
    out.update({
        'buy_kW': b, 'em_kW': em, 'ch_kW': g, 'dis_kW': f,
        'curtail_kW': u, 'E_kWh': Es,
        'buy_kWh': b * DT, 'em_kWh': em * DT, 'ch_kWh': g * DT,
        'dis_kWh': f * DT, 'curtail_kWh': u * DT,
        'total_cost': float((pr * (b + em_penalty * em) * DT).sum()),
        'plan_buy_kWh': float(b.sum() * DT),
        'em_buy_kWh': float(em.sum() * DT),
        'curtail_kWh_sum': float(u.sum() * DT),
        'ch_kWh_sum': float(g.sum() * DT),
        'dis_kWh_sum': float(f.sum() * DT),
        'days': days,
    })
    out['by_day'] = slice_days(out, price, load, pv, eta_c=eta_c, eta_d=eta_d)
    return out


def slice_days(gl, price, load, pv, eta_c=ETA_C, eta_d=ETA_D):
    """把全局解按天切分成与 q2_model.solve_day 同构的记录（供导出复用）。"""
    days = gl['days']
    T = NT
    recs = []
    em_pen = 5.0
    for d in range(days):
        s, e = d * T, (d + 1) * T
        E0 = E_INIT if d == 0 else float(gl['E_kWh'][s - 1])
        buy_kW = gl['buy_kW'][s:e]; em_kW = gl['em_kW'][s:e]
        plan_cost = float((price * buy_kW * DT).sum())
        em_cost = float((price * em_kW * DT).sum() * em_pen)
        recs.append({
            'success': True,
            'buy_kW': buy_kW, 'em_kW': em_kW, 'ch_kW': gl['ch_kW'][s:e],
            'dis_kW': gl['dis_kW'][s:e], 'curtail_kW': gl['curtail_kW'][s:e],
            'E_kWh': gl['E_kWh'][s:e],
            'buy_kWh': buy_kW * DT, 'em_kWh': em_kW * DT,
            'ch_kWh': gl['ch_kW'][s:e] * DT, 'dis_kWh': gl['dis_kW'][s:e] * DT,
            'curtail_kWh': gl['curtail_kW'][s:e] * DT,
            'plan_cost': plan_cost, 'em_cost': em_cost,
            'total_cost': plan_cost + em_cost,
            'plan_buy_kWh': float(buy_kW.sum() * DT),
            'em_buy_kWh': float(em_kW.sum() * DT),
            'ch_kWh_sum': float(gl['ch_kW'][s:e].sum() * DT),
            'dis_kWh_sum': float(gl['dis_kW'][s:e].sum() * DT),
            'curtail_kWh_sum': float(gl['curtail_kW'][s:e].sum() * DT),
            'E0': E0, 'E_T': float(gl['E_kWh'][e - 1]), 'day': d,
        })
    return recs


if __name__ == '__main__':
    import sys, os, io, time
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    from common_q2 import load_all
    price, dates, load, pv = load_all()
    t0 = time.time()
    r = solve_global(price, load, pv)
    print('状态:', r['message'])
    print('变量数 %d，等式约束 %d，耗时 %.1f 秒' % (r['nvar'], r['nrow'], time.time() - t0))
    print('全年总费用 %.2f 元；计划购电 %.2f kWh；紧急购电 %.2f kWh；弃光 %.2f kWh'
          % (r['total_cost'], r['plan_buy_kWh'], r['em_buy_kWh'], r['curtail_kWh_sum']))
