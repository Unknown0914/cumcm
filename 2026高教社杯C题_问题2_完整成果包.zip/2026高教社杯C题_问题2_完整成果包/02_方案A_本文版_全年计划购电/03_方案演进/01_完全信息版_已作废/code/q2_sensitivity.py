# -*- coding: utf-8 -*-
"""
q2_sensitivity.py —— 问题2 敏感性分析（全年逐日求解）

S1 计划购电功率上限 b_t ≤ P_buy_max —— 回答"什么条件下紧急购电才会发生"
S2 充放电效率口径（双侧 0.9/0.9、单侧 0.9/1.0、往返 90%）
S3 储能最大充放电功率与储电量上界
S4 储能口径对照（跨天连续 vs 日循环）
"""
import sys, os, io, json
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
import pandas as pd
from common_q2 import load_all, DT, E_INIT, RES_DIR, SAVE_START
from q2_model import Q2Solver
from q2_global import solve_global

price, dates, load, pv = load_all()
save_idx = [d for d, dt_ in enumerate(dates) if pd.Timestamp(dt_) >= SAVE_START]


def run(**kw):
    """全年求解（默认全局优化）并返回保存期汇总，用于敏感性对比。"""
    cyc = kw.pop('day_cycle', False)
    tot = dict(plan=0.0, em=0.0, cost=0.0, ch=0.0, dis=0.0, cur=0.0, em_days=0, cur_days=0)
    if cyc:
        solver = Q2Solver(price, **kw)
        E0 = E_INIT
        recs = []
        for d in range(load.shape[0]):
            r = solver.solve_day(load[d], pv[d], E0, day_cycle=True)
            assert r['success'], (d, r.get('message'))
            E0 = r['E_T']
            recs.append(r)
    else:
        gl = solve_global(price, load, pv, **kw)
        assert gl['success'], gl['message']
        recs = gl['by_day']
    for d, r in enumerate(recs):
        if d in save_idx:
            tot['plan'] += r['plan_buy_kWh']; tot['em'] += r['em_buy_kWh']
            tot['cost'] += r['total_cost']; tot['ch'] += r['ch_kWh_sum']
            tot['dis'] += r['dis_kWh_sum']; tot['cur'] += r['curtail_kWh_sum']
            tot['em_days'] += int(r['em_buy_kWh'] > 1e-6)
            tot['cur_days'] += int(r['curtail_kWh_sum'] > 1e-6)
    return tot


rows = []

print('=' * 104)
print('S1 计划购电功率上限 P_buy_max —— 紧急购电的触发条件（全年 334 天）')
print('=' * 104)
print('%14s %14s %14s %14s %12s' % ('P_buy_max(kW)', '计划购电(kWh)', '紧急购电(kWh)', '总费用(元)', '紧急购电天数'))
for bm in [3000.0, 4000.0, 5000.0, 6000.0, 8000.0, None]:
    t = run(buy_max=bm)
    rows.append(dict(group='buy_max', buy_max=bm, **t))
    print('%14s %14.1f %14.1f %14.1f %12d'
          % ('无上限' if bm is None else '%.0f' % bm, t['plan'], t['em'], t['cost'], t['em_days']))

print()
print('=' * 104)
print('S2 充放电效率口径')
print('=' * 104)
print('%16s %10s %10s %14s %14s %10s' % ('口径', 'eta_c', 'eta_d', '计划购电(kWh)', '总费用(元)', '弃光(kWh)'))
for tag, ec, ed in (('双侧 0.9/0.9', 0.9, 0.9), ('单侧 0.9/1.0', 0.9, 1.0),
                    ('往返 90%', 0.9 ** 0.5, 0.9 ** 0.5)):
    t = run(eta_c=ec, eta_d=ed)
    rows.append(dict(group='eta', tag=tag, eta_c=ec, eta_d=ed, **t))
    print('%16s %10.4f %10.4f %14.1f %14.1f %10.1f' % (tag, ec, ed, t['plan'], t['cost'], t['cur']))

print()
print('=' * 104)
print('S3 储能配置（功率 / 储电量上界）')
print('=' * 104)
print('%12s %14s %14s %12s %12s' % ('参数', '值', '总费用(元)', '弃光(kWh)', '充电(kWh)'))
for p in [2500.0, 3750.0, 5000.0, 6250.0]:
    t = run(p_max=p)
    rows.append(dict(group='p_max', value=p, **t))
    print('%12s %14.0f %14.1f %12.1f %12.1f' % ('P_max(kW)', p, t['cost'], t['cur'], t['ch']))
for e in [6000.0, 8400.0, 10800.0, 12000.0]:
    t = run(e_max=e)
    rows.append(dict(group='e_max', value=e, **t))
    print('%12s %14.0f %14.1f %12.1f %12.1f' % ('E_max(kWh)', e, t['cost'], t['cur'], t['ch']))

print()
print('=' * 104)
print('S4 求解方式对照（全局跨天协调 vs 逐日近视）')
print('=' * 104)
tA = run()
tB = run(day_cycle=True)
rows.append(dict(group='convention', tag='global', **tA))
rows.append(dict(group='convention', tag='daily_cycle', **tB))
print('%18s %14s %14s %12s' % ('求解方式', '总费用(元)', '计划购电(kWh)', '弃光(kWh)'))
print('%18s %14.1f %14.1f %12.1f' % ('全局优化（本文）', tA['cost'], tA['plan'], tA['cur']))
print('%18s %14.1f %14.1f %12.1f' % ('逐日（日循环口径）', tB['cost'], tB['plan'], tB['cur']))

with open(os.path.join(RES_DIR, 'q2_sensitivity.json'), 'w', encoding='utf-8') as f:
    json.dump(rows, f, ensure_ascii=False, indent=2)
print('\nwritten results/q2_sensitivity.json  (%d 组实验)' % len(rows))
