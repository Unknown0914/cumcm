# -*- coding: utf-8 -*-
"""
q2_solve.py —— 问题2 全年逐日求解 + 结果导出

用法：
    python q2_solve.py                # 主口径：跨天连续（末值自由）
    python q2_solve.py --cycle        # 对照口径：日循环（E144 = E0）

输出：
    output/result2.xlsx              问题2 结果文件（严格套附件5 模板）
    results/q2_daily.csv             全年逐日汇总（购电量/费用/充放电/弃光/储电量）
    results/q2_timeseries_*.csv      4 个指定日期的 144 时段明细
    results/q2_table1.csv           论文表1（4 个指定日期）
    results/q2_table2.csv           论文表2（4 个指定日期）
    results/q2_table3.csv           论文表3（紧急购电量）
    results/q2_summary.json         关键指标汇总
"""
import sys, os, io, json, csv, argparse
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import numpy as np
import pandas as pd
import openpyxl

from common_q2 import (load_all, DT, NT, E_INIT, RES_DIR, OUT_DIR, TPL_RESULT2,
                       SAVE_START, KEY_DATES, TABLE1_CLOCKS, clock_to_t,
                       t_to_interval)
from q2_model import Q2Solver
from q2_global import solve_global

PERIODS = [('0:00-4:00', 1, 24), ('4:00-8:00', 25, 48), ('8:00-12:00', 49, 72),
           ('12:00-16:00', 73, 96), ('16:00-20:00', 97, 120), ('20:00-24:00', 121, 144)]


def run_year(solver, load, pv, day_cycle=False, E_init=E_INIT, verbose=True):
    """全年逐日求解，返回逐日记录列表。"""
    E0 = E_init
    recs = []
    for d in range(load.shape[0]):
        r = solver.solve_day(load[d], pv[d], E0, day_cycle=day_cycle)
        assert r['success'], '第 %d 天求解失败: %s' % (d + 1, r.get('message'))
        r['day'] = d
        r['E0'] = E0
        recs.append(r)
        E0 = r['E_T']            # 跨天传递（日循环口径下 E_T 恒等于 E0）
        if verbose and (d + 1) % 60 == 0:
            print('  已完成 %d / %d 天' % (d + 1, load.shape[0]))
    return recs


def write_result2(dates, recs, path):
    """严格按附件5 模板填写：计划购电量 / 充放电量 / 紧急购电量。"""
    import shutil
    shutil.copyfile(TPL_RESULT2, path)
    wb = openpyxl.load_workbook(path)

    # ---- 计划购电量：B..EO 为 144 个时段，EP 全天购电量，EQ 全天购电费 ----
    ws = wb['计划购电量']
    row = 2
    for d, dt_ in enumerate(dates):
        if pd.Timestamp(dt_) < SAVE_START:
            continue
        r = recs[d]
        for t in range(NT):
            ws.cell(row=row, column=2 + t).value = round(float(r['buy_kWh'][t]), 4)
        ws.cell(row=row, column=2 + NT).value = round(r['plan_buy_kWh'], 4)       # 全天购电量
        ws.cell(row=row, column=3 + NT).value = round(r['total_cost'], 4)         # 全天购电费
        row += 1
    n_plan_rows = row - 2

    # ---- 充放电量：每天 6 行；前两行的"时刻"列填 0:00 / 24:00 及其储电量 ----
    ws = wb['充放电量']
    row = 2
    for d, dt_ in enumerate(dates):
        if pd.Timestamp(dt_) < SAVE_START:
            continue
        r = recs[d]
        date_val = pd.Timestamp(dt_).to_pydatetime()
        for k, (nm, a, b) in enumerate(PERIODS):
            ws.cell(row=row, column=1).value = date_val if k == 0 else None
            ws.cell(row=row, column=2).value = nm
            ws.cell(row=row, column=3).value = round(float(r['ch_kWh'][a - 1:b].sum()), 4)
            ws.cell(row=row, column=4).value = round(float(r['dis_kWh'][a - 1:b].sum()), 4)
            if k == 0:
                ws.cell(row=row, column=5).value = '0:00'
                ws.cell(row=row, column=6).value = round(r['E0'], 4)
            elif k == 1:
                ws.cell(row=row, column=5).value = '24:00'
                ws.cell(row=row, column=6).value = round(r['E_T'], 4)
            row += 1
    n_cd_rows = row - 2

    # ---- 紧急购电量：先清空模板占位行，再按实际填写 ----
    ws = wb['紧急购电量']
    for r in range(2, ws.max_row + 1):
        for c in (1, 2, 3):
            ws.cell(row=r, column=c).value = None
    row = 2
    n_em_rows = 0
    n_saved = sum(1 for d, dt_ in enumerate(dates) if pd.Timestamp(dt_) >= SAVE_START)
    any_em = any(recs[d]['em_buy_kWh'] > 1e-6
                 for d, dt_ in enumerate(dates) if pd.Timestamp(dt_) >= SAVE_START)
    if not any_em:
        # 全年无紧急购电：写一行明确结论，避免留空表产生歧义
        ws.cell(row=2, column=1).value = '%s-%s' % (
            SAVE_START.strftime('%Y.%m.%d'), pd.Timestamp(dates[-1]).strftime('%Y.%m.%d'))
        ws.cell(row=2, column=2).value = '无紧急购电发生'
        ws.cell(row=2, column=3).value = 0
        n_em_rows = 1
    else:
        for d, dt_ in enumerate(dates):
            if pd.Timestamp(dt_) < SAVE_START:
                continue
            r = recs[d]
            idx = np.where(r['em_kWh'] > 1e-6)[0]
            if len(idx) == 0:
                continue
            # 合并相邻时段为时间区间
            groups, st = [], idx[0]
            for i in range(1, len(idx)):
                if idx[i] != idx[i - 1] + 1:
                    groups.append((st, idx[i - 1])); st = idx[i]
            groups.append((st, idx[-1]))
            first = True
            for a, b in groups:
                ws.cell(row=row, column=1).value = (pd.Timestamp(dt_).to_pydatetime()
                                                    if first else None)
                ws.cell(row=row, column=2).value = '%s-%s' % (
                    t_to_interval(a + 1).split('-')[0], t_to_interval(b + 1).split('-')[1])
                ws.cell(row=row, column=3).value = round(float(r['em_kWh'][a:b + 1].sum()), 4)
                row += 1
                n_em_rows += 1
                first = False
    wb.save(path)
    return n_plan_rows, n_cd_rows, n_em_rows


def build_tables(dates, recs):
    """论文表1 / 表2 / 表3（表3 的 4 个指定日期）。"""
    t1, t2, t3 = [], [], []
    for kd in KEY_DATES:
        d = int(np.where(pd.to_datetime(dates) == kd)[0][0])
        r = recs[d]
        ds = kd.strftime('%Y.%m.%d')
        row1 = [ds]
        for ck in TABLE1_CLOCKS:
            t = clock_to_t(ck)
            row1.append(round(float(r['buy_kWh'][t - 1]), 4))
        row1 += [round(r['plan_buy_kWh'], 4), round(r['total_cost'], 4)]
        t1.append(row1)
        row2 = [ds]
        for nm, a, b in PERIODS:
            row2 += [round(float(r['ch_kWh'][a - 1:b].sum()), 4),
                     round(float(r['dis_kWh'][a - 1:b].sum()), 4)]
        row2 += [round(r['E0'], 4), round(r['E_T'], 4)]
        t2.append(row2)
        t3.append([ds, '无紧急购电' if r['em_buy_kWh'] < 1e-6 else '见 result2.xlsx',
                   round(r['em_buy_kWh'], 4)])
    return t1, t2, t3


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--mode', choices=['global', 'daily'], default='global',
                    help='global=全年一次性全局优化（默认，跨天协调）；daily=逐日优化（对照）')
    ap.add_argument('--cycle', action='store_true',
                    help='仅逐日模式下有效：使用日循环口径（E144=E0）')
    ap.add_argument('--e-end', type=float, default=None,
                    help='仅全局模式下有效：要求 12-31 24:00 储电量等于该值（如 6000）')
    args = ap.parse_args()
    tag = 'daily_cycle' if (args.mode == 'daily' and args.cycle) else args.mode

    price, dates, load, pv = load_all()
    import time
    t0 = time.time()
    if args.mode == 'global':
        print('求解方式: 全年一次性全局优化（跨天协调，变量数 6x365x144 = 315360）')
        print('开始求解...')
        gl = solve_global(price, load, pv, e_end=args.e_end)
        assert gl['success'], gl['message']
        recs = gl['by_day']
        el = time.time() - t0
        print('全局求解完成，用时 %.1f 秒（等式约束 %d 条）' % (el, gl['nrow']))
    else:
        print('求解方式: 逐日优化（%s）'
              % ('日循环 E144=E0' if args.cycle else '跨天连续，末值自由'))
        print('开始全年逐日求解（365 天）...')
        solver = Q2Solver(price)
        recs = run_year(solver, load, pv, day_cycle=args.cycle)
        el = time.time() - t0
        print('逐日求解完成，用时 %.1f 秒' % el)

    # ---- 逐日汇总 CSV ----
    with open(os.path.join(RES_DIR, 'q2_daily_%s.csv' % tag), 'w', newline='',
              encoding='utf-8-sig') as f:
        w = csv.writer(f)
        w.writerow(['日期', 'E0_kWh', 'E_T_kWh', '计划购电量_kWh', '紧急购电量_kWh',
                    '购电费_元', '充电量_kWh', '放电量_kWh', '弃光量_kWh',
                    '光伏_kWh', '负载_kWh'])
        for d, dt_ in enumerate(dates):
            r = recs[d]
            w.writerow([pd.Timestamp(dt_).strftime('%Y-%m-%d'), '%.4f' % r['E0'],
                        '%.4f' % r['E_T'], '%.4f' % r['plan_buy_kWh'],
                        '%.4f' % r['em_buy_kWh'], '%.4f' % r['total_cost'],
                        '%.4f' % r['ch_kWh_sum'], '%.4f' % r['dis_kWh_sum'],
                        '%.4f' % r['curtail_kWh_sum'],
                        '%.4f' % (pv[d].sum() * DT), '%.4f' % (load[d].sum() * DT)])

    # ---- 指定日期时序明细 ----
    for kd in KEY_DATES:
        d = int(np.where(pd.to_datetime(dates) == kd)[0][0])
        r = recs[d]
        with open(os.path.join(RES_DIR, 'q2_timeseries_%s_%s.csv' %
                               (tag, kd.strftime('%Y%m%d'))), 'w', newline='',
                  encoding='utf-8-sig') as f:
            w = csv.writer(f)
            w.writerow(['t', 'interval', 'price', 'load_kW', 'pv_kW', 'net_load_kW',
                        'buy_kW', 'buy_kWh', 'em_kW', 'ch_kW', 'dis_kW', 'curtail_kW',
                        'E_end_kWh'])
            for t in range(NT):
                w.writerow([t + 1, t_to_interval(t + 1), '%.4f' % price[t],
                            '%.4f' % load[d][t], '%.4f' % pv[d][t],
                            '%.4f' % (load[d][t] - pv[d][t]),
                            '%.4f' % r['buy_kW'][t], '%.4f' % r['buy_kWh'][t],
                            '%.4f' % r['em_kW'][t], '%.4f' % r['ch_kW'][t],
                            '%.4f' % r['dis_kW'][t], '%.4f' % r['curtail_kW'][t],
                            '%.4f' % r['E_kWh'][t]])

    # ---- 论文表1/2/3 ----
    t1, t2, t3 = build_tables(dates, recs)
    with open(os.path.join(RES_DIR, 'q2_table1_%s.csv' % tag), 'w', newline='',
              encoding='utf-8-sig') as f:
        w = csv.writer(f)
        w.writerow(['日期'] + ['%s购电量(kWh)' % c for c in TABLE1_CLOCKS] +
                   ['全天购电量(kWh)', '全天购电费(元)'])
        w.writerows(t1)
    with open(os.path.join(RES_DIR, 'q2_table2_%s.csv' % tag), 'w', newline='',
              encoding='utf-8-sig') as f:
        w = csv.writer(f)
        hdr = ['日期']
        for nm, _, _ in PERIODS:
            hdr += ['%s充电(kWh)' % nm, '%s放电(kWh)' % nm]
        hdr += ['0:00储电量(kWh)', '24:00储电量(kWh)']
        w.writerow(hdr); w.writerows(t2)
    with open(os.path.join(RES_DIR, 'q2_table3_%s.csv' % tag), 'w', newline='',
              encoding='utf-8-sig') as f:
        w = csv.writer(f)
        w.writerow(['日期', '紧急购电时间段', '紧急购电量(kWh)'])
        w.writerows(t3)

    # ---- result2.xlsx ----
    xls = os.path.join(OUT_DIR, 'result2.xlsx' if args.mode == 'global' else 'result2_daily.xlsx')
    n1, n2, n3 = write_result2(dates, recs, xls)

    # ---- 汇总 ----
    save_idx = [d for d, dt_ in enumerate(dates) if pd.Timestamp(dt_) >= SAVE_START]
    tot_plan = sum(recs[d]['plan_buy_kWh'] for d in save_idx)
    tot_em = sum(recs[d]['em_buy_kWh'] for d in save_idx)
    tot_cost = sum(recs[d]['total_cost'] for d in save_idx)
    tot_ch = sum(recs[d]['ch_kWh_sum'] for d in save_idx)
    tot_dis = sum(recs[d]['dis_kWh_sum'] for d in save_idx)
    tot_cur = sum(recs[d]['curtail_kWh_sum'] for d in save_idx)
    tot_pv = sum(pv[d].sum() * DT for d in save_idx)
    tot_load = sum(load[d].sum() * DT for d in save_idx)
    summary = {
        'convention': ('global(whole-year, cross-day coordinated)' if args.mode == 'global'
                       else ('daily + cycle(E144=E0)' if args.cycle else 'daily + cross-day')),
        'mode': args.mode,
        'days_total': int(load.shape[0]),
        'days_saved': len(save_idx),
        'save_range': [pd.Timestamp(dates[save_idx[0]]).strftime('%Y-%m-%d'),
                       pd.Timestamp(dates[save_idx[-1]]).strftime('%Y-%m-%d')],
        'solve_seconds': round(el, 1),
        'total_plan_buy_kWh': tot_plan,
        'total_emergency_kWh': tot_em,
        'total_cost_yuan': tot_cost,
        'avg_price': tot_cost / tot_plan if tot_plan else None,
        'total_charge_kWh': tot_ch,
        'total_discharge_kWh': tot_dis,
        'total_curtail_kWh': tot_cur,
        'total_pv_kWh': tot_pv,
        'total_load_kWh': tot_load,
        'pv_utilization': 1 - tot_cur / tot_pv if tot_pv else None,
        'E0_first_day': recs[0]['E0'], 'E_T_first_day': recs[0]['E_T'],
        'E0_saved_start': recs[save_idx[0]]['E0'],
        'E_T_saved_end': recs[save_idx[-1]]['E_T'],
        'E_min_overall': float(min(r['E_kWh'].min() for r in recs)),
        'E_max_overall': float(max(r['E_kWh'].max() for r in recs)),
        'emergency_days': int(sum(1 for r in recs if r['em_buy_kWh'] > 1e-6)),
        'curtail_days': int(sum(1 for r in recs if r['curtail_kWh_sum'] > 1e-6)),
        'rows': {'plan': n1, 'charge_discharge': n2, 'emergency': n3},
    }
    with open(os.path.join(RES_DIR, 'q2_summary_%s.json' % tag), 'w', encoding='utf-8') as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)

    print()
    print('保存区间 %s ~ %s，共 %d 天' % (summary['save_range'][0], summary['save_range'][1],
                                        summary['days_saved']))
    print('计划购电量合计 %.2f kWh' % tot_plan)
    print('紧急购电量合计 %.2f kWh（发生紧急购电的天数 %d）' % (tot_em, summary['emergency_days']))
    print('购电总费用 %.2f 元，平均电价 %.4f 元/kWh' % (tot_cost, summary['avg_price']))
    print('储能充电 %.2f kWh，放电 %.2f kWh' % (tot_ch, tot_dis))
    print('弃光 %.2f kWh（有弃光天数 %d），光伏消纳率 %.2f%%'
          % (tot_cur, summary['curtail_days'], summary['pv_utilization'] * 100))
    print('储电量全程范围 [%.2f, %.2f] kWh；第 1 天 %.2f -> %.2f，2.1 起点 %.2f，12.31 末值 %.2f'
          % (summary['E_min_overall'], summary['E_max_overall'], summary['E0_first_day'],
             summary['E_T_first_day'], summary['E0_saved_start'], summary['E_T_saved_end']))
    print('result2.xlsx 行数: 计划购电量 %d 行，充放电量 %d 行，紧急购电量 %d 行'
          % (n1, n2, n3))
    print('已写出:', xls)


if __name__ == '__main__':
    main()
