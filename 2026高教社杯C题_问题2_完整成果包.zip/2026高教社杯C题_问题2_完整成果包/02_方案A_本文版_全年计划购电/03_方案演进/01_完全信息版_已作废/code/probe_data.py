﻿# -*- coding: utf-8 -*-
"""探查附件2、附件1 与 result2.xlsx 模板结构。"""
import sys, os, io
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
import openpyxl
from openpyxl.utils import get_column_letter

A1 = r'C:\Users\35941\Desktop\C题\附件\附件1.xlsx'
A2 = r'C:\Users\35941\Desktop\C题\附件\附件2.xlsx'
T2 = r'C:\Users\35941\Desktop\C题\附件\附件5\result2.xlsx'

print('=' * 78)
print('附件1  表头与前两行')
print('=' * 78)
wb = openpyxl.load_workbook(A1)
print('sheets:', wb.sheetnames)
ws = wb[wb.sheetnames[0]]
print('dims:', ws.dimensions, 'max_row', ws.max_row, 'max_col', ws.max_column)
for i, row in enumerate(ws.iter_rows(min_row=1, max_row=3, values_only=True)):
    print('  row%d %s' % (i + 1, row))
wb.close()

print()
print('=' * 78)
print('附件2  结构')
print('=' * 78)
wb = openpyxl.load_workbook(A2)
print('sheets:', wb.sheetnames)
for name in wb.sheetnames:
    ws = wb[name]
    print('--- sheet: %s   dims=%s  max_row=%s  max_col=%s' % (name, ws.dimensions, ws.max_row, ws.max_column))
    rows = ws.iter_rows(min_row=1, max_row=4, values_only=True)
    for i, row in enumerate(rows):
        cells = ['%s=%r' % (get_column_letter(j + 1), v) for j, v in enumerate(row[:8])]
        tail = ['%s=%r' % (get_column_letter(len(row)), row[-1])] if len(row) > 8 else []
        print('    row%-3d %s %s' % (i + 1, ' '.join(cells), ' '.join(tail)))
    # 末尾两行
    last = list(ws.iter_rows(min_row=max(1, ws.max_row - 1), values_only=True))
    for k, row in enumerate(last):
        print('    last%-3d A=%r  B=%r  ...  %s=%r' % (k, row[0], row[1] if len(row) > 1 else None,
              get_column_letter(len(row)), row[-1]))
wb.close()

print()
print('=' * 78)
print('result2.xlsx 模板')
print('=' * 78)
wb = openpyxl.load_workbook(T2)
print('sheets:', wb.sheetnames)
for ws in wb.worksheets:
    print('--- sheet: %s   dims=%s  max_row=%d  max_col=%d' % (ws.title, ws.dimensions, ws.max_row, ws.max_column))
    print('    merged:', ws.merged_cells.ranges)
    for r in list(range(1, min(ws.max_row, 4) + 1)):
        print('    row%-3d %s' % (r, [ws.cell(r, c).value for c in range(1, ws.max_column + 1)]))
    print('    ... 末 2 行:')
    for r in range(max(1, ws.max_row - 1), ws.max_row + 1):
        print('    row%-3d %s' % (r, [ws.cell(r, c).value for c in range(1, ws.max_column + 1)]))
wb.close()

