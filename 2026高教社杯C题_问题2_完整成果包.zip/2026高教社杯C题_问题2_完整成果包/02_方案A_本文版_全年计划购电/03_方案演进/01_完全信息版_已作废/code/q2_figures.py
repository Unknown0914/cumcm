# -*- coding: utf-8 -*-
"""
q2_figures.py —— 问题2 论文用图表（300 dpi PNG + 矢量 PDF）

fig1 全年逐日购电量 / 购电费 / 弃光量
fig2 全年储能储电量轨迹（每日 0:00 与日内极值）
fig3 全年弃光与光伏富余的关系
fig4 四个指定日期（春分/夏至/秋分/冬至）的最优调度
fig5 夏至日 2025-06-21 明细（电价 / 购电 / 充放电 / 储电量）
fig6 计划购电功率上限对紧急购电的触发作用
"""
import sys, os, io, json
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager

from common_q2 import (load_all, DT, NT, E_INIT, E_MIN, E_MAX, FIG_DIR, RES_DIR, KEY_DATES)
from q2_model import Q2Solver
from q2_global import solve_global

_CAND = ['Microsoft YaHei', 'SimHei', 'Noto Sans CJK SC']
_avail = {f.name for f in font_manager.fontManager.ttflist}
_PICK = next((c for c in _CAND if c in _avail), None)
if _PICK:
    plt.rcParams['font.sans-serif'] = [_PICK]
plt.rcParams['axes.unicode_minus'] = False
plt.rcParams['font.size'] = 11
plt.rcParams['axes.grid'] = True
plt.rcParams['grid.alpha'] = 0.3

C_PRICE, C_LOAD, C_PV = '#c0392b', '#2c3e50', '#e67e22'
C_BUY, C_CH, C_DIS, C_E = '#2980b9', '#27ae60', '#8e44ad', '#16a085'
H = np.arange(1, NT + 1) * DT


def _save(fig, name):
    for ext in ('png', 'pdf'):
        fig.savefig(os.path.join(FIG_DIR, '%s.%s' % (name, ext)), dpi=300, bbox_inches='tight')
    plt.close(fig)
    print('figure ->', name)


def solve_year():
    """与 q2_solve.py 保持一致：采用全年全局优化解。"""
    price, dates, load, pv = load_all()
    gl = solve_global(price, load, pv)
    assert gl['success'], gl['message']
    return price, dates, load, pv, gl['by_day']


def fig1(price, dates, load, pv, recs):
    day = np.arange(len(dates))
    buy = [r['plan_buy_kWh'] for r in recs]
    cost = [r['total_cost'] for r in recs]
    cur = [r['curtail_kWh_sum'] for r in recs]
    fig, axes = plt.subplots(3, 1, figsize=(10, 7.2), sharex=True)
    axes[0].plot(day, buy, color=C_BUY, lw=0.9)
    axes[0].set_ylabel('计划购电量 (kWh)')
    axes[0].set_title('图1  全年逐日计划购电量、购电费与弃光量')
    axes[1].plot(day, cost, color='#e74c3c', lw=0.9)
    axes[1].set_ylabel('购电费 (元)')
    axes[2].fill_between(day, 0, cur, color=C_PV, alpha=0.7, lw=0)
    axes[2].set_ylabel('弃光量 (kWh)')
    axes[2].set_xlabel('日期')
    for ax in axes:
        ax.axvspan(0, 31, color='#bdc3c7', alpha=0.35)
    axes[2].annotate('1 月：储能过渡期（结果不保存）', xy=(15, max(cur) * 0.7),
                     fontsize=9, ha='center', color='#7f8c8d')
    ticks = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334, 364]
    labels = ['1/1', '2/1', '3/1', '4/1', '5/1', '6/1', '7/1', '8/1', '9/1', '10/1', '11/1', '12/1', '12/31']
    axes[2].set_xticks(ticks)
    axes[2].set_xticklabels(labels, fontsize=8)
    axes[2].set_xlim(0, 364)
    _save(fig, 'q2_fig1_year_buy')


def fig2(dates, recs):
    day = np.arange(len(dates))
    E0 = [r['E0'] for r in recs]
    Emax = [r['E_kWh'].max() for r in recs]
    Emin = [r['E_kWh'].min() for r in recs]
    fig, ax = plt.subplots(figsize=(10, 3.8))
    ax.fill_between(day, Emin, Emax, color=C_E, alpha=0.35, label='日内储电量区间')
    ax.plot(day, E0, color=C_E, lw=1.0, label='每日 0:00 储电量')
    ax.axhline(E_MAX, color='#7f8c8d', ls='--', lw=1, label='上限 10800 kWh')
    ax.axhline(E_MIN, color='#7f8c8d', ls=':', lw=1, label='下限 1200 kWh')
    ax.set_ylabel('储电量 (kWh)')
    ax.set_xlabel('日期')
    ticks = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334, 364]
    labels = ['1/1', '2/1', '3/1', '4/1', '5/1', '6/1', '7/1', '8/1', '9/1', '10/1', '11/1', '12/1', '12/31']
    ax.set_xticks(ticks); ax.set_xticklabels(labels, fontsize=8)
    ax.set_xlim(0, 364); ax.set_ylim(0, 12000)
    ax.legend(fontsize=8, loc='upper left')
    ax.set_title('图2  全年储能储电量轨迹（首日由 6000 降至下界 1200，其后稳定运行）')
    _save(fig, 'q2_fig2_soc_year')


def fig3(load, pv, recs):
    sur = np.clip(pv - load, 0, None).sum(axis=1) * DT
    cur = np.array([r['curtail_kWh_sum'] for r in recs])
    fig, ax = plt.subplots(figsize=(8, 4.2))
    ax.scatter(sur, cur, s=8, alpha=0.6, color=C_PV)
    lim = max(sur.max(), cur.max()) * 1.05
    ax.plot([0, lim], [0, lim], ls='--', color='#7f8c8d', lw=1, label='弃光 = 富余（全部弃掉）')
    ax.set_xlabel('当日光伏富余量（kWh）')
    ax.set_ylabel('当日弃光量（kWh）')
    ax.legend(fontsize=9)
    ax.set_title('图3  弃光量与光伏富余量的关系（储能吸收能力有限）')
    _save(fig, 'q2_fig3_curtail')


def fig4(price, dates, load, pv, recs):
    fig, axes = plt.subplots(2, 2, figsize=(11, 6.4))
    for ax, kd in zip(axes.ravel(), KEY_DATES):
        d = int(np.where(pd.to_datetime(dates) == kd)[0][0])
        r = recs[d]
        ax.plot(H, load[d], color=C_LOAD, lw=1.4, label='负载 $L_t$')
        ax.plot(H, pv[d], color=C_PV, lw=1.4, label='光伏 $v_t$')
        ax.fill_between(H, 0, r['buy_kW'], color=C_BUY, alpha=0.45, label='计划购电 $b_t$')
        ax.set_title('%s' % kd.strftime('%Y-%m-%d'), fontsize=10)
        ax.set_xticks(range(0, 25, 6)); ax.set_xlim(0, 24)
        if ax is axes[0, 0]:
            ax.legend(fontsize=7, loc='upper left')
        ax.set_ylabel('功率 (kW)', fontsize=9)
    fig.suptitle('图4  四个指定日期（春分/夏至/秋分/冬至）的最优调度', y=1.0)
    fig.tight_layout()
    _save(fig, 'q2_fig4_key_dates')


def fig5(price, dates, load, pv, recs, kd=pd.Timestamp('2025-06-21')):
    d = int(np.where(pd.to_datetime(dates) == kd)[0][0])
    r = recs[d]
    fig, (ax, ax2) = plt.subplots(2, 1, figsize=(9, 6), sharex=True,
                                  gridspec_kw={'height_ratios': [1, 1]})
    ax.plot(H, load[d], color=C_LOAD, lw=1.5, label='负载')
    ax.plot(H, pv[d], color=C_PV, lw=1.5, label='光伏')
    ax.fill_between(H, 0, r['buy_kW'], color=C_BUY, alpha=0.45, label='计划购电')
    ax.fill_between(H, 0, -r['curtail_kW'], color='#95a5a6', alpha=0.6, label='弃光')
    ax.axhline(0, color='k', lw=0.8)
    ax.set_ylabel('功率 (kW)')
    ax.legend(fontsize=8, loc='upper left')
    ax3 = ax.twinx()
    ax3.step(H, price, where='post', color=C_PRICE, lw=1.2, alpha=0.85, label='电价')
    ax3.set_ylabel('电价 (元/kWh)', color=C_PRICE); ax3.tick_params(axis='y', colors=C_PRICE)
    ax3.grid(False)
    ax.set_title('图5  %s 最优调度明细（夏至，光伏富余最大）' % kd.strftime('%Y-%m-%d'))
    ax2.bar(H, r['ch_kW'], width=DT * 0.9, color=C_CH, label='充电')
    ax2.bar(H, -r['dis_kW'], width=DT * 0.9, color=C_DIS, label='放电')
    ax2.axhline(0, color='k', lw=0.8)
    ax2.set_ylabel('充(+)/放(-) 功率 (kW)')
    ax2b = ax2.twinx()
    ax2b.plot(H, r['E_kWh'], color=C_E, lw=1.8, label='储电量')
    ax2b.axhline(E_MIN, color='#7f8c8d', ls=':', lw=1)
    ax2b.set_ylabel('储电量 (kWh)', color=C_E); ax2b.tick_params(axis='y', colors=C_E)
    ax2b.grid(False)
    h1, l1 = ax2.get_legend_handles_labels(); h2, l2 = ax2b.get_legend_handles_labels()
    ax2.legend(h1 + h2, l1 + l2, fontsize=8, loc='upper left', ncol=3)
    ax2.set_xticks(range(0, 25, 2)); ax2.set_xlim(0, 24); ax2.set_xlabel('时刻 (h)')
    _save(fig, 'q2_fig5_summersolstice')


def fig6():
    p = os.path.join(RES_DIR, 'q2_sensitivity.json')
    if not os.path.exists(p):
        print('跳过 fig6：未找到敏感性结果')
        return
    with open(p, encoding='utf-8') as f:
        rows = json.load(f)
    bm = [r for r in rows if r['group'] == 'buy_max']
    xs = [(r['buy_max'] if r['buy_max'] is not None else 12000) for r in bm]
    em = [r['em'] for r in bm]
    cost = [r['cost'] for r in bm]
    fig, ax = plt.subplots(figsize=(8.5, 4.2))
    ax.bar(range(len(bm)), em, width=0.5, color='#e74c3c', alpha=0.85, label='紧急购电量')
    for i, v in enumerate(em):
        ax.annotate('%.0f' % v, (i, v), textcoords='offset points', xytext=(0, 3),
                    ha='center', fontsize=9)
    ax.set_xticks(range(len(bm)))
    ax.set_xticklabels(['%s' % ('无上限' if r['buy_max'] is None else '%.0f' % r['buy_max'])
                        for r in bm], fontsize=9)
    ax.set_xlabel('计划购电功率上限 $P^{buy}_{max}$ (kW)')
    ax.set_ylabel('全年紧急购电量 (kWh)', color='#c0392b')
    ax.tick_params(axis='y', colors='#c0392b')
    ax2 = ax.twinx()
    ax2.plot(range(len(bm)), cost, 'o-', color=C_BUY, lw=1.6, label='购电总费用')
    ax2.set_ylabel('购电总费用 (元)', color=C_BUY); ax2.tick_params(axis='y', colors=C_BUY)
    ax2.grid(False)
    ax.set_title('图6  计划购电功率上限与紧急购电量（上限 ≤4000 kW 时紧急购电被触发）')
    h1, l1 = ax.get_legend_handles_labels(); h2, l2 = ax2.get_legend_handles_labels()
    ax.legend(h1 + h2, l1 + l2, fontsize=9, loc='upper right')
    _save(fig, 'q2_fig6_buylimit')


def main():
    print('中文字体:', _PICK or '未找到')
    price, dates, load, pv, recs = solve_year()
    fig1(price, dates, load, pv, recs)
    fig2(dates, recs)
    fig3(load, pv, recs)
    fig4(price, dates, load, pv, recs)
    fig5(price, dates, load, pv, recs)
    fig6()


if __name__ == '__main__':
    main()
