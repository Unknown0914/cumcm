# -*- coding: utf-8 -*-
"""探查两种储能口径下 E0/E_T 的逐日演化（前 60 天），用于确定建模口径。"""
import sys, os, io
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
import pandas as pd
from common_q2 import load_all, E_INIT, DT
from q2_model import Q2Solver

price, dates, load, pv = load_all()
solver = Q2Solver(price)

for tag, cyc in (('跨天连续（末值自由）', False), ('日循环（E144=E0）', True)):
    E0 = E_INIT
    rows = []
    for d in range(60):
        r = solver.solve_day(load[d], pv[d], E0, day_cycle=cyc)
        assert r['success'], (d, r)
        rows.append((d, str(pd.Timestamp(dates[d]).date()), E0, r['E_T'],
                     r['plan_buy_kWh'], r['em_buy_kWh'], r['curtail_kWh_sum'],
                     r['ch_kWh_sum'], r['dis_kWh_sum'], r['total_cost']))
        E0 = r['E_T']
    print('=' * 100)
    print('口径:', tag)
    print('=' * 100)
    print('%3s %-11s %10s %10s %12s %10s %10s %10s %10s %10s' %
          ('d', '日期', 'E0(kWh)', 'E_T(kWh)', '计划购电', '紧急购电', '弃光', '充电', '放电', '费用(元)'))
    for row in rows[:14]:
        print('%3d %-11s %10.1f %10.1f %12.1f %10.1f %10.1f %10.1f %10.1f %10.1f' % row)
    print('  ...')
    for row in rows[28:34]:
        print('%3d %-11s %10.1f %10.1f %12.1f %10.1f %10.1f %10.1f %10.1f %10.1f' % row)
    print('  ...')
    for row in rows[-4:]:
        print('%3d %-11s %10.1f %10.1f %12.1f %10.1f %10.1f %10.1f %10.1f %10.1f' % row)
    E0s = [r[2] for r in rows]
    print('  E0 轨迹: min %.1f  max %.1f  末值 %.1f' % (min(E0s), max(E0s), E0s[-1]))
    print()
