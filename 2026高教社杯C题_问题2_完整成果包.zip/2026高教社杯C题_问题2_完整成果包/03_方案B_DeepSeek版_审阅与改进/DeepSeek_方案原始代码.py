# -*- coding: utf-8 -*-
"""2026 CUMCM C题 问题2：微网逐日计划购电策略 —— DeepSeek 版原始代码逐字复现

来源：桌面《2026高教社杯 C题第二问解答.pdf》（DeepSeek, 2026-09-11）第 4--6 页代码块。

本文件除以下"仅为能运行"的必要改动外，与原文代码完全一致：
  1) 附件路径改为绝对路径（附件 1/2 现位于 Desktop\\C题\\附件\\）；
  2) 输出写到 results/ 子目录；
  3) 追加审计输出（约束残差、可行性诊断）与解落盘。
其余（变量顺序、约束构造、特别是 2.5 节的"放电后储能不低于 Emin"写法）保持原样，
以便真实检验该方案能否直接运行、结果是否正确。
"""
import os
import numpy as np
import pandas as pd
from scipy.optimize import linprog

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
OUT = os.path.join(ROOT, 'results')
os.makedirs(OUT, exist_ok=True)
SRC1 = r'C:\Users\35941\Desktop\C题\附件\附件1.xlsx'
SRC2 = r'C:\Users\35941\Desktop\C题\附件\附件2.xlsx'

# ========== 1. 读取数据 ==========
# 附件1（单日电价）
df1 = pd.read_excel(SRC1)
c = df1['电价'].values.astype(float)  # 144个时段
n = len(c)
dt = 1/6
# 附件2（全年逐日负载和光伏）
df_load = pd.read_excel(SRC2, sheet_name='小区负载')
df_pv = pd.read_excel(SRC2, sheet_name='光伏发电实际功率')
# 演示单日逻辑（实际需循环全年）
Load = df_load.iloc[0, 1:145].values.astype(float)  # 假设第一行是1月1日
PV = df_pv.iloc[0, 1:145].values.astype(float)
E0 = 6000.0
Emax = 10800.0
Emin = 1200.0
Pmax = 5000.0
eta = 0.9
# ========== 2. 构造线性规划 ==========
# 决策变量顺序: P_buy(n), P_em(n), P_ch(n), P_dis(n), E(n)
# 总变量数 5*n
obj = np.zeros(5*n)
obj[:n] = c * dt          # 计划购电费用
obj[n:2*n] = 5 * c * dt   # 紧急购电费用（5倍）
A_eq = []
b_eq = []
# 2.1 功率平衡: P_buy + PV + P_dis + P_em = Load + P_ch
for t in range(n):
    row = np.zeros(5*n)
    row[t] = 1            # P_buy
    row[n+t] = 1          # P_em
    row[3*n+t] = 1        # P_dis
    row[2*n+t] = -1       # -P_ch
    A_eq.append(row)
    b_eq.append(Load[t] - PV[t])
# 2.2 储能动态: E_t - E_{t-1} - 0.9*P_ch*dt + P_dis*dt/0.9 = 0
for t in range(n):
    row = np.zeros(5*n)
    row[4*n+t] = 1        # E_t
    if t > 0:
        row[4*n+t-1] = -1 # -E_{t-1}
    row[2*n+t] = -eta * dt          # -0.9*P_ch*dt
    row[3*n+t] = dt / eta           # +P_dis*dt/0.9
    A_eq.append(row)
    if t == 0:
        b_eq.append(E0)   # E_0 = 6000
    else:
        b_eq.append(0)
A_ub = []
b_ub = []
# 2.3 充放电功率上限
for t in range(n):
    row = np.zeros(5*n)
    row[2*n+t] = 1
    A_ub.append(row); b_ub.append(Pmax)
    row = np.zeros(5*n)
    row[3*n+t] = 1
    A_ub.append(row); b_ub.append(Pmax)
# 2.4 储能容量上下限
for t in range(n):
    row = np.zeros(5*n)
    row[4*n+t] = 1
    A_ub.append(row); b_ub.append(Emax)
    row = np.zeros(5*n)
    row[4*n+t] = -1
    A_ub.append(row); b_ub.append(-Emin)
# 2.5 新增：放电后储能不低于Emin（解决min函数问题）
for t in range(1, n):
    row = np.zeros(5*n)
    row[4*n+t-1] = 1
    row[3*n+t] = -dt / eta
    A_ub.append(row); b_ub.append(-Emin)
# 变量下界
bounds = [(0, None)] * n + [(0, None)] * n + [(0, Pmax)] * n + [(0, Pmax)] * n + [(Emin, Emax)] * n
# ========== 3. 求解 ==========
res = linprog(obj, A_ub=A_ub, b_ub=b_ub, A_eq=A_eq, b_eq=b_eq,
              bounds=bounds, method='highs')
if res.success:
    x = res.x
    P_buy = x[:n]
    P_em = x[n:2*n]
    P_ch = x[2*n:3*n]
    P_dis = x[3*n:4*n]
    E = x[4*n:5*n]
    total_buy = np.sum(P_buy) * dt
    total_em = np.sum(P_em) * dt
    total_cost = np.sum(c * P_buy) * dt + np.sum(5 * c * P_em) * dt

    print('全天计划购电量: %.4f kWh' % total_buy)
    print('全天紧急购电量: %.4f kWh' % total_em)
    print('全天购电总费用: %.4f 元' % total_cost)
    # 保存结果（此处仅为单日示例，实际需循环全年）
    with pd.ExcelWriter(os.path.join(OUT, 'ds_q2_original_result2.xlsx')) as writer:
        df_buy = pd.DataFrame({'时间': df1['时间'], '计划购电量(kWh)': np.round(P_buy * dt, 4)})
        df_buy.to_excel(writer, sheet_name='计划购电量', index=False)
else:
    print('求解失败:', res.message)

# ================= 以下为审计附加（不影响原逻辑） =================
print()
print('=' * 74)
print('审计')
print('=' * 74)
print('求解状态 success =', res.success)
print('求解器消息     :', res.message)
print('待解算日期     : %s   （第 1 天）' % df_load.iloc[0, 0])
print('该日负载范围   : [%.2f, %.2f] kW，日电量 %.2f kWh'
      % (Load.min(), Load.max(), Load.sum() * dt))
print('该日光伏范围   : [%.2f, %.2f] kW，日电量 %.2f kWh'
      % (PV.min(), PV.max(), PV.sum() * dt))
print('净负荷最低     : %.2f kW，光伏富余总量 %.2f kWh'
      % ((Load - PV).min(), np.clip(PV - Load, 0, None).sum() * dt))
print()
print('原代码 A_ub 中 2.5 节约束为:  E_{t-1} - (dt/eta)*P_dis_t <= -Emin')
lhs = E0 - (dt / eta) * Pmax
print('取 E_{t-1}=E0=%.0f、P_dis<=Pmax=%.0f 代入左侧: %.2f，而右端为 %.2f'
      % (E0, Pmax, lhs, -Emin))
print('=> 该约束等价于 P_dis_t >= (E_{t-1}+Emin)/(dt/eta) = %.1f kW，远超 P_max=%.0f kW'
      % ((E0 + Emin) / (dt / eta), Pmax))
print('=> 与 0 <= P_dis <= %.0f 冲突，模型不可行。' % Pmax)
print()
print('此外，原代码未引入弃光变量：当光伏富余超过储能吸收能力时，')
print('平衡式 P_buy + P_em + PV + P_dis = Load + P_ch 要求 P_buy/P_em 为负，同样不可行。')
