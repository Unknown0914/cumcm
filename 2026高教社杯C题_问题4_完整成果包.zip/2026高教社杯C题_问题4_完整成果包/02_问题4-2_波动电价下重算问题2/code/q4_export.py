# -*- coding: utf-8 -*-
"""
q4_export.py —— 按附件5 模板导出 result4-2.xlsx（对应问题2）与 result4-3.xlsx（对应问题3）。

模板结构（实测）：
  result4-2：计划购电量(335×147) / 充放电量(每6行一天) / 紧急购电量(每天3行)
  result4-3：计划购电量 / 调整购电量 / 充放电量 / 紧急购电量
"""
import os, sys, io, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.stdout.reconfigure(encoding='utf-8', errors='replace')
import numpy as np
import pandas as pd
import openpyxl
from common_q4 import (DT, NT, E_INIT, E_MIN, E_MAX, SAVE_START, OUT_DIR, RES_DIR,
                       TPL4_2, TPL4_3, load_price_a4, load_year, load_forecast)
import q4_2
import q4_3

Z42 = 0.30
Z43 = 0.30


def _sheet(wb, tpl, name):
    """若 wb 已有同名工作表则复用，否则按模板新建。"""
    if name in wb.sheetnames:
        return wb[name]
    src = tpl[name]
    ws = wb.create_sheet(name)
    for c in range(1, src.max_column + 1):
        ws.cell(1, c).value = src.cell(1, c).value
    return ws


def _write_plan_sheet(wb, tpl, name, rows):
    """rows: list of (date, P_array_len144, plan_cost, em_cost)。"""
    src = tpl[name]
    ws = _sheet(wb, tpl, name)
    for c in range(1, src.max_column + 1):
        ws.cell(1, c).value = src.cell(1, c).value
    for r, (dt, P, pc, ec) in enumerate(rows):
        ws.cell(r + 2, 1).value = dt.to_pydatetime()
        for t in range(NT):
            ws.cell(r + 2, 2 + t).value = round(float(P[t]), 4)
        ws.cell(r + 2, 146).value = round(float(P.sum()), 4)
        ws.cell(r + 2, 147).value = round(float(pc + ec), 4)
    return ws


def _write_cycle_sheet(wb, tpl, name, recs, idx, dates):
    src = tpl[name]
    ws = _sheet(wb, tpl, name)
    for c in range(1, 7):
        ws.cell(1, c).value = src.cell(1, c).value
    r = 2
    for i in idx:
        ch, dis = recs[i]['ch'], recs[i]['dis']
        e0 = E_INIT if i == 0 else recs[i - 1]['E'][-1]
        ws.cell(r, 1).value = pd.Timestamp(dates[i]).to_pydatetime()
        for b in range(6):
            sl = slice(24 * b, 24 * b + 24)
            ws.cell(r + b, 2).value = '%d:00-%d:00' % (4 * b, 4 * (b + 1))
            ws.cell(r + b, 3).value = round(float(ch[sl].sum()), 4)
            ws.cell(r + b, 4).value = round(float(dis[sl].sum()), 4)
        ws.cell(r, 5).value = '00:00'; ws.cell(r, 6).value = round(float(e0), 4)
        ws.cell(r + 1, 5).value = '24:00'; ws.cell(r + 1, 6).value = round(float(recs[i]['E'][-1]), 4)
        r += 6
    return ws


def _blocks(em, tol=1e-6):
    out, t = [], 0
    while t < NT:
        if em[t] > tol:
            s = t
            while t < NT and em[t] > tol:
                t += 1
            out.append(('%d:%02d-%d:%02d' % (s // 6, s % 6 * 10, t // 6, t % 6 * 10),
                        float(em[s:t].sum())))
        else:
            t += 1
    return out


def _write_em_sheet(wb, tpl, name, recs, idx, dates):
    src = tpl[name]
    ws = _sheet(wb, tpl, name)
    for c in range(1, 4):
        ws.cell(1, c).value = src.cell(1, c).value
    r = 2
    for i in idx:
        bl = _blocks(recs[i]['em'])
        ws.cell(r, 1).value = pd.Timestamp(dates[i]).to_pydatetime()
        if not bl:
            r += 1
            continue
        for k, (seg, q) in enumerate(bl):
            ws.cell(r + k, 2).value = seg
            ws.cell(r + k, 3).value = round(q, 4)
        r += max(1, len(bl))
    return ws


def main():
    price, _ = load_price_a4()
    dates, L = load_year('小区负载')
    _, V = load_year('光伏发电实际功率')
    _, fc = load_forecast()
    idx = [i for i, d in enumerate(dates) if pd.Timestamp(d) >= SAVE_START]
    print('保存期 %d 天' % len(idx))

    # ---------- result4-2 ----------
    print('推演问题4-2…')
    recs2 = q4_2.run(price, L, V, z=Z42, verbose=False)
    tpl = openpyxl.load_workbook(TPL4_2)
    wb = openpyxl.Workbook(); wb.remove(wb.active)
    rows = [(pd.Timestamp(dates[i]), recs2[i]['P'],
             float((recs2[i]['P'] * price[i]).sum()),
             float((5.0 * price[i] * recs2[i]['em']).sum())) for i in idx]
    _write_plan_sheet(wb, tpl, '计划购电量', rows)
    _write_cycle_sheet(wb, tpl, '充放电量', recs2, idx, dates)
    _write_em_sheet(wb, tpl, '紧急购电量', recs2, idx, dates)
    p2 = os.path.join(OUT_DIR, 'result4-2.xlsx')
    wb.save(p2)
    print('已写出', p2)

    # ---------- result4-3 ----------
    print('推演问题4-3…')
    recs3 = q4_3.run(price, L, V, fc, n_slots=4, z=Z43, verbose=False)
    tpl3 = openpyxl.load_workbook(TPL4_3)
    wb3 = openpyxl.Workbook(); wb3.remove(wb3.active)
    for nm in tpl3.sheetnames:
        src = tpl3[nm]
        ws = wb3.create_sheet(nm)
        for c in range(1, src.max_column + 1):
            ws.cell(1, c).value = src.cell(1, c).value
    ws = wb3['计划购电量']
    for r, i in enumerate(idx):
        ws.cell(r + 2, 1).value = pd.Timestamp(dates[i]).to_pydatetime()
        for t in range(NT):
            ws.cell(r + 2, 2 + t).value = round(float(recs3[i]['P'][t]), 4)
        ws.cell(r + 2, 146).value = round(float(recs3[i]['P'].sum()), 4)
        base = float((np.minimum(recs3[i]['P'], recs3[i]['A']) * price[i]).sum())
        dp = np.maximum(0.0, recs3[i]['A'] - recs3[i]['P'])
        dm = np.maximum(0.0, recs3[i]['P'] - recs3[i]['A'])
        dev = float((price[i] * (0.5 * dm + 1.5 * dp)).sum())
        emc = float((5.0 * price[i] * recs3[i]['em']).sum())
        ws.cell(r + 2, 147).value = round(base + dev + emc, 4)
    ws2 = wb3['调整购电量']
    for r, i in enumerate(idx):
        ws2.cell(r + 2, 1).value = pd.Timestamp(dates[i]).to_pydatetime()
        for t in range(NT):
            ws2.cell(r + 2, 2 + t).value = round(float(recs3[i]['A'][t]), 4)
        ws2.cell(r + 2, 146).value = round(float(recs3[i]['A'].sum()), 4)
    _write_cycle_sheet(wb3, tpl3, '充放电量', recs3, idx, dates)
    _write_em_sheet(wb3, tpl3, '紧急购电量', recs3, idx, dates)
    p3 = os.path.join(OUT_DIR, 'result4-3.xlsx')
    wb3.save(p3)
    print('已写出', p3)

    json.dump({'z42': Z42, 'z43': Z43, 'days': len(idx)},
              io.open(os.path.join(RES_DIR, 'q4_export_meta.json'), 'w', encoding='utf-8'),
              ensure_ascii=False, indent=2)


if __name__ == '__main__':
    main()
