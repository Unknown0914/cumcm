# -*- coding: utf-8 -*-
"""
q4_3.py —— 问题4-3：**实时波动电价**下重算"问题3"（多时刻预报 + 调整策略）

与问题3 的唯一区别：电价由"每天相同"改为附件4 的逐日逐时段电价。
其余沿用问题3 的最终方案（含本轮改善）：
  · 光伏用附件3 官方预报（0:00/6:00/12:00/18:00）
  · 负载用 lag-7 外推（题面未给负载预报）
  · 各阶段规划叠加安全裕度 z·σ
  · 执行层：储能实时响应（**不用日内 LP**——会破坏"计划—调整"耦合）
  · 阶段划分 6/6/6/6 小时
  · 结算 C = c·A + 0.5c|A−P|

费用：F = Σ c_t·A_t·Δt + Σ 0.5c_t|A_t−P_t|·Δt + Σ 5c_t·em_t
"""
import os, sys, io, json, argparse, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.stdout.reconfigure(encoding='utf-8', errors='replace')
import numpy as np
from scipy.optimize import linprog
from common_q4 import (DT, NT, E_INIT, E_MIN, E_MAX, P_MAX, ETA_C, ETA_D, DE,
                       BIAS_UP, BIAS_DOWN, EM_K, SAVE_START, RES_DIR,
                       SLOT_START_T, SLOT_END_T, load_price_a4, load_year, load_forecast,
                       stage_forecast, lag7, rolling_sigma)


# ==================== 阶段规划 LP ====================
def solve_stage(price_d, load_pred, fc_pv, plan_ref, a, soc_init, z, sigma):
    """规划 [a, 144]。变量 7 个/时段：[A, ch, dis, curt, E, d+, d-]。

    费用 c·min(P,A) + 0.5c(P−A)⁺ + 1.5c(A−P)⁺ 关于 A 的线性展开为
        c·P + 1.5c·d⁺ − 0.5c·d⁻
    故 d⁺ 系数 +1.5c、d⁻ 系数 **−0.5c**（下调可净省 0.5c）。
    """
    n = NT - a + 1
    nv = 7 * n
    A, C, D, CU, E, DP, DM = 0, n, 2 * n, 3 * n, 4 * n, 5 * n, 6 * n
    idx = np.arange(a - 1, NT)
    p_price = price_d[idx]
    p_load = load_pred[idx] + (z * sigma[idx] if sigma is not None else 0.0)
    p_pv = fc_pv[idx]
    D_req = (p_load - p_pv) * DT

    c = np.zeros(nv)
    if plan_ref is None:
        c[A:A + n] = p_price * DT
    else:
        c[A:A + n] = p_price * DT
        c[DP:DP + n] = BIAS_UP * p_price * DT
        c[DM:DM + n] = -BIAS_DOWN * p_price * DT

    A_eq, b_eq = [], []
    for k in range(n):
        row = np.zeros(nv)
        row[A + k] = 1.0; row[CU + k] = -1.0; row[D + k] = 1.0; row[C + k] = -1.0
        A_eq.append(row); b_eq.append(D_req[k])
    for k in range(n):
        row = np.zeros(nv)
        row[E + k] = 1.0
        if k > 0:
            row[E + k - 1] = -1.0
        row[C + k] = -ETA_C; row[D + k] = 1.0 / ETA_D
        A_eq.append(row); b_eq.append(soc_init if k == 0 else 0.0)
    if plan_ref is not None:
        p_ref = plan_ref[idx]
        for k in range(n):
            row = np.zeros(nv)
            row[A + k] = 1.0; row[DP + k] = -1.0; row[DM + k] = 1.0
            A_eq.append(row); b_eq.append(p_ref[k])

    cur_hi = np.maximum(0.0, (p_pv - p_load)) * DT
    cur_hi = np.maximum(cur_hi, 0.0)
    bounds = ([(0.0, None)] * n + [(0.0, DE)] * n + [(0.0, DE)] * n
              + [(0.0, float(cur_hi[k])) for k in range(n)]
              + [(E_MIN, E_MAX)] * n + [(0.0, None)] * n + [(0.0, None)] * n)
    res = linprog(c, A_eq=np.array(A_eq), b_eq=np.array(b_eq), bounds=bounds, method='highs')
    if not res.success:
        raise RuntimeError('阶段 LP 失败: ' + res.message)
    x = res.x
    return x[A:A + n], x[C:C + n], x[D:D + n], x[CU:CU + n], x[E:E + n]


# ==================== 执行层：储能实时响应 ====================
def execute_segment(price_d, load_act, pv_act, a_final, a, b, E0):
    """逐时段：缺额先放电（至下限），仍不足则紧急购电；富余先充电（至上限），
    仍有余则弃光（仅光伏自身富余可弃）。"""
    m = b - a + 1
    ch = np.zeros(m); dis = np.zeros(m); curt = np.zeros(m); em = np.zeros(m); E = np.zeros(m)
    e = E0
    for k in range(m):
        t = a - 1 + k
        net = load_act[t] * DT - pv_act[t] * DT - a_final[k]      # kWh，>0 表示缺额
        if net > 1e-9:
            d = min(DE, max(0.0, e - E_MIN) * ETA_D, net)
            dis[k] = d; em[k] = net - d
            e -= d / ETA_D
        else:
            surplus = -net
            cg = min(DE, (E_MAX - e) / ETA_C, surplus)
            ch[k] = cg
            pv_sur = max(0.0, pv_act[t] * DT - load_act[t] * DT)
            curt[k] = min(surplus - cg, pv_sur)
            e += cg * ETA_C
        E[k] = e
    return ch, dis, curt, em, float(e)


def run_day(price_d, load_act, load_pred, pv_act, fc_day, sig_day, soc_init,
            n_slots=4, z=0.0):
    """阶段 0 用 0:00 预报规划全天 P 与储能轨迹；阶段 s>0 用新预报调整 A
    （偏差基准始终是 0:00 的计划 P）；执行层沿段实时响应。"""
    starts = list(SLOT_START_T[:n_slots]); ends = list(SLOT_END_T[:n_slots])
    ends[-1] = NT
    P_plan = np.zeros(NT); A_final = np.zeros(NT)
    ch_all = np.zeros(NT); dis_all = np.zeros(NT)
    curt_all = np.zeros(NT); em_all = np.zeros(NT); E_all = np.zeros(NT)
    plan_ref = None; prev_fc = None
    e = soc_init
    for s in range(n_slots):
        a, b = starts[s], ends[s]
        fc10 = stage_forecast(fc_day, s, prev_fc)
        prev_fc = fc10
        As, chs, diss, curs, Es = solve_stage(price_d, load_pred, fc10, plan_ref, a,
                                              e, z, sig_day[s])
        if s == 0:
            P_plan[:] = As
            plan_ref = P_plan.copy()          # ★ 偏差基准 = 0:00 的计划 P
        A_final[a - 1:] = As
        ch, dis, curt, em, e = execute_segment(price_d, load_act, pv_act, As, a, b, e)
        ch_all[a - 1:b] = ch; dis_all[a - 1:b] = dis
        curt_all[a - 1:b] = curt; em_all[a - 1:b] = em
        E_all[a - 1:b] = np.asarray(np.cumsum([0] * 0), dtype=float) if False else E_all[a - 1:b]
        # 记录该段末储电量
        E_all[b - 1] = e
        e = float(min(max(e, E_MIN), E_MAX))
    # 补全段内储电量轨迹（供校验）
    ee = soc_init
    for t in range(NT):
        ee += ch_all[t] * ETA_C - dis_all[t] / ETA_D
        E_all[t] = ee
    return dict(P=P_plan, A=A_final, ch=ch_all, dis=dis_all, curt=curt_all,
                em=em_all, E=E_all, e_end=float(min(max(ee, E_MIN), E_MAX)))


def run(price, L, V, fc, n_slots=4, z=0.0, verbose=True):
    import pandas as pd
    Lp = lag7(L)
    # σ：用附件3 各时刻的净负荷预报残差（逐时段），与问题3 一致
    sig_day = []
    for s in range(4):
        h = [0, 6, 12, 18][s]
        t0 = 6 * (h + 1)
        E = np.array([((Lp[d] - stage_forecast(fc[d], s, None)) - (L[d] - V[d]))[t0 - 1:]
                      for d in range(L.shape[0])])
        sg = np.zeros(NT); sg[t0 - 1:] = E.std(axis=0)
        sig_day.append(sg)
    soc = E_INIT
    recs = []
    for d in range(L.shape[0]):
        r = run_day(price[d], L[d], Lp[d], V[d], fc[d], sig_day, soc, n_slots=n_slots, z=z)
        soc = r['e_end']
        recs.append(r)
        if verbose and (d + 1) % 100 == 0:
            print('  已推演 %d / %d 天' % (d + 1, L.shape[0]))
    return recs


def summarize(recs, dates, price):
    import pandas as pd
    idx = [i for i, d in enumerate(dates) if pd.Timestamp(d) >= SAVE_START]
    base = dev = emc = 0.0
    for i in idx:
        r = recs[i]
        base += float((np.minimum(r['P'], r['A']) * price[i]).sum())
        dp = np.maximum(0.0, r['A'] - r['P']); dm = np.maximum(0.0, r['P'] - r['A'])
        dev += float((price[i] * (BIAS_DOWN * dm + BIAS_UP * dp)).sum())
        emc += float((EM_K * price[i] * r['em']).sum())
    g = lambda k: float(sum(recs[i][k].sum() for i in idx))
    return dict(days=len(idx), plan_kWh=g('P'), final_kWh=g('A'),
                base_cost=base, dev_cost=dev, em_cost=emc, total_cost=base + dev + emc,
                em_kWh=g('em'), curt_kWh=g('curt'), charge_kWh=g('ch'),
                discharge_kWh=g('dis'))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--slots', type=int, default=4, choices=[1, 2, 4])
    ap.add_argument('--z', type=float, default=0.0)
    ap.add_argument('--tag', default=None)
    a = ap.parse_args()
    price, _ = load_price_a4()
    dates, L = load_year('小区负载')
    _, V = load_year('光伏发电实际功率')
    _, fc = load_forecast()
    print('问题4-3（波动电价）：附件3 光伏预报 + 负载 lag-7，裕度 z=%.4f，时点 %d'
          % (a.z, a.slots))
    t0 = time.time()
    recs = run(price, L, V, fc, n_slots=a.slots, z=a.z)
    s = summarize(recs, dates, price)
    s['z'] = a.z; s['slots'] = a.slots; s['seconds'] = round(time.time() - t0, 1)
    print('计划 %.0f kWh -> 调整 %.0f kWh' % (s['plan_kWh'], s['final_kWh']))
    print('基础 %.2f + 偏差 %.2f + 紧急 %.2f = 总费用 %.2f 元 | %.1f s'
          % (s['base_cost'], s['dev_cost'], s['em_cost'], s['total_cost'], s['seconds']))
    tag = a.tag or ('q43_s%d_z%.4f' % (a.slots, a.z))
    json.dump(s, io.open(os.path.join(RES_DIR, '%s.json' % tag), 'w', encoding='utf-8'),
              ensure_ascii=False, indent=2)
    print('已写出 results/%s.json' % tag)


if __name__ == '__main__':
    main()
