# -*- coding: utf-8 -*-
"""q4_figures.py —— 问题4 的论文级图（波动电价特征 + 两问结果 + 对照）。"""
import os, sys, io, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.stdout.reconfigure(encoding='utf-8', errors='replace')
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import rcParams
from common_q4 import (DT, NT, RES_DIR, FIG_DIR, load_price_a4, load_year)

rcParams['font.sans-serif'] = ['Microsoft YaHei', 'SimHei', 'DejaVu Sans']
rcParams['axes.unicode_minus'] = False
rcParams['font.size'] = 10.5
rcParams['axes.grid'] = True
rcParams['grid.alpha'] = 0.3
C = {'p4': '#C44E52', 'p1': '#4C72B0', 'pv': '#E8A33D', 'net': '#8172B2',
     'g1': '#55A868', 'g2': '#8172B2'}
os.makedirs(FIG_DIR, exist_ok=True)


def save(fig, nm):
    for ext in ('pdf', 'png'):
        fig.savefig(os.path.join(FIG_DIR, '%s.%s' % (nm, ext)), dpi=300, bbox_inches='tight')
    plt.close(fig)
    print('  ->', nm)


price, dates = load_price_a4()
import pandas as pd
_, L = load_year('小区负载')
p1 = pd.read_excel(r'C:\Users\35941\Desktop\C题\附件\附件1.xlsx')['电价'].to_numpy(float)[:NT]
hr = ((np.arange(NT) + 1) * DT) % 24

# ============ 图1 波动电价的统计特征 ============
fig, (a1, a2) = plt.subplots(1, 2, figsize=(12, 3.9))
a1.plot(hr, p1, lw=1.8, color=C['p1'], label='附件1（每天相同）')
a1.plot(hr, price[:60].mean(axis=0), lw=1.5, color=C['p4'], alpha=0.85,
        label='附件4（前 60 天均值）')
a1.fill_between(hr, np.percentile(price, 10, axis=0), np.percentile(price, 90, axis=0),
                color=C['p4'], alpha=0.18, label='附件4 的 10–90 分位带')
a1.set_xlabel('时刻 (h)'); a1.set_ylabel('电价 (元/kWh)')
a1.set_xlim(0, 24); a1.set_xticks(np.arange(0, 25, 3))
a1.set_title('(a) 日内电价形态：附件4 波动显著大于附件1'); a1.legend(fontsize=8.5)
dmean = price.mean(axis=1)
a2.plot(np.arange(len(dmean)), dmean, lw=0.9, color=C['p4'])
a2.axhline(dmean.mean(), color='gray', ls='--', lw=1.2,
           label='全年均值 %.4f 元' % dmean.mean())
a2.set_xlabel('天数序号（2025-01-01 起）'); a2.set_ylabel('日均电价 (元/kWh)')
a2.set_title('(b) 日均电价的逐日波动（σ=%.4f 元）' % dmean.std())
a2.legend(fontsize=9)
save(fig, 'q4f_fig1_price_variation')

# ============ 图2 两问的裕度敏感性 ============
fig, (a1, a2) = plt.subplots(1, 2, figsize=(12, 3.9))
for f, ax, ttl in ((('q42_z0.0.json', 'q42_z0.3.json', 'q42_z0.5.json', 'q42_z0.8416.json'),
                    a1, '(a) 问题4-2（对应问题2）'),
                   (('q43_s4_z0.0.json', 'q43_s4_z0.3.json', 'q43_s4_z0.5.json',
                     'q43_s4_z0.8416.json'), a2, '(b) 问题4-3（对应问题3）')):
    zs, ys = [], []
    for fn in f:
        p = os.path.join(RES_DIR, fn)
        if os.path.exists(p):
            d = json.load(io.open(p, encoding='utf-8'))
            zs.append(d['z']); ys.append(d['total_cost'] / 1e4)
    if zs:
        o = np.argsort(zs)
        zs = np.array(zs)[o]; ys = np.array(ys)[o]
        ax.plot(zs, ys, 'o-', color=C['g1'], lw=2, ms=8)
        for x_, y_ in zip(zs, ys):
            ax.annotate('%.1f' % y_, (x_, y_), textcoords='offset points', xytext=(0, 8),
                        ha='center', fontsize=9)
        b = int(np.argmin(ys))
        ax.plot(zs[b], ys[b], 'o', ms=14, mfc='none', mec=C['p4'], mew=2)
        ax.set_xlabel('安全裕度系数 z'); ax.set_ylabel('总费用 (万元)')
        ax.set_title(ttl + '：最优 z=%.2f' % zs[b])
save(fig, 'q4f_fig2_margin_scan')

# ============ 图3 恒定价 vs 波动电价的四问对照 ============
labels = ['问题2\n(恒定价)', '问题4-2\n(波动价)', '问题3\n(恒定价)', '问题4-3\n(波动价)']
vals = [13839956.05 / 1e4, 14524805.64 / 1e4, 13596227.88 / 1e4, 14238411.87 / 1e4]
cols = [C['p1'], C['p4'], C['p1'], C['p4']]
fig, ax = plt.subplots(figsize=(8.4, 4.2))
bars = ax.bar(np.arange(4), vals, 0.55, color=cols)
for i, v in enumerate(vals):
    ax.text(i, v + 15, '%.1f 万元' % v, ha='center', fontsize=9.5)
for i in (0, 2):
    ax.annotate('', xy=(i + 1, vals[i + 1]), xytext=(i, vals[i]),
                arrowprops=dict(arrowstyle='->', color='gray', lw=1.2))
    ax.text(i + 0.5, (vals[i] + vals[i + 1]) / 2 + 30, '+%.1f%%'
            % (100 * (vals[i + 1] - vals[i]) / vals[i]), ha='center', fontsize=9,
            color='gray')
ax.set_xticks(np.arange(4)); ax.set_xticklabels(labels, fontsize=9.5)
ax.set_ylabel('总费用 (万元)')
ax.set_title('图3  实时波动电价的影响：两问的费用均上升约 5%')
save(fig, 'q4f_fig3_fixed_vs_varying')

# ============ 图4 问题4-3 的逐日购电量 ============
# 从 result4-3.xlsx 读取计划/调整量
import openpyxl
p = os.path.join(os.path.dirname(FIG_DIR), 'output', 'result4-3.xlsx')
if os.path.exists(p):
    wb = openpyxl.load_workbook(p, read_only=True, data_only=True)
    def sheet_arr(nm):
        ws = wb[nm]; out = []
        for i, row in enumerate(ws.iter_rows(values_only=True)):
            if i == 0:
                continue
            v = row[1:145]
            if v and v[0] is not None:
                out.append([float(x) if x is not None else 0.0 for x in v])
        return np.array(out)
    try:
        P4 = sheet_arr('计划购电量'); A4 = sheet_arr('调整购电量')
        day = np.arange(P4.shape[0])
        fig, ax = plt.subplots(figsize=(11, 3.9))
        ax.plot(day, P4.sum(axis=1) / 1e3, lw=0.9, color=C['g1'], label='计划购电量')
        ax.plot(day, A4.sum(axis=1) / 1e3, lw=0.9, color=C['net'], label='调整后购电量')
        ax.fill_between(day, A4.sum(axis=1) / 1e3, P4.sum(axis=1) / 1e3,
                        color='#CCCCCC', alpha=0.5, label='调整量')
        ax.set_xlabel('天数序号（2025-02-01 起）'); ax.set_ylabel('日购电量 (MWh)')
        ax.set_title('图4  问题4-3：全年逐日计划与调整后购电量（334 天）')
        ax.legend(fontsize=9)
        save(fig, 'q4f_fig4_daily_plan_vs_final')
    except Exception as e:
        print('  跳过图4:', e)

print('\n完成')
