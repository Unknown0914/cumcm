# -*- coding: utf-8 -*-
"""
common_q4.py —— 问题4 的数据层与公共常量

问题4 = 在**实时波动电价**下重算问题2 与问题3：
  · 电价：附件4（365 天 × 144 时段，逐日逐时段不同）替代附件1 的恒定价
  · 负载/光伏实际：附件2
  · 光伏预报：附件3（仅问题3 使用）

与问题2/3 的全部约定保持一致：
  时段划分 6/6/6/6 小时；双侧效率 0.9；储能 1200–10800 kWh、5000 kW；
  结算口径 C = c·A + 0.5c|A−P|；负载用 lag-7 外推、光伏用 ma7 外推。
"""
import os, sys, io
sys.stdout.reconfigure(encoding='utf-8', errors='replace')
import numpy as np
import pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
DATA = r'C:\Users\35941\Desktop\C题\附件'
RES_DIR = os.path.join(ROOT, 'results')
OUT_DIR = os.path.join(ROOT, 'output')
FIG_DIR = os.path.join(ROOT, 'figures')
for _d in (RES_DIR, OUT_DIR, FIG_DIR):
    os.makedirs(_d, exist_ok=True)

# ---------- 常量（与问题2/3 一致）----------
DT = 1.0 / 6.0
NT = 144
E_INIT, E_MIN, E_MAX = 6000.0, 1200.0, 10800.0
P_MAX = 5000.0
ETA_C = ETA_D = 0.9
DE = P_MAX * DT                     # 单时段最大充放电量 833.33 kWh
BIAS_UP, BIAS_DOWN, EM_K = 1.5, 0.5, 5.0
SAVE_START = pd.Timestamp('2025-02-01')          # 1 月作预热期
KEY_DATES = [pd.Timestamp('2025-03-20'), pd.Timestamp('2025-06-21'),
             pd.Timestamp('2025-09-23'), pd.Timestamp('2025-12-21')]
SLOT_HOURS = [0, 6, 12, 18]
SLOT_START_T = [1, 37, 73, 109]
SLOT_END_T = [36, 72, 108, 144]
SLOT_LB = [('0:00+1' if (i + 1) == 144 else '%d:%02d' % divmod(((i + 1) * 10) % 1440, 60))
           for i in range(NT)]

TPL4_2 = os.path.join(DATA, '附件5', 'result4-2.xlsx')
TPL4_3 = os.path.join(DATA, '附件5', 'result4-3.xlsx')


# ==================== 数据加载 ====================
def load_price_a4():
    """附件4：实时波动电价 (365, 144)，元/kWh。"""
    df = pd.read_excel(os.path.join(DATA, '附件4.xlsx'), index_col=0)
    vals = df.iloc[:, :NT].apply(pd.to_numeric, errors='raise').to_numpy(float)
    assert vals.shape == (365, NT), vals.shape
    return vals, pd.to_datetime(df.index)


def load_year(sheet):
    """附件2：小区负载 / 光伏发电实际功率 (365, 144)，kW。"""
    df = pd.read_excel(os.path.join(DATA, '附件2.xlsx'), sheet_name=sheet, index_col=0)
    vals = df.iloc[:, :NT].apply(pd.to_numeric, errors='raise').to_numpy(float)
    assert vals.shape == (365, NT), vals.shape
    return pd.to_datetime(df.index), vals


def load_forecast():
    """附件3：光伏预报 (365, 4, 24)，kW。"""
    df = pd.read_excel(os.path.join(DATA, '附件3.xlsx'))
    df.iloc[:, 0] = pd.to_datetime(df.iloc[:, 0]).ffill()     # 日期列仅每天首行有值
    kmap = {'0:00': 0, '6:00': 1, '12:00': 2, '18:00': 3}
    fc = np.zeros((365, 4, 24))
    for _, row in df.iterrows():
        d = (pd.Timestamp(row.iloc[0]).normalize() - pd.Timestamp('2025-01-01')).days
        if 0 <= d < 365:
            fc[d, kmap[str(row.iloc[1])]] = row.iloc[2:26].to_numpy(float)
    return None, fc


def stage_forecast(fc_day, slot_idx, prev):
    """第 slot_idx 个发布时刻可用的 144 个 10 分钟光伏预报（kW）。

    h:00 发布的预报覆盖 h+1 时起至当日 24:00；更早的时段沿用上一次预报。
    """
    h = SLOT_HOURS[slot_idx]
    t_hour = (h + np.arange(1, 25)) * 6
    y = np.asarray(fc_day[slot_idx], float)
    out = np.zeros(NT) if prev is None else np.array(prev, float)
    t_all = np.arange(1, NT + 1)
    mask = t_all >= 6 * (h + 1)
    out[mask] = np.interp(t_all[mask], t_hour, y)
    return np.maximum(0.0, out)


def lag7(X, lag=7):
    """lag-7 预测（负载用）。"""
    n = X.shape[0]
    P = np.zeros_like(X)
    for d in range(n):
        P[d] = X[d - lag] if d >= lag else (X[:d].mean(axis=0) if d > 0 else X[d])
    return P


def ma7(X, win=7):
    """前 win 天滑动均值（光伏用）。"""
    n = X.shape[0]
    P = np.zeros_like(X)
    for d in range(n):
        lo = max(0, d - win)
        P[d] = X[lo:d].mean(axis=0) if d > 0 else X[d]
    return P


def rolling_sigma(L, V, Lp, Vp, win=60):
    """逐日逐时段净负荷残差标准差（只用当日之前数据）。"""
    n = L.shape[0]
    sig = np.zeros((n, L.shape[1]))
    for d in range(n):
        lo = max(0, d - win)
        if d - lo < 5:
            sig[d] = 50.0
        else:
            e = (Lp[lo:d] - L[lo:d]) - (Vp[lo:d] - V[lo:d])
            sig[d] = e.std(axis=0)
    return sig


if __name__ == '__main__':
    price, dates_p = load_price_a4()
    dts, L = load_year('小区负载')
    _, V = load_year('光伏发电实际功率')
    print('附件4 电价: %s, 范围 [%.4f, %.4f] 元/kWh' % (price.shape, price.min(), price.max()))
    print('  日均电价前 5 天:', np.round(price[:5].mean(axis=1), 4))
    print('  逐日差异（日均电价的 σ）: %.4f' % price.mean(axis=1).std())
    print('附件2 负载: %s [%.1f, %.1f] kW' % (L.shape, L.min(), L.max()))
    print('附件2 光伏: %s [%.1f, %.1f] kW' % (V.shape, V.min(), V.max()))
    fc = load_forecast()[1]
    print('附件3 预报: %s [%.1f, %.1f] kW' % (fc.shape, fc.min(), fc.max()))
    # 对比恒定价
    p1 = pd.read_excel(os.path.join(DATA, '附件1.xlsx'))['电价'].to_numpy(float)[:NT]
    print('附件1 恒定价: 范围 [%.4f, %.4f]，日间相同' % (p1.min(), p1.max()))
