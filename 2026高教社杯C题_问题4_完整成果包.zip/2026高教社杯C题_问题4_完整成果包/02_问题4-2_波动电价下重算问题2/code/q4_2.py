# -*- coding: utf-8 -*-
"""
q4_2.py —— 问题4-2：**实时波动电价**下重算"问题2"（全年计划购电策略）

与问题2 的唯一区别：电价由"每天相同"改为附件4 的**逐日逐时段**电价。
其余全部沿用问题2 的最终方案：
  · 当天负载/光伏不可知 → 负载 lag-7 外推、光伏 ma7 外推（分开预测）
  · 安全裕度 z（需重新扫描，因电价波动改变了代价结构）
  · 执行层：日内 LP 闭环（问题2 已验证最优）

费用（题面）：F = Σ c_t·P_t·Δt（按计划购电量） + Σ 5c_t·em_t
"""
import os, sys, io, json, argparse, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.stdout.reconfigure(encoding='utf-8', errors='replace')
import numpy as np
from scipy.optimize import linprog
from common_q4 import (DT, NT, E_INIT, E_MIN, E_MAX, P_MAX, ETA_C, ETA_D, DE,
                       EM_K, SAVE_START, RES_DIR, load_price_a4, load_year, lag7, ma7,
                       rolling_sigma)


def solve_plan(price_d, D, E0, pv_sur):
    """日前计划 LP：min Σ c·P  s.t. P + dis − ch − curt = D（D 为需求，kWh）。"""
    n, nv = NT, 5 * NT
    P, C, Dv, CU, E = 0, n, 2 * n, 3 * n, 4 * n
    c = np.zeros(nv); c[P:P + n] = price_d * DT
    A_eq, b_eq = [], []
    for k in range(n):
        row = np.zeros(nv)
        row[P + k] = 1.0; row[Dv + k] = 1.0; row[C + k] = -1.0; row[CU + k] = -1.0
        A_eq.append(row); b_eq.append(D[k])
    for k in range(n):
        row = np.zeros(nv)
        row[E + k] = 1.0
        if k > 0:
            row[E + k - 1] = -1.0
        row[C + k] = -ETA_C; row[Dv + k] = 1.0 / ETA_D
        A_eq.append(row); b_eq.append(E0 if k == 0 else 0.0)
    bounds = ([(0.0, None)] * n + [(0.0, DE)] * n + [(0.0, DE)] * n
              + [(0.0, float(pv_sur[k])) for k in range(n)] + [(E_MIN, E_MAX)] * n)
    res = linprog(c, A_eq=np.array(A_eq), b_eq=np.array(b_eq), bounds=bounds, method='highs')
    if not res.success:
        raise RuntimeError('日前 LP 失败: ' + res.message)
    x = res.x
    return x[P:P + n], x[C:C + n], x[Dv:Dv + n], x[CU:CU + n], x[E:E + n]


def execute_intraday_lp(price_d, L_act, V_act, plan_buy, E0):
    """日内 LP（闭环）：计划量锁定，储能逐时段最优使用以最小化 Σ5c·U。"""
    G, C, D, CU, S, U = 0, NT, 2 * NT, 3 * NT, 4 * NT, 5 * NT
    nv = 6 * NT
    c = np.zeros(nv); c[U:U + NT] = EM_K * price_d
    A_eq, b_eq = [], []
    for t in range(NT):
        row = np.zeros(nv)
        row[G + t] = 1.0; row[C + t] = -1.0; row[D + t] = 1.0; row[CU + t] = -1.0
        A_eq.append(row); b_eq.append(L_act[t] * DT - V_act[t] * DT)
    for t in range(NT):
        row = np.zeros(nv)
        row[S + t] = 1.0
        if t > 0:
            row[S + t - 1] = -1.0
        row[C + t] = -ETA_C; row[D + t] = 1.0 / ETA_D
        A_eq.append(row); b_eq.append(E0 if t == 0 else 0.0)
    A_ub, b_ub = [], []
    for t in range(NT):
        row = np.zeros(nv)
        row[G + t] = 1.0; row[U + t] = -1.0
        A_ub.append(row); b_ub.append(float(plan_buy[t]))
    bounds = ([(0.0, None)] * NT + [(0.0, DE)] * NT + [(0.0, DE)] * NT
              + [(0.0, float(V_act[t] * DT)) for t in range(NT)]
              + [(E_MIN, E_MAX)] * NT + [(0.0, None)] * NT)
    res = linprog(c, A_ub=np.array(A_ub), b_ub=np.array(b_ub),
                  A_eq=np.array(A_eq), b_eq=np.array(b_eq), bounds=bounds, method='highs')
    if not res.success:
        raise RuntimeError('日内 LP 失败: ' + res.message)
    x = res.x
    return x[U:U + NT], x[C:C + NT], x[D:D + NT], x[CU:CU + NT], x[S:S + NT], float(x[S + NT - 1])


def run(price, L, V, z=0.0, verbose=True):
    Lp, Vp = lag7(L), ma7(V)
    sig = rolling_sigma(L, V, Lp, Vp, 60)
    soc = E_INIT
    recs = []
    for d in range(L.shape[0]):
        D = (Lp[d] - Vp[d]) * DT + z * sig[d] * DT
        pv_sur = np.maximum(0.0, (Vp[d] - Lp[d]) * DT)
        P, ch_p, dis_p, curt_p, _ = solve_plan(price[d], D, soc, pv_sur)
        em, ch, dis, curt, E, soc = execute_intraday_lp(price[d], L[d], V[d], P, soc)
        soc = float(min(max(soc, E_MIN), E_MAX))
        recs.append(dict(P=P, em=em, ch=ch, dis=dis, curt=curt, E=E,
                         plan_cost=float((P * price[d]).sum()),
                         em_cost=float((EM_K * price[d] * em).sum())))
        if verbose and (d + 1) % 100 == 0:
            print('  已推演 %d / %d 天' % (d + 1, L.shape[0]))
    return recs


def summarize(recs, dates):
    import pandas as pd
    idx = [i for i, d in enumerate(dates) if pd.Timestamp(d) >= SAVE_START]
    g = lambda k: float(sum(recs[i][k] for i in idx))
    pc, ec = g('plan_cost'), g('em_cost')
    return dict(days=len(idx), plan_kWh=float(sum(recs[i]['P'].sum() for i in idx)),
                plan_cost=pc, em_cost=ec, total_cost=pc + ec,
                em_kWh=float(sum(recs[i]['em'].sum() for i in idx)),
                curt_kWh=float(sum(recs[i]['curt'].sum() for i in idx)),
                charge_kWh=float(sum(recs[i]['ch'].sum() for i in idx)),
                discharge_kWh=float(sum(recs[i]['dis'].sum() for i in idx)),
                em_days=int(sum(1 for i in idx if recs[i]['em'].sum() > 1e-6)))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--z', type=float, default=0.0)
    ap.add_argument('--tag', default=None)
    a = ap.parse_args()
    price, _ = load_price_a4()
    dates, L = load_year('小区负载')
    _, V = load_year('光伏发电实际功率')
    print('问题4-2（波动电价）：负载 lag-7 + 光伏 ma7，裕度 z=%.4f' % a.z)
    t0 = time.time()
    recs = run(price, L, V, z=a.z)
    s = summarize(recs, dates)
    s['z'] = a.z; s['seconds'] = round(time.time() - t0, 1)
    print('计划购电 %.0f kWh（%.2f 元）| 紧急 %.0f kWh（%.2f 元）| 总费用 %.2f 元 | %.1f s'
          % (s['plan_kWh'], s['plan_cost'], s['em_kWh'], s['em_cost'], s['total_cost'],
             s['seconds']))
    tag = a.tag or ('q42_z%.4f' % a.z)
    json.dump(s, io.open(os.path.join(RES_DIR, '%s.json' % tag), 'w', encoding='utf-8'),
              ensure_ascii=False, indent=2)
    print('已写出 results/%s.json' % tag)


if __name__ == '__main__':
    main()
