# -*- coding: utf-8 -*-
"""probe_a4.py —— 勘察附件4（实时期价）与 result4-2 / result4-3 模板。"""
import os, sys, io
sys.stdout.reconfigure(encoding='utf-8', errors='replace')
import openpyxl

AD = r'C:\Users\35941\Desktop\C题\附件'
print('=' * 78)
print('附件4 电价数据')
wb = openpyxl.load_workbook(os.path.join(AD, '附件4.xlsx'), read_only=True, data_only=True)
print('工作表:', wb.sheetnames)
for sn in wb.sheetnames:
    ws = wb[sn]
    print('\n--- sheet %r: %d 行 × %d 列 ---' % (sn, ws.max_row, ws.max_column))
    for i, row in enumerate(ws.iter_rows(values_only=True)):
        if i >= 4:
            break
        cells = [str(v)[:20] if v is not None else '' for v in row[:7]]
        print('   行%d: %s' % (i + 1, ' | '.join(cells)))
    # 第 1 列取值分布（判断结构）
    vals = {}
    for i, row in enumerate(ws.iter_rows(min_col=1, max_col=1, values_only=True)):
        if i == 0:
            continue
        vals[str(row[0])[:10]] = vals.get(str(row[0])[:10], 0) + 1
    print('   第1列前 6 种取值:', dict(list(vals.items())[:6]), '共', len(vals), '种')
wb.close()

for tpl in ('result4-2.xlsx', 'result4-3.xlsx'):
    print('\n' + '=' * 78)
    print(tpl)
    p = os.path.join(AD, '附件5', tpl)
    if not os.path.exists(p):
        print('  不存在'); continue
    wb = openpyxl.load_workbook(p, read_only=True)
    print('  工作表:', wb.sheetnames)
    for sn in wb.sheetnames:
        ws = wb[sn]
        print('  --- %r: %d 行 × %d 列 ---' % (sn, ws.max_row, ws.max_column))
        for i, row in enumerate(ws.iter_rows(values_only=True)):
            if i >= 4:
                break
            cells = [str(v)[:18] if v is not None else '' for v in row[:6]]
            print('     行%d: %s' % (i + 1, ' | '.join(cells)))
    wb.close()
