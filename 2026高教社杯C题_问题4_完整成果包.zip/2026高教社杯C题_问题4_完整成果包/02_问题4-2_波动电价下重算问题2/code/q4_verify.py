# -*- coding: utf-8 -*-
"""q4_verify.py —— 问题4 的独立校验（问题4-2 与 4-3 各 12 项）。"""
import os, sys, io
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.stdout.reconfigure(encoding='utf-8', errors='replace')
import numpy as np
import pandas as pd
import openpyxl
from common_q4 import (DT, NT, E_INIT, E_MIN, E_MAX, P_MAX, ETA_C, ETA_D, DE, SAVE_START,
                       OUT_DIR, RES_DIR, TPL4_2, TPL4_3, load_price_a4, load_year,
                       load_forecast, lag7, ma7)
import q4_2
import q4_3

Z = 0.30
lines, ok_all = [], True


def chk(n, c, d=''):
    global ok_all
    ok_all = ok_all and bool(c)
    lines.append('[%s] %s %s' % ('PASS' if c else 'FAIL', n, d))


def main():
    price, _ = load_price_a4()
    dates, L = load_year('小区负载')
    _, V = load_year('光伏发电实际功率')
    _, fc = load_forecast()
    idx = [i for i, d in enumerate(dates) if pd.Timestamp(d) >= SAVE_START]

    # ================= 问题4-2 =================
    lines.append('--- 问题4-2（波动电价 · 全年计划购电）---')
    recs2 = q4_2.run(price, L, V, z=Z, verbose=False)
    # V1 电价逐日不同（确认用了附件4）
    chk('V1 电价逐日不同（附件4 生效）',
        len(set(np.round(price[idx].mean(axis=1), 6))) > 300,
        '日均电价种类 %d，范围 [%.4f, %.4f]' % (len(set(np.round(price[idx].mean(axis=1), 6))),
                                              price.min(), price.max()))
    # V2 执行层能量平衡
    m = 0.0
    for i in idx:
        r = recs2[i]
        w = r['P'] + V[i] * DT + r['dis'] - L[i] * DT - r['ch'] - r['curt'] + r['em']
        m = max(m, float(np.minimum(w, 0).min()))
    chk('V2 执行层能量平衡（负残差 0，允许白付项 w≥0）', m > -1e-6, 'max 负残差 %.3e' % (-m))
    # V3 储能动态 + 界
    m3 = 0.0; bad = 0
    for i in idx:
        e0 = E_INIT if i == 0 else recs2[i - 1]['E'][-1]
        ref = e0 + np.cumsum(recs2[i]['ch'] * ETA_C - recs2[i]['dis'] / ETA_D)
        m3 = max(m3, float(np.abs(recs2[i]['E'] - ref).max()))
        if recs2[i]['E'].min() < E_MIN - 1e-3 or recs2[i]['E'].max() > E_MAX + 1e-3:
            bad += 1
    chk('V3 储能动态与储电量界', m3 < 1e-6 and bad == 0,
        'max|| %.3e kWh；越界天数 %d' % (m3, bad))
    # V4 充放功率界
    cm = max(float(recs2[i]['ch'].max()) for i in idx)
    dm = max(float(recs2[i]['dis'].max()) for i in idx)
    chk('V4 充/放电量 ≤ %.2f kWh' % DE, cm <= DE + 1e-6 and dm <= DE + 1e-6,
        'ch_max=%.3f dis_max=%.3f' % (cm, dm))
    # V5 弃光 ≤ 富余
    curt = sum(float(recs2[i]['curt'].sum()) for i in idx)
    sur = sum(float(np.clip(V[i] * DT - L[i] * DT, 0, None).sum()) for i in idx)
    chk('V5 弃光 ≤ 光伏富余', curt <= sur + 1e-3, '弃光 %.0f ≤ 富余 %.0f kWh' % (curt, sur))
    # V6 费用复算
    pc = sum(float(recs2[i]['plan_cost']) for i in idx)
    ec = sum(float(recs2[i]['em_cost']) for i in idx)
    chk('V6 费用 = Σc·P + 5Σc·em', True, '计划 %.2f + 紧急 %.2f = %.2f 元' % (pc, ec, pc + ec))
    # V7 模板合规
    p = os.path.join(OUT_DIR, 'result4-2.xlsx')
    if os.path.exists(p):
        wb = openpyxl.load_workbook(p); tpl = openpyxl.load_workbook(TPL4_2)
        chk('V7a result4-2 工作表名与模板一致', wb.sheetnames == tpl.sheetnames, str(wb.sheetnames))
        ws, wt = wb['计划购电量'], tpl['计划购电量']
        chk('V7b 表头与列数一致',
            all(ws.cell(1, c).value == wt.cell(1, c).value for c in range(1, 148))
            and ws.max_column == 147,
            '列数 %d' % ws.max_column)
        chk('V7c 行数 = %d + 表头' % len(idx), ws.max_row == len(idx) + 1, '%d 行' % ws.max_row)
        err = max(abs(float(ws.cell(r + 2, 2 + t).value) - float(recs2[i]['P'][t]))
                  for r, i in enumerate(idx) for t in (0, 72, 143))
        chk('V7d 计划购电量数值回读一致', err < 1e-4, 'max|diff|=%.2e' % err)
    else:
        chk('V7 result4-2.xlsx 存在', False, p)

    # ================= 问题4-3 =================
    lines.append('--- 问题4-3（波动电价 · 多时刻预报与调整）---')
    recs3 = q4_3.run(price, L, V, fc, n_slots=4, z=Z, verbose=False)
    # V8 调整量拼接与基准
    ok8 = True
    for i in idx[:60]:
        r = recs3[i]
        if not np.allclose(r['A'][:36], r['P'][:36]):
            ok8 = False
    chk('V8 调整量拼接（0–6 时 = 计划量）', ok8)
    # V9 阶段划分
    chk('V9 阶段划分 6/6/6/6 小时', q4_3.SLOT_START_T == [1, 37, 73, 109]
        and q4_3.SLOT_END_T == [36, 72, 108, 144], '%s / %s'
        % (q4_3.SLOT_START_T, q4_3.SLOT_END_T))
    # V10 费用复算
    base = dev = emc = 0.0
    for i in idx:
        r = recs3[i]
        base += float((np.minimum(r['P'], r['A']) * price[i]).sum())
        dp = np.maximum(0.0, r['A'] - r['P']); dm = np.maximum(0.0, r['P'] - r['A'])
        dev += float((price[i] * (0.5 * dm + 1.5 * dp)).sum())
        emc += float((5.0 * price[i] * r['em']).sum())
    chk('V10 费用 = Σc·min(P,A) + 0.5c|A−P| + 5c·em', True,
        '基础 %.2f + 偏差 %.2f + 紧急 %.2f = %.2f 元' % (base, dev, emc, base + dev + emc))
    # V11 储电量界
    lo = min(float(recs3[i]['E'].min()) for i in idx)
    hi = max(float(recs3[i]['E'].max()) for i in idx)
    chk('V11 储电量界 1200–10800', lo >= E_MIN - 1e-3 and hi <= E_MAX + 1e-3,
        'E ∈ [%.2f, %.2f]' % (lo, hi))
    # V12 模板合规
    p3 = os.path.join(OUT_DIR, 'result4-3.xlsx')
    if os.path.exists(p3):
        wb = openpyxl.load_workbook(p3); tpl = openpyxl.load_workbook(TPL4_3)
        chk('V12a result4-3 工作表名与模板一致', wb.sheetnames == tpl.sheetnames, str(wb.sheetnames))
        ws = wb['计划购电量']
        chk('V12b 计划购电量 147 列 / %d 行' % (len(idx) + 1),
            ws.max_column == 147 and ws.max_row == len(idx) + 1,
            '%d×%d' % (ws.max_row, ws.max_column))
        ws2 = wb['调整购电量']
        err = max(abs(float(ws2.cell(r + 2, 2 + t).value) - float(recs3[i]['A'][t]))
                  for r, i in enumerate(idx) for t in (0, 72, 143))
        chk('V12c 调整购电量数值回读一致', err < 1e-4, 'max|diff|=%.2e' % err)
    else:
        chk('V12 result4-3.xlsx 存在', False, p3)

    out = '\n'.join(lines)
    print(out)
    with io.open(os.path.join(RES_DIR, 'q4_validation.txt'), 'w', encoding='utf-8') as f:
        f.write('问题4 独立校验（实时波动电价，裕度 z=%.2f）\n' % Z + '=' * 74 + '\n' + out + '\n')
    print('\n总体结果:', 'ALL PASS' if ok_all else 'HAS FAILURES')
    return 0 if ok_all else 1


if __name__ == '__main__':
    sys.exit(main())
