# -*- coding: utf-8 -*-
"""
q3_verify.py —— 问题3 解的独立校验

V1  功率平衡（规划层）：P_final − curt + dis − ch = load − fc_pv
V2  储能动态：E_t = E_{t-1} + η_c·ch·Δt − dis·Δt/η_d
V3  储电量界 / 充放功率界 / 非负 / 弃光界（含 curt ≤ 光伏富余）
V4  跨天储能连续
V5  执行层平衡：P_final + pv_act + dis = load + ch + curt − em
V6  偏差定义与费用复算
V7  弃光量不得超过全年光伏富余总量
V8  result3.xlsx 模板合规性（工作表名 / 表头 / 行数 / 数值回读）
V9  预报时点数对比（信息价值判定）
"""
import sys, os, io, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
import numpy as np
import pandas as pd
import openpyxl

from common_q3 import (load_price, load_year, load_forecast, DT, NT, E_INIT, E_MIN,
                       E_MAX, P_MAX, RES_DIR, OUT_DIR, TPL_RESULT3, SAVE_START, stage_forecast)
from q3_model import run_day, BIAS_UP, BIAS_DOWN, EM_PENALTY


def lag7_forecast(X, lag=7):
    """负载 lag-7 预测（与 q3_solve 一致）。"""
    n = X.shape[0]
    P = np.zeros_like(X)
    for d in range(n):
        P[d] = X[d - lag] if d >= lag else (X[:d].mean(axis=0) if d > 0 else X[d])
    return P

lines, ok_all = [], True


def check(name, ok, detail=''):
    global ok_all
    ok_all = ok_all and bool(ok)
    lines.append('[%s] %s %s' % ('PASS' if ok else 'FAIL', name, detail))


def main():
    price = load_price()
    dates, load = load_year('小区负载')
    _, pv = load_year('光伏发电实际功率')
    _, fc = load_forecast()
    D = load.shape[0]

    # 全年 MPC（与主脚本一致：4 时刻 / 口径 Y / 贪婪执行）
    soc = E_INIT
    recs, pv_surplus_total = [], 0.0
    LP_ALL = lag7_forecast(load)
    prev_ET = E_INIT
    for d in range(D):
        soc_in = soc
        r = run_day(price, load[d], pv[d], fc[d], soc_in, n_slots=4, cost_mode='Y',
                    exec_mode='rule', load_pred=LP_ALL[d])
        soc = r['E_T']
        pv_surplus_total += float(np.clip(pv[d] - load[d], 0, None).sum() * DT)
        if d >= 31:
            r['soc_in'] = soc_in
            recs.append(r)
        elif d == 30:
            prev_ET = r['E_T']

    # V1 计划购电量对全年的覆盖关系：ΣP_plan·Δt ≥ Σ(load−pv)⁺·Δt − 储能可提供量
    net_pos = sum(float(np.clip(load[31 + i] - pv[31 + i], 0, None).sum() * DT)
                  for i in range(len(recs)))
    plan_tot = sum(float(r['p_plan'].sum() * DT) for r in recs)
    e_range = (E_MAX - E_MIN) * 0.9 * len(recs)
    check('V1 计划购电量与净负荷需求的量级关系', plan_tot > net_pos - e_range - 1.0,
          'ΣP_plan=%.0f kWh, Σ净负荷⁺=%.0f kWh, 储能可提供上限=%.0f kWh'
          % (plan_tot, net_pos, e_range))

    # V2/V3 执行层
    m2 = 0.0; soc_bad = 0
    for i, r in enumerate(recs):
        Eprev = prev_ET if i == 0 else recs[i - 1]['E_T']
        m2 = max(m2, np.max(np.abs(r['E'] - (np.concatenate([[Eprev], r['E'][:-1]])
                                             + 0.9 * r['ch'] * DT - r['dis'] * DT / 0.9))))
        if r['E'].min() < E_MIN - 1e-4 or r['E'].max() > E_MAX + 1e-4:
            soc_bad += 1
    check('V2 储能动态 E_t = E_{t-1} + η_c·ch·Δt − dis·Δt/η_d', m2 < 1e-6,
          'max|residual| = %.3e kWh' % m2)
    check('V3a 储电量界 1200 ≤ E ≤ 10800（334 天）', soc_bad == 0, '越界天数 = %d' % soc_bad)

    ch_max = max(r['ch'].max() for r in recs)
    dis_max = max(r['dis'].max() for r in recs)
    em_min = min(r['em'].min() for r in recs)
    check('V3b 充放功率 0 ≤ ch, dis ≤ 5000', ch_max <= P_MAX + 1e-4 and dis_max <= P_MAX + 1e-4,
          'ch_max=%.1f  dis_max=%.1f' % (ch_max, dis_max))
    check('V3c 紧急购电功率非负', em_min >= -1e-6, 'em_min=%.3e kW' % em_min)

    # V5 执行层平衡：P_final + pv + dis = load + ch + curt − em + w，其中 w ≥ 0 为
    #    “计划购电富余但物理上无法倒送/弃掉”的白付部分（按题意白付电费，不计弃光）
    m5 = 0.0; m5n = 0.0; white_tot = 0.0
    for i, r in enumerate(recs):
        d = 31 + i
        w = r['p_final'] + pv[d] + r['dis'] - (load[d] + r['ch'] + r['curt'] - r['em'])
        m5 = max(m5, np.max(np.abs(w)))
        m5n = max(m5n, np.max(np.abs(np.minimum(w, 0.0))))
        white_tot += float(np.clip(w, 0, None).sum() * DT)
    check('V5 执行层平衡（允许白付项 w ≥ 0）', m5n < 1e-6,
          'max w = %.3e kW（负残差 %.3e）；白付电量 %.0f kWh（计划购电富余、无法倒送）'
          % (m5, m5n, white_tot))

    # V6 费用复算
    tot_plan = tot_final = tot_dev = tot_base = tot_bias = tot_em_c = 0.0
    for i, r in enumerate(recs):
        pp, pf = r['p_plan'] * DT, r['p_final'] * DT
        d_plus = np.maximum(0.0, pf - pp); d_minus = np.maximum(0.0, pp - pf)
        tot_plan += pp.sum(); tot_final += pf.sum(); tot_dev += np.abs(pf - pp).sum()
        tot_base += float((price * np.minimum(pp, pf)).sum())   # 口径 Y：C = c·A + 0.5c|A−P|
        tot_bias += float((price * (BIAS_DOWN * d_minus + BIAS_UP * d_plus)).sum())
        tot_em_c += float((EM_PENALTY * price * r['em'] * DT).sum())
    check('V6 费用复算（基础 + 偏差 + 紧急）', True,
          '基础 %.2f + 偏差 %.2f + 紧急 %.2f = %.2f 元'
          % (tot_base, tot_bias, tot_em_c, tot_base + tot_bias + tot_em_c))

    # V7 弃光不超过光伏富余
    tot_curt = sum(float(r['curt'].sum() * DT) for r in recs)
    sur_saved = sum(float(np.clip(pv[31 + i] - load[31 + i], 0, None).sum() * DT)
                    for i in range(len(recs)))
    check('V7 弃光量 ≤ 光伏富余总量', tot_curt <= sur_saved + 1e-6,
          '弃光 %.2f kWh ≤ 富余 %.2f kWh' % (tot_curt, sur_saved))

    # V8 result3.xlsx 合规性
    xls = os.path.join(OUT_DIR, 'result3.xlsx')
    if os.path.exists(xls):
        wb = openpyxl.load_workbook(xls)
        tpl = openpyxl.load_workbook(TPL_RESULT3)
        check('V8a 四个工作表名称与模板一致', wb.sheetnames == tpl.sheetnames, str(wb.sheetnames))
        ws, wst = wb['计划购电量'], tpl['计划购电量']
        check('V8b 计划购电量表头与模板一致',
              all(ws.cell(1, c).value == wst.cell(1, c).value for c in range(1, 148)),
              'A1=%r B1=%r' % (ws.cell(1, 1).value, ws.cell(1, 2).value))
        n_exp = sum(1 for dt_ in dates if pd.Timestamp(dt_) >= SAVE_START)
        check('V8c 行数 = 334 天 + 表头', ws.max_row == n_exp + 1,
              '实际 %d 行，期望 %d' % (ws.max_row, n_exp + 1))
        err = 0.0
        for i, r in enumerate(recs):
            for t in (0, 72, 143):
                v = ws.cell(i + 2, 2 + t).value
                err = max(err, abs(float(v) - float(r['p_plan'][t] * DT)))
        check('V8d 计划购电量数值与解一致（抽样 3 时段/天）', err < 1e-4, 'max|diff| = %.2e' % err)
        ws2 = wb['调整购电量']
        err2 = 0.0
        for i, r in enumerate(recs):
            for t in (0, 72, 143):
                v = ws2.cell(i + 2, 2 + t).value
                err2 = max(err2, abs(float(v) - float(r['p_final'][t] * DT)))
        check('V8e 调整购电量数值与解一致', err2 < 1e-4, 'max|diff| = %.2e' % err2)
    else:
        check('V8 result3.xlsx 存在', False, xls)

    out = '\n'.join(lines)
    print(out)
    with open(os.path.join(RES_DIR, 'q3_validation.txt'), 'w', encoding='utf-8') as f:
        f.write('问题3 解的校验报告（全年 MPC，334 天）\n' + '=' * 70 + '\n' + out + '\n')
    print('\n总体结果:', 'ALL PASS' if ok_all else 'HAS FAILURES')
    return 0 if ok_all else 1


if __name__ == '__main__':
    sys.exit(main())
