# -*- coding: utf-8 -*-
"""
q3_solve.py —— 问题3 全年 MPC 求解 + 结果导出

用法：
    python q3_solve.py                 # 默认 4 个预报时刻（0:00/6:00/12:00/18:00）
    python q3_solve.py --slots 2       # 只用 0:00 与 12:00 的预报（回答"是否需要其他时刻"）
    python q3_solve.py --slots 8       # 每 3 小时一次预报（加密对照）

输出：
    output/result3.xlsx            问题3 结果文件（严格套附件5 模板，4 个工作表）
    results/q3_daily_<tag>.csv     逐日汇总
    results/q3_table1/2/3_<tag>.csv 论文表 1/2/3
    results/q3_timeseries_<tag>_<date>.csv  指定日期时序明细
    results/q3_summary_<tag>.json  关键指标
"""
import sys, os, io, json, csv, argparse, time, shutil
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

import numpy as np
import pandas as pd
import openpyxl

from common_q3 import (load_price, load_year, load_forecast, DT, NT, E_INIT,
                       RES_DIR, OUT_DIR, TPL_RESULT3, SAVE_START, KEY_DATES,
                       TABLE1_CLOCKS, clock_to_t, t_to_interval)
from q3_model import run_day, BIAS_UP, BIAS_DOWN, EM_PENALTY

PERIODS = [('0:00-4:00', 1, 24), ('4:00-8:00', 25, 48), ('8:00-12:00', 49, 72),
           ('12:00-16:00', 73, 96), ('16:00-20:00', 97, 120), ('20:00-24:00', 121, 144)]


def run_year(price, load, pv, fc, n_slots=4, jan_days=31, verbose=True,
             cost_mode='Y', exec_mode='plan'):
    """全年 MPC：1 月预热，2.1 起记录。"""
    D = load.shape[0]
    soc = E_INIT
    recs = []
    t0 = time.time()
    for d in range(D):
        r = run_day(price, load[d], pv[d], fc[d], soc, n_slots=n_slots, cost_mode=cost_mode, exec_mode=exec_mode)
        soc = r['E_T']
        if d >= jan_days:
            # 费用明细
            pf = r['p_final'] * DT
            pp = r['p_plan'] * DT
            dplus = np.maximum(0.0, pf - pp)
            dminus = np.maximum(0.0, pp - pf)
            # 口径 Y：基础电费按最终执行量结算；偏差部分分别按 0.5c / 1.5c
            # 口径 X：基础电费按计划量锁定；阶段 k 只付偏差费
            if cost_mode == 'Y':
                base = price * np.minimum(pp, pf)
            else:
                base = price * pp
            r.update({
                'plan_buy_kWh': float(pp.sum()), 'final_buy_kWh': float(pf.sum()),
                'base_cost': float(base.sum()),
                'bias_cost': float((price * (BIAS_DOWN * dminus + BIAS_UP * dplus)).sum()),
                'em_cost': float((EM_PENALTY * price * r['em'] * DT).sum()),
                'em_buy_kWh': float(r['em'].sum() * DT),
                'curtail_kWh': float(r['curt'].sum() * DT),
                'ch_kWh': float(r['ch'].sum() * DT), 'dis_kWh': float(r['dis'].sum() * DT),
                'dev_kWh': float(np.abs(pf - pp).sum()),
            })
            r['total_cost'] = r['base_cost'] + r['bias_cost'] + r['em_cost']
            recs.append(r)
        if verbose and (d - jan_days + 1) % 60 == 0 and d >= jan_days:
            print('  已完成 %d / %d 天' % (d - jan_days + 1, D - jan_days))
    el = time.time() - t0
    if verbose:
        print('全年 MPC 完成，用时 %.1f 秒' % el)
    return recs, el


def write_result3(dates, recs, path):
    shutil.copyfile(TPL_RESULT3, path)
    wb = openpyxl.load_workbook(path)

    # ---- 计划购电量 / 调整购电量 ----
    for sheet, key in (('计划购电量', 'p_plan'), ('调整购电量', 'p_final')):
        ws = wb[sheet]
        for i, r in enumerate(recs):
            row = i + 2
            vals = r[key] * DT
            for t in range(NT):
                ws.cell(row=row, column=2 + t).value = round(float(vals[t]), 4)
            ws.cell(row=row, column=2 + NT).value = round(float(vals.sum()), 4)
            if sheet == '计划购电量':
                ws.cell(row=row, column=3 + NT).value = round(
                    float((recs[i]['p_plan'] * DT * PRICE_G).sum()), 4)
            else:
                ws.cell(row=row, column=3 + NT).value = round(float(recs[i]['total_cost']), 4)

    # ---- 充放电量 ----
    ws = wb['充放电量']
    for r in range(2, ws.max_row + 1):
        for c in range(1, 7):
            ws.cell(r, c).value = None
    row = 2
    for i, rec in enumerate(recs):
        dv = pd.Timestamp(dates[i + 31]).to_pydatetime()
        E0 = E_INIT if i == 0 else recs[i - 1]['E_T']
        for k, (nm, a, b) in enumerate(PERIODS):
            ws.cell(row, 1).value = dv if k == 0 else None
            ws.cell(row, 2).value = nm
            ws.cell(row, 3).value = round(float(rec['ch'][a - 1:b].sum()), 4)
            ws.cell(row, 4).value = round(float(rec['dis'][a - 1:b].sum()), 4)
            if k == 0:
                ws.cell(row, 5).value = '0:00'
                ws.cell(row, 6).value = round(float(E0), 4)
            elif k == 1:
                ws.cell(row, 5).value = '24:00'
                ws.cell(row, 6).value = round(float(rec['E_T']), 4)
            row += 1

    # ---- 紧急购电量 ----
    ws = wb['紧急购电量']
    for r in range(2, ws.max_row + 1):
        for c in range(1, 4):
            ws.cell(r, c).value = None
    row = 2
    n_em = 0
    for i, rec in enumerate(recs):
        idx = np.where(rec['em'] > 1e-6)[0]
        if len(idx) == 0:
            continue
        groups, st = [], idx[0]
        for k in range(1, len(idx)):
            if idx[k] != idx[k - 1] + 1:
                groups.append((st, idx[k - 1])); st = idx[k]
        groups.append((st, idx[-1]))
        first = True
        for a, b in groups:
            ws.cell(row, 1).value = pd.Timestamp(dates[i + 31]).to_pydatetime() if first else None
            ws.cell(row, 2).value = '%s-%s' % (t_to_interval(a + 1).split('-')[0],
                                               t_to_interval(b + 1).split('-')[1])
            ws.cell(row, 3).value = round(float(rec['em'][a:b + 1].sum()), 4)
            row += 1; n_em += 1; first = False
    wb.save(path)
    return row - 2, n_em


PRICE_G = None


def main():
    global PRICE_G
    ap = argparse.ArgumentParser()
    ap.add_argument('--slots', type=int, default=4, choices=[1, 2, 4, 8],
                    help='预报时刻数：1=仅0:00（计划制），2=0:00+12:00，4=0/6/12/18（默认），8=每3小时')
    ap.add_argument('--tag', type=str, default=None)
    ap.add_argument('--exec', choices=['plan', 'rule'], default='rule',
                    help='执行方式：rule=储能实时贪婪响应（默认）；plan=严格按日前计划')
    ap.add_argument('--cost-mode', choices=['Y', 'X'], default='Y',
                    help='费用口径：Y=题面正确口径 C=c·A+0.5c|A−P|（默认）；'
                         'X=计划电费全额（错误口径，仅作对照）')
    args = ap.parse_args()
    tag = args.tag or ('slots%d' % args.slots)
    tag = '%s_%s' % (tag, args.exec)

    price = load_price()
    PRICE_G = price
    dates, load = load_year('小区负载')
    _, pv = load_year('光伏发电实际功率')
    _, fc = load_forecast()
    print('预报时刻数 = %d' % args.slots)
    recs, el = run_year(price, load, pv, fc, n_slots=args.slots,
                        exec_mode=args.exec, cost_mode=args.cost_mode)

    tot = lambda k: sum(r[k] for r in recs)
    pv_tot = pv[31:].sum() * DT
    load_tot = load[31:].sum() * DT
    em_days = sum(1 for r in recs if r['em_buy_kWh'] > 1e-6)
    summary = {
        'n_slots': args.slots, 'days': len(recs), 'solve_seconds': round(el, 1),
        'total_plan_buy_kWh': tot('plan_buy_kWh'),
        'total_final_buy_kWh': tot('final_buy_kWh'),
        'total_base_cost': tot('base_cost'), 'total_bias_cost': tot('bias_cost'),
        'total_emergency_kWh': tot('em_buy_kWh'), 'total_emergency_cost': tot('em_cost'),
        'total_cost': tot('total_cost'),
        'total_charge_kWh': tot('ch_kWh'), 'total_discharge_kWh': tot('dis_kWh'),
        'total_curtail_kWh': tot('curtail_kWh'),
        'total_deviation_kWh': tot('dev_kWh'),
        'pv_total_kWh': float(pv_tot), 'load_total_kWh': float(load_tot),
        'pv_utilization': 1 - tot('curtail_kWh') / float(pv_tot),
        'emergency_days': em_days,
        'saved_range': [str(dates[31])[:10], str(dates[-1])[:10]],
    }
    with open(os.path.join(RES_DIR, 'q3_summary_%s.json' % tag), 'w', encoding='utf-8') as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)

    # 逐日 CSV
    with open(os.path.join(RES_DIR, 'q3_daily_%s.csv' % tag), 'w', newline='', encoding='utf-8-sig') as f:
        w = csv.writer(f)
        w.writerow(['日期', '计划购电量_kWh', '调整购电量_kWh', '偏差量_kWh',
                    '基础电费_元', '偏差费_元', '紧急购电量_kWh', '紧急购电费_元',
                    '总费用_元', '充电_kWh', '放电_kWh', '弃光_kWh', '24:00储电量'])
        for i, r in enumerate(recs):
            w.writerow([str(dates[i + 31])[:10], '%.4f' % r['plan_buy_kWh'],
                        '%.4f' % r['final_buy_kWh'], '%.4f' % r['dev_kWh'],
                        '%.4f' % r['base_cost'], '%.4f' % r['bias_cost'],
                        '%.4f' % r['em_buy_kWh'], '%.4f' % r['em_cost'],
                        '%.4f' % r['total_cost'], '%.4f' % r['ch_kWh'],
                        '%.4f' % r['dis_kWh'], '%.4f' % r['curtail_kWh'], '%.4f' % r['E_T']])

    # 表 1/2/3 + 时序
    t1, t2, t3 = [], [], []
    for kd in KEY_DATES:
        i = int(np.where(pd.to_datetime(dates) == kd)[0][0]) - 31
        r = recs[i]
        ds = kd.strftime('%Y.%m.%d')
        pp, pf = r['p_plan'] * DT, r['p_final'] * DT
        row1 = [ds]
        for ck in TABLE1_CLOCKS:
            t = clock_to_t(ck)
            row1 += [round(float(pp[t - 1]), 4), round(float(pf[t - 1]), 4)]
        row1 += [round(r['plan_buy_kWh'], 4), round(r['final_buy_kWh'], 4), round(r['total_cost'], 4)]
        t1.append(row1)
        row2 = [ds]
        for nm, a, b in PERIODS:
            row2 += [round(float(r['ch'][a - 1:b].sum()), 4),
                     round(float(r['dis'][a - 1:b].sum()), 4)]
        E0 = E_INIT if i == 0 else recs[i - 1]['E_T']
        row2 += [round(float(E0), 4), round(float(r['E_T']), 4)]
        t2.append(row2)
        t3.append([ds, '无紧急购电' if r['em_buy_kWh'] < 1e-6 else '见 result3.xlsx',
                   round(r['em_buy_kWh'], 4)])
        with open(os.path.join(RES_DIR, 'q3_timeseries_%s_%s.csv' % (tag, kd.strftime('%Y%m%d'))),
                  'w', newline='', encoding='utf-8-sig') as f:
            w = csv.writer(f)
            w.writerow(['t', 'interval', 'price', 'load_kW', 'pv_act_kW', 'fc_pv_kW',
                        'p_plan_kW', 'p_final_kW', 'ch_kW', 'dis_kW', 'curt_kW', 'em_kW', 'E_kWh'])
            for t in range(NT):
                w.writerow([t + 1, t_to_interval(t + 1), '%.4f' % price[t],
                            '%.4f' % load[31 + i][t], '%.4f' % pv[31 + i][t], '%.4f' % 0,
                            '%.4f' % r['p_plan'][t], '%.4f' % r['p_final'][t],
                            '%.4f' % r['ch'][t], '%.4f' % r['dis'][t],
                            '%.4f' % r['curt'][t], '%.4f' % r['em'][t], '%.4f' % r['E'][t]])

    with open(os.path.join(RES_DIR, 'q3_table1_%s.csv' % tag), 'w', newline='', encoding='utf-8-sig') as f:
        w = csv.writer(f)
        hdr = ['日期']
        for c in TABLE1_CLOCKS:
            hdr += ['%s计划(kWh)' % c, '%s调整(kWh)' % c]
        hdr += ['全天计划购电(kWh)', '全天调整购电(kWh)', '全天购电相关费用(元)']
        w.writerow(hdr); w.writerows(t1)
    with open(os.path.join(RES_DIR, 'q3_table2_%s.csv' % tag), 'w', newline='', encoding='utf-8-sig') as f:
        w = csv.writer(f)
        hdr = ['日期']
        for nm, _, _ in PERIODS:
            hdr += ['%s充电(kWh)' % nm, '%s放电(kWh)' % nm]
        hdr += ['0:00储电量(kWh)', '24:00储电量(kWh)']
        w.writerow(hdr); w.writerows(t2)
    with open(os.path.join(RES_DIR, 'q3_table3_%s.csv' % tag), 'w', newline='', encoding='utf-8-sig') as f:
        w = csv.writer(f)
        w.writerow(['日期', '紧急购电时间段', '紧急购电量(kWh)']); w.writerows(t3)

    xls = os.path.join(OUT_DIR, 'result3.xlsx' if args.slots == 4 else 'result3_%s.xlsx' % tag)
    n_em_rows, _ = write_result3(dates, recs, xls)

    print()
    print('保存期 %s ~ %s，共 %d 天' % (summary['saved_range'][0], summary['saved_range'][1], len(recs)))
    print('计划购电量 %.2f kWh → 调整购电量 %.2f kWh（偏差 %.2f kWh，%.2f%%）'
          % (tot('plan_buy_kWh'), tot('final_buy_kWh'), tot('dev_kWh'),
             tot('dev_kWh') / tot('plan_buy_kWh') * 100))
    print('基础电费 %.2f 元 + 偏差费 %.2f 元 + 紧急购电费 %.2f 元 = 总费用 %.2f 元'
          % (tot('base_cost'), tot('bias_cost'), tot('em_cost'), tot('total_cost')))
    print('紧急购电 %.2f kWh（%d 天）| 弃光 %.2f kWh | 光伏消纳率 %.2f%%'
          % (tot('em_buy_kWh'), em_days, tot('curtail_kWh'), summary['pv_utilization'] * 100))
    print('储能充电 %.2f kWh，放电 %.2f kWh' % (tot('ch_kWh'), tot('dis_kWh')))
    print('已写出', xls, '（紧急购电表 %d 行）' % n_em_rows)


if __name__ == '__main__':
    main()
