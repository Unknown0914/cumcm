# -*- coding: utf-8 -*-
"""探查附件3（光伏预报）与 result3.xlsx 模板结构。"""
import sys, os, io
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
import openpyxl
from openpyxl.utils import get_column_letter

A3 = r'C:\Users\35941\Desktop\C题\附件\附件3.xlsx'
T3 = r'C:\Users\35941\Desktop\C题\附件\附件5\result3.xlsx'

print('=' * 88)
print('附件3 结构')
print('=' * 88)
wb = openpyxl.load_workbook(A3, data_only=True)
print('sheets:', wb.sheetnames)
for name in wb.sheetnames:
    ws = wb[name]
    print('--- sheet: %s   max_row=%s  max_col=%s' % (name, ws.max_row, ws.max_column))
    for r in range(1, min(ws.max_row, 5) + 1):
        row = [ws.cell(r, c).value for c in range(1, min(ws.max_column, 8) + 1)]
        tail = ws.cell(r, ws.max_column).value if ws.max_column > 8 else None
        print('    row%-3d %s ... 末列=%r' % (r, row, tail))
    print('    ... 末 2 行:')
    for r in range(max(1, ws.max_row - 1), ws.max_row + 1):
        row = [ws.cell(r, c).value for c in range(1, min(ws.max_column, 6) + 1)]
        print('    row%-3d %s ... 末列=%r' % (r, row, ws.cell(r, ws.max_column).value))
wb.close()

print()
print('=' * 88)
print('result3.xlsx 模板结构')
print('=' * 88)
wb = openpyxl.load_workbook(T3)
print('sheets:', wb.sheetnames)
for ws in wb.worksheets:
    print('--- sheet: %s   dims=%s  max_row=%d  max_col=%d' % (ws.title, ws.dimensions, ws.max_row, ws.max_column))
    print('    表头:', [ws.cell(1, c).value for c in range(1, min(ws.max_column, 6) + 1)],
          ('... 末列=%r' % ws.cell(1, ws.max_column).value) if ws.max_column > 6 else '')
    for r in range(2, min(ws.max_row, 4) + 1):
        print('    row%-3d %s' % (r, [ws.cell(r, c).value for c in range(1, min(ws.max_column, 6) + 1)]))
    print('    ... 末行:', [ws.cell(ws.max_row, c).value for c in range(1, min(ws.max_column, 6) + 1)])
wb.close()
