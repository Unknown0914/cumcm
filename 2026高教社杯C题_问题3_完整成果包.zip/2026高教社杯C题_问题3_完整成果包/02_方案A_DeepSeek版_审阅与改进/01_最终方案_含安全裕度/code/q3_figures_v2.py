# -*- coding: utf-8 -*-
"""q3_figures_v2.py —— 问题3 改善版的论文级图（补齐预报精度与裕度敏感性）。"""
import os, sys, io, json
import numpy as np
WQ = r'C:\Users\35941\Desktop\cumcm2026C_q3'
sys.path.insert(0, os.path.join(WQ, 'code'))
os.chdir(WQ)
sys.stdout.reconfigure(encoding='utf-8', errors='replace')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import rcParams
from common_q3 import (DT, NT, E_INIT, E_MIN, E_MAX, P_MAX, RES_DIR, FIG_DIR,
                       load_price, load_year, load_forecast, stage_forecast, SLOT_HOURS)

rcParams['font.sans-serif'] = ['Microsoft YaHei', 'SimHei', 'DejaVu Sans']
rcParams['axes.unicode_minus'] = False
rcParams['font.size'] = 10.5
rcParams['axes.grid'] = True
rcParams['grid.alpha'] = 0.3
C = {'price': '#C44E52', 'load': '#4C72B0', 'pv': '#E8A33D', 'net': '#8172B2',
     'soc': '#55A868', 'em': '#C44E52', 'curt': '#E8A33D', 'g1': '#4C72B0', 'g2': '#55A868'}
os.makedirs(FIG_DIR, exist_ok=True)


def save(fig, nm):
    for ext in ('pdf', 'png'):
        fig.savefig(os.path.join(FIG_DIR, '%s.%s' % (nm, ext)), dpi=300, bbox_inches='tight')
    plt.close(fig)
    print('  ->', nm)


price = load_price()
dates, L = load_year('小区负载')
_, V = load_year('光伏发电实际功率')
_, fc = load_forecast()
n = L.shape[0]
hr_ts = ((np.arange(NT) + 1) * DT) % 24

# ============ 图A：附件3 光伏预报精度（覆盖区间内）============
fig, (a1, a2) = plt.subplots(1, 2, figsize=(12, 3.9))
hs = [0, 6, 12, 18]
maes, sigs = [], []
for h in hs:
    s = SLOT_HOURS.index(h)
    t0 = 6 * (h + 1)
    E = np.array([stage_forecast(fc[d], s, None)[t0 - 1:] - V[d][t0 - 1:] for d in range(n)])
    maes.append(np.abs(E).mean()); sigs.append(E.std())
x = np.arange(4)
a1.bar(x - 0.2, maes, 0.4, color=C['pv'], label='MAE')
a1.bar(x + 0.2, sigs, 0.4, color=C['price'], label='σ')
for i in range(4):
    a1.text(i - 0.2, maes[i], '%.0f' % maes[i], ha='center', va='bottom', fontsize=8)
    a1.text(i + 0.2, sigs[i], '%.0f' % sigs[i], ha='center', va='bottom', fontsize=8)
a1.set_xticks(x); a1.set_xticklabels(['0:00', '6:00', '12:00', '18:00'])
a1.set_xlabel('预报发布时刻'); a1.set_ylabel('预报误差 (kW)')
a1.set_title('(a) 附件3 光伏预报的精度（仅统计覆盖区间）'); a1.legend(fontsize=9)

# 净负荷 σ 随发布时刻
sn = []
for s in range(4):
    h = SLOT_HOURS[s]
    t0 = 6 * (h + 1)
    Lp = np.zeros_like(L)
    for d in range(n):
        Lp[d] = L[d - 7] if d >= 7 else (L[:d].mean(axis=0) if d > 0 else L[d])
    E = np.array([((Lp[d] - stage_forecast(fc[d], s, None)) - (L[d] - V[d]))[t0 - 1:]
                  for d in range(n)])
    sn.append(E.std())
a2.plot(x, sn, 'o-', color=C['net'], lw=2, ms=8)
for i, v in enumerate(sn):
    a2.annotate('%.0f' % v, (i, v), textcoords='offset points', xytext=(0, 8), ha='center', fontsize=9)
a2.set_xticks(x); a2.set_xticklabels(['0:00', '6:00', '12:00', '18:00'])
a2.set_xlabel('预报发布时刻'); a2.set_ylabel('净负荷预报 σ (kW)')
a2.set_title('(b) 净负荷预报不确定性随发布时刻递减')
save(fig, 'q3v2_figA_forecast_accuracy')

# ============ 图B：安全裕度敏感性 ============
mp = os.path.join(RES_DIR, 'q3_margin_scan.json')
if os.path.exists(mp):
    rows = json.load(io.open(mp, encoding='utf-8'))
    zs = [r['z'] for r in rows]; ys = [r['total'] / 1e4 for r in rows]
    fig, ax = plt.subplots(figsize=(7.4, 4.0))
    ax.plot(zs, ys, 'o-', color=C['g1'], lw=2, ms=8)
    for x_, y_ in zip(zs, ys):
        ax.annotate('%.2f' % y_, (x_, y_), textcoords='offset points', xytext=(0, 8),
                    ha='center', fontsize=9)
    best = int(np.argmin(ys))
    ax.plot(zs[best], ys[best], 'o', ms=14, mfc='none', mec=C['price'], mew=2)
    ax.axvline(zs[best], color=C['price'], ls=':', lw=1.2)
    ax.annotate('最优 z=%.2f' % zs[best], (zs[best], ys[best]), textcoords='offset points',
                xytext=(8, -22), fontsize=9.5, color=C['price'])
    ax.set_xlabel('安全裕度系数 z'); ax.set_ylabel('总费用 (万元)')
    ax.set_title('图B  安全裕度敏感性：最优 z=0.30（小于问题2 的报童值 0.8416）')
    save(fig, 'q3v2_figB_margin_sensitivity')

# ============ 图C：预报时点数 vs 费用 ============
fig, ax = plt.subplots(figsize=(7.0, 4.0))
labels, vals = [], []
for tag, lbl in (('q3_summary_slots1_rule.json', '1（仅 0:00）'),
                 ('q3_summary_slots2_rule.json', '2（0:00+6:00）'),
                 ('q3_summary_slots4_rule.json', '4（全部）')):
    p = os.path.join(RES_DIR, tag)
    if os.path.exists(p):
        labels.append(lbl); vals.append(json.load(io.open(p, encoding='utf-8'))['total_cost'] / 1e4)
if vals:
    ax.bar(np.arange(len(vals)), vals, 0.5, color=[C['price'], C['net'], C['g2']])
    for i, v in enumerate(vals):
        ax.text(i, v + 12, '%.1f' % v, ha='center', fontsize=9.5)
    ax.set_xticks(np.arange(len(vals))); ax.set_xticklabels(labels)
    ax.set_xlabel('当日预报发布时刻数'); ax.set_ylabel('总费用 (万元)')
    ax.set_title('图C  预报时点数与总费用：调整显著降低成本')
    save(fig, 'q3v2_figC_slots_vs_cost')

# ============ 图D：全年逐日购电量与费用 ============
import csv as _csv
dp = os.path.join(RES_DIR, 'q3_daily_slots4_rule.csv')
if os.path.exists(dp):
    rr = list(_csv.DictReader(io.open(dp, encoding='utf-8-sig')))
    def cc(name):
        return np.array([float(r.get(name, 0) or 0) for r in rr])
    plan = cc('计划购电量_kWh') if '计划购电量_kWh' in rr[0] else cc('plan_kWh')
    fin = cc('调整购电量_kWh') if '调整购电量_kWh' in rr[0] else cc('final_kWh')
    em = cc('紧急购电量_kWh') if '紧急购电量_kWh' in rr[0] else cc('em_kWh')
    day = np.arange(len(plan))
    fig, ax = plt.subplots(figsize=(11, 3.9))
    ax.plot(day, plan / 1e3, lw=0.9, color=C['g1'], label='计划购电量')
    ax.plot(day, fin / 1e3, lw=0.9, color=C['net'], label='调整后购电量')
    ax.fill_between(day, fin / 1e3, plan / 1e3, color='#CCCCCC', alpha=0.5, label='调整量')
    ax.set_xlabel('天数序号（2025-02-01 起）'); ax.set_ylabel('日购电量 (MWh)')
    ax.set_title('图D  全年逐日计划购电量与调整后购电量（334 天）')
    ax.legend(fontsize=9)
    save(fig, 'q3v2_figD_daily_plan_vs_final')

print('\n完成')
