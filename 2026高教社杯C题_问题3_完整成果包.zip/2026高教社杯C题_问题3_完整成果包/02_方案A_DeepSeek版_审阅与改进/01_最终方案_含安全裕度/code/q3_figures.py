# -*- coding: utf-8 -*-
"""q3_figures.py —— 问题3 论文用图（中文宋体风格，PDF + PNG）。"""
import sys, os, io, json, csv as _csv
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import rcParams
from common_q3 import (load_price, load_year, load_forecast, DT, NT, E_INIT, E_MIN,
                       E_MAX, P_MAX, FIG_DIR, RES_DIR, stage_forecast, SLOT_START_T)

rcParams['font.sans-serif'] = ['Microsoft YaHei', 'SimHei', 'DejaVu Sans']
rcParams['axes.unicode_minus'] = False
rcParams['font.size'] = 10.5
rcParams['axes.grid'] = True
rcParams['grid.alpha'] = 0.3
C = {'grid': '#2E5C8A', 'pv': '#E8A33D', 'load': '#4C72B0', 'soc': '#55A868',
     'price': '#C44E52', 'plan': '#8172B2', 'final': '#937860'}


def save(fig, name):
    for ext in ('pdf', 'png'):
        fig.savefig(os.path.join(FIG_DIR, '%s.%s' % (name, ext)), dpi=300,
                    bbox_inches='tight')
    plt.close(fig)
    print('  ->', name)


def read_daily(tag):
    p = os.path.join(RES_DIR, 'q3_daily_%s.csv' % tag)
    rows = list(_csv.DictReader(open(p, encoding='utf-8-sig')))
    return rows


def col(rows, name):
    return np.array([float(r[name]) for r in rows])


def main():
    price = load_price()
    dates, load = load_year('小区负载')
    _, pv = load_year('光伏发电实际功率')
    _, fc = load_forecast()
    hr = np.arange(NT) * DT
    hr_ts = ((np.arange(NT) + 1) * DT) % 24          # 时段右端点

    # ===== 图1 预报精度 =====
    slots_name = ['0:00', '6:00', '12:00', '18:00']
    maes, sds = [], []
    for s in range(4):
        e = []
        for d in range(31, load.shape[0]):
            f = stage_forecast(fc[d], s, None)
            t0 = SLOT_START_T[s] - 1
            e.append(load[d][t0:] - pv[d][t0:] - f[t0:])
        e = np.concatenate(e)
        maes.append(np.abs(e).mean()); sds.append(e.std())
    fig, ax = plt.subplots(figsize=(6.6, 3.6))
    x = np.arange(4); w = 0.36
    ax.bar(x - w / 2, maes, w, label='平均绝对误差 MAE', color=C['load'])
    ax.bar(x + w / 2, sds, w, label='残差标准差 $\\sigma$', color=C['price'])
    for i in range(4):
        ax.text(x[i] - w / 2, maes[i], '%.0f' % maes[i], ha='center', va='bottom', fontsize=9)
        ax.text(x[i] + w / 2, sds[i], '%.0f' % sds[i], ha='center', va='bottom', fontsize=9)
    ax.set_xticks(x); ax.set_xticklabels(slots_name)
    ax.set_xlabel('预报发布时刻'); ax.set_ylabel('净负荷预报误差 (kW)')
    ax.set_title('图1  各预报时刻对当日 24 h 净负荷的预报精度（334 天）')
    ax.legend()
    save(fig, 'q3_fig1_forecast_accuracy')

    rows = read_daily('slots4_rule')
    plan = col(rows, '计划购电量_kWh'); fin = col(rows, '调整购电量_kWh')
    curt = col(rows, '弃光_kWh'); em = col(rows, '紧急购电量_kWh')
    dev = col(rows, '偏差量_kWh'); tot = col(rows, '总费用_元')
    day = np.arange(len(rows))

    # ===== 图2 全年逐日 计划 vs 调整 =====
    fig, ax = plt.subplots(figsize=(11, 3.8))
    ax.plot(day, plan / 1e3, lw=0.9, color=C['plan'], label='计划购电量')
    ax.plot(day, fin / 1e3, lw=0.9, color=C['final'], label='调整后购电量')
    ax.fill_between(day, fin / 1e3, plan / 1e3, color='#CCCCCC', alpha=0.5,
                    label='调整下调量')
    ax.set_xlabel('保存期天数序号（2025-02-01 起）'); ax.set_ylabel('日购电量 (MWh)')
    ax.set_title('图2  全年逐日计划购电量与调整后购电量（334 天）')
    ax.legend(loc='upper right', fontsize=9, ncol=3)
    save(fig, 'q3_fig2_daily_plan_vs_final')

    # ===== 图3 弃光与紧急购电月度分布 =====
    mon = np.array([int(str(r['日期'])[5:7]) for r in rows])
    ms = list(range(2, 13))
    m_curt = [curt[mon == m].sum() / 1e3 for m in ms]
    m_em = [em[mon == m].sum() for m in ms]
    fig, ax = plt.subplots(figsize=(9.8, 3.6))
    ax.bar(np.arange(len(ms)), m_curt, 0.6, color=C['pv'], label='弃光电量')
    ax.set_ylabel('弃光电量 (MWh)', color=C['pv'])
    ax.set_xticks(np.arange(len(ms))); ax.set_xticklabels(['%d月' % m for m in ms])
    ax2 = ax.twinx(); ax2.grid(False)
    ax2.plot(np.arange(len(ms)), m_em, 'o-', color=C['price'], label='紧急购电量')
    ax2.set_ylabel('紧急购电量 (kWh)', color=C['price'])
    ax.set_title('图3  弃光电量与紧急购电量的月度分布')
    h1, l1 = ax.get_legend_handles_labels(); h2, l2 = ax2.get_legend_handles_labels()
    ax.legend(h1 + h2, l1 + l2, loc='upper center', fontsize=9)
    save(fig, 'q3_fig3_curtail_em_monthly')

    # ===== 图4 预报时点数 vs 全年总费用（两方案）=====
    cmp_path = os.path.join(RES_DIR, 'q3_two_scheme_compare.json')
    if os.path.exists(cmp_path):
        rr = json.load(open(cmp_path, encoding='utf-8'))
        for tag, clr, mk, lbl in (('A_DeepSeek路线', '#4C72B0', 'o-', '方案A（DeepSeek 路线改进）'),
                                  ('B_GLM路线', '#C44E52', 's--', '方案B（GLM 路线改进）')):
            sub = sorted([r for r in rr if r['scheme'] == tag], key=lambda r: r['slots'])
            if not sub:
                continue
            xs = [r['slots'] for r in sub]; ys = [r['total_cost'] / 1e4 for r in sub]
            plt.plot(xs, ys, mk, color=clr, lw=1.9, ms=7, label=lbl)
            for x_, y_ in zip(xs, ys):
                plt.annotate('%.0f' % y_, (x_, y_), textcoords='offset points',
                             xytext=(0, 8), ha='center', fontsize=8.5)
        plt.xticks([1, 2, 4]); plt.xlabel('当日预报发布时刻数（1 / 2 / 4）')
        plt.ylabel('保存期总费用 (万元)')
        plt.title('图4  预报时点数与总费用：两方案一致显示“调整有益”')
        plt.legend(fontsize=8.5)
        plt.grid(alpha=0.3)
        fig = plt.gcf(); fig.set_size_inches(7.2, 4.0)
        save(fig, 'q3_fig4_slots_vs_cost')

    # ===== 图5 典型日时序（4 个时点） =====
    for ymd, lbl in (('20250320', '2025-03-20'), ('20250621', '2025-06-21')):
        p = os.path.join(RES_DIR, 'q3_timeseries_slots4_rule_%s.csv' % ymd)
        ts = list(_csv.DictReader(open(p, encoding='utf-8-sig')))
        tp = col(ts, 'price'); tl = col(ts, 'load_kW'); tv = col(ts, 'pv_act_kW')
        tfin = col(ts, 'p_final_kW'); te = col(ts, 'E_kWh')
        tcurt = col(ts, 'curt_kW'); tem = col(ts, 'em_kW')
        fig, (a1, a2) = plt.subplots(2, 1, figsize=(9.8, 5.6), sharex=True,
                                     gridspec_kw={'height_ratios': [1.15, 1.5]})
        a1.plot(hr_ts, tp, color=C['price'], lw=1.3, label='电价')
        a1.set_ylabel('电价 (元/kWh)', color=C['price'])
        a1.set_title('图5  典型日（%s）电价与电能平衡' % lbl)
        a1b = a1.twinx(); a1b.grid(False)
        a1b.plot(hr_ts, tfin, color=C['plan'], lw=1.4, label='购电功率（调整后）')
        a1b.plot(hr_ts, tl, color=C['load'], lw=1.2, ls=':', label='小区负载')
        a1b.plot(hr_ts, tv, color=C['pv'], lw=1.2, ls='--', label='光伏实际')
        a1b.set_ylabel('功率 (kW)')
        h1, l1 = a1.get_legend_handles_labels(); h2, l2 = a1b.get_legend_handles_labels()
        a1.legend(h1 + h2, l1 + l2, loc='upper left', fontsize=8.5, ncol=2)
        a2.plot(hr_ts, te, color=C['soc'], lw=1.8, label='储电量 $E_t$')
        a2.axhline(E_MIN, color='gray', ls='--', lw=1, label='下限 1200')
        a2.axhline(E_MAX, color='gray', ls='-.', lw=1, label='上限 10800')
        a2.axhline(E_INIT, color='green', ls=':', lw=1, label='初始 6000')
        a2.set_xlabel('时刻 (h)'); a2.set_ylabel('储电量 (kWh)')
        a2.set_xlim(0, 24); a2.set_xticks(np.arange(0, 25, 2))
        a2.legend(fontsize=8.5, ncol=4, loc='upper center')
        save(fig, 'q3_fig5_typical_%s' % ymd)

    # ===== 图6 偏差结构与费用构成 =====
    fig, (a1, a2) = plt.subplots(1, 2, figsize=(11, 3.9))
    a1.plot(day, dev / 1e3, lw=0.8, color=C['final'])
    a1.set_xlabel('天数序号'); a1.set_ylabel('日调整偏差量 (MWh)')
    a1.set_title('(a) 逐日“计划—调整”偏差量')
    base = col(rows, '基础电费_元').sum(); bias = col(rows, '偏差费_元').sum()
    emc = col(rows, '紧急购电费_元').sum()
    a2.bar([0, 1, 2], [base / 1e4, bias / 1e4, emc / 1e4],
           color=[C['plan'], C['price'], C['pv']], width=0.6)
    for i, v in enumerate([base / 1e4, bias / 1e4, emc / 1e4]):
        a2.text(i, v, '%.1f 万元' % v, ha='center', va='bottom', fontsize=9)
    a2.set_xticks([0, 1, 2]); a2.set_xticklabels(['基础电费', '偏差费', '紧急购电费'])
    a2.set_ylabel('金额 (万元)')
    a2.set_title('(b) 总费用构成（合计 %.1f 万元）' % ((base + bias + emc) / 1e4))
    save(fig, 'q3_fig6_deviation_cost_structure')


if __name__ == '__main__':
    main()
