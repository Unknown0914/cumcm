# -*- coding: utf-8 -*-
"""
q3_forecast_error.py —— 问题3 的不确定性分析

问题3 有两个误差来源：
  ① 光伏：附件3 的官方预报 vs 附件2 的实际值（各发布时刻 × 各提前时效）
  ② 负载：lag-7 外推 vs 实际值（题面未给负载预报）

输出各来源的 MAE / σ，供"安全裕度"设计使用。
"""
import os, sys, io, json
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.stdout.reconfigure(encoding='utf-8', errors='replace')
import numpy as np
import pandas as pd
from common_q3 import (DT, NT, E_INIT, E_MIN, E_MAX, P_MAX, ETA_C, ETA_D, SAVE_START,
                       RES_DIR, load_price, load_year, load_forecast,
                       stage_forecast, SLOT_HOURS)


def main():
    dates, L = load_year('小区负载')
    _, V = load_year('光伏发电实际功率')
    fdates, fc = load_forecast()
    n = L.shape[0]
    print('数据 %d 天 × %d 时段' % (n, NT))

    # ---------- ① 光伏预报误差（附件3） ----------
    print('\n===== ① 附件3 光伏预报的 MAE / σ（kW）=====')
    print('（只统计该发布时刻**实际覆盖**的时段：h:00 发布的预报覆盖 h+1 时起至当日 24:00）')
    print('%-8s %8s %10s %10s %10s %10s' % ('发布时刻', '覆盖时段', 'MAE', 'σ', '提前1h', '提前6h'))
    pv_stats = {}
    for s in range(4):
        h = SLOT_HOURS[s]
        t0 = 6 * (h + 1)                            # 覆盖起点（1-based 时段号）
        errs = []
        for d in range(n):
            f = stage_forecast(fc[d], s, None)
            errs.append(f[t0 - 1:] - V[d][t0 - 1:])  # 只取覆盖区间
        E = np.array(errs)
        lead1 = np.abs(E[:, 0:6]).mean()             # 提前 1h（覆盖区间首个时段）
        lead6 = np.abs(E[:, 30:36]).mean() if E.shape[1] > 36 else float('nan')
        pv_stats['%d:00' % h] = dict(mae=float(np.abs(E).mean()), sigma=float(E.std()),
                                     lead1=float(lead1), lead6=float(lead6),
                                     t0=int(t0), n_t=int(E.shape[1]))
        print('%-8s %8s %10.2f %10.2f %10.2f %10.2f'
              % ('%d:00' % h, '%d-%d' % (t0, NT), np.abs(E).mean(), E.std(), lead1, lead6))

    # ---------- ② 负载 lag-7 误差 ----------
    print('\n===== ② 负载 lag-7 外推的 MAE / σ（kW）=====')
    Lp = np.zeros_like(L)
    for d in range(n):
        Lp[d] = L[d - 7] if d >= 7 else (L[:d].mean(axis=0) if d > 0 else L[d])
    EL = Lp - L
    print('负载 lag-7: MAE=%.2f kW, σ=%.2f kW' % (np.abs(EL).mean(), EL.std()))

    # ---------- ③ 净负荷误差（两者叠加） ----------
    print('\n===== ③ 净负荷（负载预测 − 光伏预报）的误差 =====')
    for s in range(4):
        h = SLOT_HOURS[s]
        t0 = 6 * (h + 1)
        errs = []
        for d in range(n):
            f = stage_forecast(fc[d], s, None)
            errs.append(((Lp[d] - f) - (L[d] - V[d]))[t0 - 1:])
        E = np.array(errs)
        sig_t = E.std(axis=0)
        sig_full = np.zeros(NT); sig_full[t0 - 1:] = sig_t
        print('  %d:00 发布 → 覆盖 [%d,%d]，净负荷 MAE=%.2f kW, σ均值=%.2f kW'
              % (h, t0, NT, np.abs(E).mean(), sig_t.mean()))
        np.save(os.path.join(RES_DIR, 'q3_sigma_net_slot%d.npy' % s), sig_full)

    # ---------- ④ 报童分位数 ----------
    print('\n===== ④ 安全裕度的理论值（报童模型）=====')
    print('代价不对称：计划偏低 → 上调按 1.5c、缺电按 5c；计划偏高 → 下调只按 0.5c')
    print('若以"缺电 5c vs 多买 0.5c"为准：')
    print('  α* = (5c − c) / ((5c − c) + 0.5c) = 4c/4.5c = %.4f → z = Φ⁻¹(α*) = %.4f'
          % (4 / 4.5, 0.0))
    from scipy.stats import norm
    for cu, co, lbl in ((4.0, 0.5, '缺电 5c vs 多买 0.5c'),
                        (0.5, 0.5, '上调 1.5c vs 下调 0.5c（对称）'),
                        (4.0, 1.0, '缺电 5c vs 多买 1c')):
        a = cu / (cu + co)
        print('  %-32s α*=%.4f → z=%.4f' % (lbl, a, norm.ppf(a)))

    json.dump({'pv': pv_stats,
               'load': {'mae': float(np.abs(EL).mean()), 'sigma': float(EL.std())}},
              io.open(os.path.join(RES_DIR, 'q3_forecast_error.json'), 'w',
                      encoding='utf-8'), ensure_ascii=False, indent=2)
    print('\n已写出 results/q3_forecast_error.json 与 q3_sigma_net_slot*.npy')


if __name__ == '__main__':
    main()
