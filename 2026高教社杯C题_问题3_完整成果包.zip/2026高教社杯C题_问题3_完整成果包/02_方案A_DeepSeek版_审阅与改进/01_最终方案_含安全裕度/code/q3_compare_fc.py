# -*- coding: utf-8 -*-
"""q3_compare_fc.py —— 生成“信息结构对照”数据与图（问题2/3 预测版）。"""
import os, sys, io, json, csv
sys.stdout.reconfigure(encoding='utf-8', errors='replace')
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import rcParams

rcParams['font.sans-serif'] = ['Microsoft YaHei', 'SimHei', 'DejaVu Sans']
rcParams['axes.unicode_minus'] = False
rcParams['font.size'] = 10.5
rcParams['axes.grid'] = True
rcParams['grid.alpha'] = 0.3
C = {'a': '#4C72B0', 'b': '#C44E52', 'c': '#55A868', 'd': '#8172B2', 'e': '#E8A33D'}

D2 = r'C:\Users\35941\Desktop\cumcm2026C_q2\results'
D3 = r'C:\Users\35941\Desktop\cumcm2026C_q3\results'
FIG = r'C:\Users\35941\Desktop\cumcm2026C_q3\figures'

ROWS = [
    ('问题2 · 完全信息（旧，已作废）', '实际值', '实际值', 12227243.64, 0.0, 990168.09),
    ('问题2 · 历史外推（本轮）', 'ma7 外推', 'lag-7 外推', 14917127.54, 322476.0, 1535216.0),
    ('问题3 · 仅 0:00 预报（本轮）', '附件3 0:00 预报', 'lag-7 外推', 15572120.87, 556709.0, 1268550.0),
    ('问题3 · 四个时点预报（本轮）', '附件3 四时点', 'lag-7 外推', 13736217.56, 180898.0, 1120790.0),
]


def main():
    os.makedirs(FIG, exist_ok=True)
    # 校验：与本轮 JSON 对齐
    d2 = json.load(io.open(os.path.join(D2, 'q2_fc5_0.8416.json'), encoding='utf-8'))
    d31 = json.load(io.open(os.path.join(D3, 'q3_summary_lp1_rule.json'), encoding='utf-8'))
    d34 = json.load(io.open(os.path.join(D3, 'q3_summary_lp4_rule.json'), encoding='utf-8'))
    assert abs(ROWS[1][3] - d2['total_cost']) < 1
    assert abs(ROWS[2][3] - d31['total_cost']) < 1
    assert abs(ROWS[3][3] - d34['total_cost']) < 1
    print('数值与 JSON 一致 ✓')

    with io.open(os.path.join(D3, 'q3_info_structure_compare.csv'), 'w', newline='',
                 encoding='utf-8-sig') as f:
        w = csv.writer(f)
        w.writerow(['方案', '光伏信息来源', '负载信息来源', '总费用_元', '紧急购电_kWh', '弃光_kWh'])
        for r in ROWS:
            w.writerow([r[0], r[1], r[2], '%.2f' % r[3], '%.0f' % r[4], '%.0f' % r[5]])
    json.dump([{'scheme': r[0], 'pv_src': r[1], 'load_src': r[2], 'total_cost': r[3],
                'em_kWh': r[4], 'curt_kWh': r[5]} for r in ROWS],
              io.open(os.path.join(D3, 'q3_info_structure_compare.json'), 'w',
                      encoding='utf-8'), ensure_ascii=False, indent=2)

    def save(fig, nm):
        for ext in ('pdf', 'png'):
            fig.savefig(os.path.join(FIG, '%s.%s' % (nm, ext)), dpi=300, bbox_inches='tight')
        plt.close(fig)
        print('  ->', nm)

    # 图1 总费用对照
    fig, ax = plt.subplots(figsize=(9.2, 4.2))
    names = [r[0].replace(' · ', '\n') for r in ROWS]
    vals = [r[3] / 1e4 for r in ROWS]
    cols = [C['d'], C['a'], C['e'], C['b']]
    bars = ax.bar(np.arange(4), vals, 0.55, color=cols)
    for i, v in enumerate(vals):
        ax.text(i, v + 15, '%.1f' % v, ha='center', fontsize=10)
    ax.set_xticks(np.arange(4)); ax.set_xticklabels(names, fontsize=9)
    ax.set_ylabel('保存期总费用 (万元)')
    ax.set_title('图1  信息结构对总费用的影响（问题2/3，2025-02-01~12-31，334 天）')
    save(fig, 'q3_fig_info_cost')

    # 图2 紧急购电与弃光
    fig, ax = plt.subplots(figsize=(9.2, 3.8))
    idx = np.arange(4); w = 0.36
    ax.bar(idx - w / 2, [r[4] / 1e3 for r in ROWS], w, color=C['b'], label='紧急购电量 (MWh)')
    ax.bar(idx + w / 2, [r[5] / 1e3 for r in ROWS], w, color=C['d'], label='弃光量 (MWh)')
    for i in idx:
        ax.text(i - w / 2, ROWS[i][4] / 1e3, '%.0f' % (ROWS[i][4] / 1e3), ha='center',
                va='bottom', fontsize=9)
        ax.text(i + w / 2, ROWS[i][5] / 1e3, '%.0f' % (ROWS[i][5] / 1e3), ha='center',
                va='bottom', fontsize=9)
    ax.set_xticks(idx); ax.set_xticklabels(names, fontsize=9)
    ax.set_ylabel('电量 (MWh)'); ax.set_title('图2  各信息结构下的紧急购电与弃光')
    ax.legend()
    save(fig, 'q3_fig_info_em_curt')

    print('\n对照表:')
    print('%-30s %14s %14s %12s' % ('方案', '总费用(元)', '紧急购电(kWh)', '弃光(kWh)'))
    for r in ROWS:
        print('%-30s %14.2f %14.0f %12.0f' % (r[0], r[3], r[4], r[5]))
    print('\n信息价值:')
    print('  问题2“完全信息 → 历史外推”的代价 = %.2f 元 (%.1f%%)'
          % (ROWS[1][3] - ROWS[0][3], 100 * (ROWS[1][3] - ROWS[0][3]) / ROWS[0][3]))
    print('  问题3“仅 0:00 → 四时点预报”的价值 = %.2f 元 (%.1f%%)'
          % (ROWS[2][3] - ROWS[3][3], 100 * (ROWS[2][3] - ROWS[3][3]) / ROWS[2][3]))


if __name__ == '__main__':
    main()
