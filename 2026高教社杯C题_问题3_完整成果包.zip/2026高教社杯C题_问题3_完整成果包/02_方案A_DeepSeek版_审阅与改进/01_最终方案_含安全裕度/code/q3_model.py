# -*- coding: utf-8 -*-
"""
q3_model.py —— 问题3 的滚动时域（MPC）模型

决策链（每天四个预报发布时刻 0:00 / 6:00 / 12:00 / 18:00）：

  阶段 0（0:00）  用 0:00 预报规划全天 144 个时段 → 计划购电量 P_plan(1..144)
  执行 1..24     按 P_plan 购电，储能按实际光伏实时平衡
  阶段 1（6:00）  用 6:00 预报重优化 25..144  → 调整购电量 P_adj1
  执行 25..48
  阶段 2（12:00） 用 12:00 预报重优化 49..144 → P_adj2
  执行 49..96
  阶段 3（18:00） 用 18:00 预报重优化 97..144 → P_adj3
  执行 97..144

  最终执行购电量 P_final(t) 由上述四段拼接而成。

费用口径（依题目原文推导）：
  "计划购电量高于调整购电量的部分，违约电价是交易时刻电价的 50%；
   调整购电量高于计划购电量的部分，超出部分的电价是交易时刻电价的 1.5 倍。"
  ⇒  设 d⁺ = max(0, P_final − P_plan)、d⁻ = max(0, P_plan − P_final)，
      费用 = c·min(P_plan, P_final) + 0.5c·d⁻ + 1.5c·d⁺
           = c·P_final + 0.5c·(d⁺ + d⁻)          （因 min(P,Pf)=Pf−d⁺）
  ⇒  即 **基础电费按最终执行量 + 0.5 倍偏差绝对值 + 5 倍紧急购电**

  ⚠ DeepSeek 原方案写成 c·P_plan + 0.5c·d⁻ + 1.5c·d⁺，在 P_final < P_plan 时
    会把"多报部分"多算一个 c·d⁻（等价于按 1.5c 而非 0.5c 计），与"违约电价 50%"
    的字面不符，且会导致"调低购电量永远不划算"的反常结论。

执行规则（实时平衡）：购电量在阶段内已承诺，实际光伏与预报的偏差由储能实时吸收
  （缺额优先放电、不足则紧急购电；富余优先充电、充不下的弃光）。
"""
import numpy as np
from scipy.optimize import linprog

from common_q3 import (DT, NT, E_INIT, E_MIN, E_MAX, P_MAX, ETA_C, ETA_D,
                       SLOT_START_T, SLOT_END_T, stage_forecast)

DELTA_E_MAX = P_MAX * DT
BIAS_UP = 1.5      # 调整高于计划部分的电价系数
BIAS_DOWN = 0.5    # 计划高于调整部分的电价系数
EM_PENALTY = 5.0


def solve_stage(price, load, fc_pv, plan_ref, a, soc_init,
                eta_c=ETA_C, eta_d=ETA_D, p_max=P_MAX, e_min=E_MIN, e_max=E_MAX,
                cost_mode='X'):
    """求解一个规划阶段：优化时段 a..144 的最终购电量与储能调度。

    参数
    ----
    fc_pv     : 长度 144 的光伏预报（该阶段可用的最新预报，kW）
    plan_ref  : 长度 144 的计划购电参照量（kW）；阶段 0 传 None（无偏差费）
    a         : 本阶段负责的起始时段（1-based）；a=1 表示全天规划
    返回 dict：p_final / ch / dis / curt / E（均为长度 n = 145-a 的数组）
    """
    n = NT - a + 1
    nv = 7 * n
    P, C, D, CU, E, DP, DM = 0, n, 2 * n, 3 * n, 4 * n, 5 * n, 6 * n
    idx = np.arange(a - 1, NT)               # 全局时段下标（0-based）
    p_price = price[idx]
    p_load = load[idx]                       # kW（变量统一采用功率单位）
    p_pv = fc_pv[idx]                        # kW

    c = np.zeros(nv)
    if cost_mode == 'Y':
        # 口径 Y：基础电费按最终执行量结算，偏差只付 0.5c（调低可净省 0.5c）
        c[P:P + n] = p_price * DT
        if plan_ref is not None:
            c[DP:DP + n] = BIAS_DOWN * p_price * DT
            c[DM:DM + n] = BIAS_DOWN * p_price * DT
    else:
        # 口径 X（本文采用）：基础电费按计划购电量结算（已在阶段 0 锁定，
        # 不随 P_final 变化），阶段 k 只需最小化偏差费：
        #     计划高于调整 → 0.5c·d⁻     调整高于计划 → 1.5c·d⁺
        if plan_ref is not None:
            c[DP:DP + n] = BIAS_UP * p_price * DT      # 1.5c
            c[DM:DM + n] = BIAS_DOWN * p_price * DT    # 0.5c
        else:
            c[P:P + n] = p_price * DT                  # 阶段 0：min Σ c·P_plan

    A_eq, b_eq = [], []
    for k in range(n):                       # 平衡：P_final − curt + dis − ch = load − pv
        row = np.zeros(nv)
        row[P + k] = 1.0; row[CU + k] = -1.0; row[D + k] = 1.0; row[C + k] = -1.0
        A_eq.append(row); b_eq.append(p_load[k] - p_pv[k])
    for k in range(n):                       # 储能动态
        row = np.zeros(nv)
        row[E + k] = 1.0
        if k > 0:
            row[E + k - 1] = -1.0
        row[C + k] = -eta_c * DT
        row[D + k] = DT / eta_d
        A_eq.append(row)
        b_eq.append(soc_init if k == 0 else 0.0)
    if plan_ref is not None:                 # 偏差定义：P_final − plan = d⁺ − d⁻
        p_ref = plan_ref[idx]
        for k in range(n):
            row = np.zeros(nv)
            row[P + k] = 1.0; row[DP + k] = -1.0; row[DM + k] = 1.0
            A_eq.append(row); b_eq.append(p_ref[k])

    # 【修正】C/D 是功率(kW)，上界必须是 p_max(=5000 kW)；
    #   原写 DELTA_E_MAX = P_MAX*DT = 833.33 是“单时段电量”，等于把充放功率
    #   人为压到 1/6，导致储能套利严重不足。
    bounds = ([(0.0, None)] * n + [(0.0, p_max)] * n + [(0.0, p_max)] * n
              + [(0.0, float(p_pv[k])) for k in range(n)]
              + [(e_min, e_max)] * n + [(0.0, None)] * n + [(0.0, None)] * n)
    res = linprog(c, A_eq=np.array(A_eq), b_eq=np.array(b_eq), bounds=bounds,
                  method='highs')
    assert res.success, res.message
    x = res.x
    return {'p_final': x[P:P + n], 'ch': x[C:C + n], 'dis': x[D:D + n],
            'curt': x[CU:CU + n], 'E': x[E:E + n],
            'd_plus': x[DP:DP + n] if plan_ref is not None else np.zeros(n),
            'd_minus': x[DM:DM + n] if plan_ref is not None else np.zeros(n)}


def execute_segment(load, pv_act, p_final, a, b, soc_init):
    """按实际光伏执行时段 [a, b]（1-based，含端点）。

    购电功率 p_final（kW）已承诺不可改，实际光伏与预报的偏差由储能实时吸收：
      · 缺额 → 先放电（至下限），仍不足则紧急购电
      · 富余 → 先充电（至上限），仍有余则弃光
    返回该段的 ch/dis/curt/em（长度 b−a+1，单位 **kW**）与末储电量（kWh）。
    """
    m = b - a + 1
    ch = np.zeros(m); dis = np.zeros(m); curt = np.zeros(m); em = np.zeros(m)
    soc = soc_init
    for k in range(m):
        t = a - 1 + k
        net = load[t] - pv_act[t] - p_final[k]            # kW；>0 表示供电不足
        if net > 1e-9:
            max_dis = min(P_MAX, (soc - E_MIN) * ETA_D / DT)      # kW
            d = min(max_dis, net)
            dis[k] = d
            em[k] = net - d
            soc -= d * DT / ETA_D
        else:
            surplus = -net
            max_ch = min(P_MAX, (E_MAX - soc) / ETA_C / DT)       # kW
            chg = min(max_ch, surplus)
            ch[k] = chg
            # 只有"光伏本身的富余"才可能被弃掉；"计划购电的富余部分"物理上无法倒送，
            # 只是按题意白付电费，不能计入弃光。
            rest = surplus - chg
            pv_surplus = max(0.0, pv_act[t] - load[t])            # kW
            curt[k] = min(rest, pv_surplus)
            soc += chg * DT * ETA_C
    return ch, dis, curt, em, float(soc)


def execute_by_plan(load, pv_act, p_final, ch_plan, dis_plan, a, b, soc_init):
    """按日前规划执行：储能动作沿用 LP 给出的充放电计划（kW），
    实际光伏与预报的偏差由"弃光"（光伏富余部分）或"紧急购电"吸收。

    相比贪婪规则，这种方式保证储能轨迹与规划一致，不会因规则的短视而
    反复充满/放空，从而避免后续阶段基于失真状态重新规划。
    """
    m = b - a + 1
    sl = slice(a - 1, b)
    ch = np.array(ch_plan[:m], float)          # 阶段 LP 输出为局部数组（下标 0 对应时段 a）
    dis = np.array(dis_plan[:m], float)
    bal = p_final + pv_act[sl] + dis - load[sl] - ch        # kW；>0 供给多余
    pv_sur = np.maximum(0.0, pv_act[sl] - load[sl])
    curt = np.maximum(0.0, np.minimum(bal, pv_sur))
    em = np.maximum(0.0, -bal)
    soc_series = soc_init + np.cumsum(ETA_C * ch * DT - dis * DT / ETA_D)
    return ch, dis, curt, em, float(soc_series[-1]), soc_series


def execute_intraday_lp(price, load, pv_act, a_final, a_beg, a_end, E0):
    """日内 LP（闭环执行）：调整后的购电量 A 锁定不变，储能逐时段最优使用以最小化 5 倍紧急购电。

        min Σ 5c·U
        s.t. G − ch + dis − cur = load·Δt − pv·Δt
             U ≥ G − A_final, U ≥ 0
             E(t) = E(t−1) + η_c·ch − dis/η_d
    返回该段的 em/ch/dis/curt（kWh，长度 a_end−a_beg+1）与末储电量。
    """
    m = a_end - a_beg + 1
    G, C, D, CU, S, U = 0, m, 2 * m, 3 * m, 4 * m, 5 * m
    nv = 6 * m
    c = np.zeros(nv); c[U:U + m] = EM_PENALTY * price[a_beg - 1:a_end]
    A_eq, b_eq = [], []
    for k in range(m):
        t = a_beg - 1 + k
        row = np.zeros(nv)
        row[G + k] = 1.0; row[C + k] = -1.0; row[D + k] = 1.0; row[CU + k] = -1.0
        A_eq.append(row); b_eq.append(load[t] * DT - pv_act[t] * DT)
    for k in range(m):
        row = np.zeros(nv)
        row[S + k] = 1.0
        if k > 0:
            row[S + k - 1] = -1.0
        # C/D 均为“单时段充放电量(kWh)”，故 E 的变化 = η_c·C − D/η_d（不乘 DT）
        row[C + k] = -ETA_C; row[D + k] = 1.0 / ETA_D
        A_eq.append(row); b_eq.append(E0 if k == 0 else 0.0)
    A_ub, b_ub = [], []
    for k in range(m):
        row = np.zeros(nv)
        row[G + k] = 1.0; row[U + k] = -1.0
        A_ub.append(row); b_ub.append(float(a_final[k] * DT))
    DE = P_MAX * DT
    bounds = ([(0.0, None)] * m + [(0.0, DE)] * m + [(0.0, DE)] * m
              + [(0.0, float(pv_act[a_beg - 1 + k] * DT)) for k in range(m)]
              + [(E_MIN, E_MAX)] * m + [(0.0, None)] * m)
    res = linprog(c, A_ub=np.array(A_ub), b_ub=np.array(b_ub),
                  A_eq=np.array(A_eq), b_eq=np.array(b_eq), bounds=bounds, method='highs')
    if not res.success:
        raise RuntimeError('日内 LP 失败: ' + res.message)
    x = res.x
    return x[U:U + m], x[C:C + m], x[D:D + m], x[CU:CU + m], float(x[S + m - 1])


def run_day(price, load, pv_act, fc_day, soc_init, n_slots=4, eta_c=ETA_C, eta_d=ETA_D,
            cost_mode='Y', exec_mode='plan', load_pred=None):
    """对单日执行一次完整的 MPC（默认 4 个预报时刻 0:00/6:00/12:00/18:00）。

    流程：阶段 s 用该时刻可用的最新预报规划 [start_s, 144]，只执行 [start_s, end_s]。

    load_pred : 规划层使用的“负载预测”（kW）。题面只给光伏预报，负载须用历史外推，
                故规划用 load_pred、执行用真实 load。None 时退化为“负载已知”。
    返回 p_plan / p_final / ch / dis / curt / em / E（长度 144）与末储电量。
    """
    load_plan = load if load_pred is None else load_pred
    starts = list(SLOT_START_T[:n_slots])
    ends = list(SLOT_END_T[:n_slots])
    ends[-1] = NT          # 【修正】最后一个阶段的执行终点必须是当天结束，
                           #  否则 n_slots<4 时会漏执行尾段、严重低估费用

    p_final = np.zeros(NT)
    p_plan = np.zeros(NT)
    ch_all = np.zeros(NT); dis_all = np.zeros(NT)
    curt_all = np.zeros(NT); em_all = np.zeros(NT)
    prev_fc = None
    soc = soc_init
    for s in range(n_slots):
        a, b = starts[s], ends[s]
        fc10 = stage_forecast(fc_day, s, prev_fc)
        prev_fc = fc10
        if s == 0:
            out = solve_stage(price, load_plan, fc10, None, a=1, soc_init=soc,
                              eta_c=eta_c, eta_d=eta_d, cost_mode=cost_mode)
            p_plan[:] = out['p_final']
            p_final[:] = out['p_final']
        else:
            out = solve_stage(price, load_plan, fc10, p_plan, a=a, soc_init=soc,
                              eta_c=eta_c, eta_d=eta_d, cost_mode=cost_mode)
            p_final[a - 1:] = out['p_final']
        if exec_mode == 'intraday':
            em_, ch, dis_, curt_, soc = execute_intraday_lp(
                price, load, pv_act, p_final[a - 1:b], a, b, soc)
        elif exec_mode == 'plan':
            ch, dis_, curt_, em_, soc, _ = execute_by_plan(
                load, pv_act, p_final[a - 1:b], out['ch'], out['dis'], a, b, soc)
        else:
            ch, dis_, curt_, em_, soc = execute_segment(
                load, pv_act, p_final[a - 1:b], a, b, soc)
        ch_all[a - 1:b] = ch; dis_all[a - 1:b] = dis_
        curt_all[a - 1:b] = curt_; em_all[a - 1:b] = em_

    E = np.zeros(NT)
    s_ = soc_init
    for t in range(NT):
        s_ = s_ + eta_c * ch_all[t] * DT - dis_all[t] * DT / eta_d
        E[t] = s_
    return {'p_plan': p_plan, 'p_final': p_final, 'ch': ch_all, 'dis': dis_all,
            'curt': curt_all, 'em': em_all, 'E': E, 'E_T': float(E[-1])}
