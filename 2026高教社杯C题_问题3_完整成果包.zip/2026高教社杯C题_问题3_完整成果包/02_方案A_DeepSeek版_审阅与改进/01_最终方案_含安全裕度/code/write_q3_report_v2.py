# -*- coding: utf-8 -*-
"""write_q3_report_v2.py —— 重写《问题3 方案A 审阅与改进报告》（含 8 张图）。"""
import io, os, shutil, sys
WQ = r'C:\Users\35941\Desktop\cumcm2026C_q3'
R = os.path.join(WQ, 'report')
FIG = os.path.join(WQ, 'figures')
os.makedirs(R, exist_ok=True)
os.makedirs(os.path.join(R, 'figures'), exist_ok=True)
KEEP = ('q3v2_figA_forecast_accuracy', 'q3v2_figB_margin_sensitivity', 'q3v2_figC_slots_vs_cost',
        'q3v2_figD_daily_plan_vs_final', 'q3_fig3_curtail_em_monthly',
        'q3_fig5_typical_20250320', 'q3_fig5_typical_20250621', 'q3_fig6_deviation_cost_structure',
        'q3_fig4_slots_vs_cost')
cnt = 0
for f in os.listdir(FIG):
    if any(f.startswith(k) for k in KEEP):
        shutil.copy2(os.path.join(FIG, f), os.path.join(R, 'figures', f)); cnt += 1
print('已复制图:', cnt)

MD = r"""# 2026 高教社杯 C 题 问题 3 解答报告 —— 方案 A（DeepSeek 版）审阅与改进

> **建模定位**：光伏用附件3 的官方预报（0:00/6:00/12:00/18:00 四个时点），
> **负载用 lag-7 历史外推**（题面未给负载预报）；各阶段规划叠加**安全裕度** $z\cdot\sigma$；
> 执行层采用储能实时响应。
> **最终结果**：2025-02-01 ~ 12-31（334 天）总费用 **13 596 227.88 元**。

---

## 一、问题重述与建模定位

### 1.1 题面关键条件

> 问题3：在每天 0:00、6:00、12:00 和 18:00 可获得未来 24 小时整点的光伏发电功率预报。
> 可根据 0:00 的预报制定当天的计划购电策略，也可根据其他时刻的预报调整购电策略。
> **计划购电量高于调整购电量的部分，违约电价是交易时刻电价的 50%。
> 调整购电量高于计划购电量的部分，超出部分的电价是交易时刻电价的 1.5 倍。
> 总的购电费用包括计划购电费用、紧急购电费用和调整购电量的相关费用。**

据此确定结算口径（下文 3.5 节给出线性化形式）：

$$F=\underbrace{\sum_t c_tA_t\Delta t}_{\text{基础电费}}+\underbrace{\sum_t 0.5c_t|A_t-P_t|\Delta t}_{\text{偏差结算}}+\underbrace{\sum_t 5c_t\,em_t}_{\text{紧急购电}}$$

其中 $P$ 为 0:00 计划购电量、$A$ 为调整后购电量。**该等价形式（L1 罚金）来自 GLM-5.3 方案的贡献**，
本文早期采用的"计划电费全额"口径经核对与题面不符，已修正。

### 1.2 两处不确定性

| 来源 | 说明 | 是否可预测 |
|---|---|---|
| **光伏** | 附件3 给出官方预报 | ✅ 有预报 |
| **负载** | **题目四问均未给负载预报** | ❌ 只能历史外推 |

**这与问题2 的情形一致**：附件2 提供的是"小区负载"与"光伏发电**实际**功率"（全年实测历史），
因此负载必须用历史数据外推。本文取 **lag-7**（上周同一天），依据见 2.2。

---

## 二、不确定性分析与安全裕度设计

### 2.1 附件3 光伏预报的精度

按"该发布时刻**实际覆盖**的区间"统计（0:00 发布的预报覆盖 1:00–24:00，12:00 只覆盖 13:00–24:00）：

| 发布时刻 | 覆盖时段 | MAE (kW) | σ (kW) |
|---|---|---|---|
| 0:00 | 6–144 | 198.55 | 380.18 |
| 6:00 | 42–144 | 157.39 | 270.23 |
| 12:00 | 78–144 | 63.57 | 122.76 |
| **18:00** | 114–144 | **0.04** | **0.35** |

**一个重要发现**：18:00 发布的预报在其覆盖区间（19:00–24:00）**误差几乎为零**——
因为**夜间光伏本就为 0**。也就是说，这份预报**几乎不含信息**，
它的价值只能来自"依据白天实际偏差造成的储能状态重排晚间购电"。

净负荷预报的不确定性则随发布时刻递减（σ：426 → 385 → 322 → 280 kW），见**图A**。

![图A  附件3 光伏预报精度：(a) 各发布时刻的误差；(b) 净负荷不确定性递减](figures/q3v2_figA_forecast_accuracy.pdf)

### 2.2 负载的 lag-7 外推

与问题2 相同，负载存在强周内结构（周五/周六仅为其余日的 63%），故用 lag-7：
**MAE = 186.58 kW，σ = 283.23 kW**。

### 2.3 安全裕度的设计

代价是不对称的：计划偏低 → 上调按 1.5 倍、缺电按 5 倍；计划偏高 → 下调**仅** 0.5 倍。
故应在预测需求上叠加正的安全裕度 $z\sigma$。实测最优 **$z=0.30$**（见第五节）。

---

## 三、数学模型

### 3.1 符号说明

| 符号 | 含义 | 符号 | 含义 |
|---|---|---|---|
| $T=144$，$\Delta t=1/6$ h | 时段数与步长 | $c_t$ | 电价（元/kWh） |
| $P_t$ | **0:00 计划购电量** (kWh) | $A_t$ | **调整后购电量** (kWh) |
| $L_t,V_t$ | 负载、光伏实际功率 (kW) | $\hat L_t$ | 负载 lag-7 外推 (kW) |
| $F_t^{(s)}$ | 第 $s$ 个发布时刻的光伏预报 (kW) | $\sigma_t^{(s)}$ | 该时刻净负荷预报残差 σ (kW) |
| $ch_t,dis_t$ | 充/放电量 (kWh) | $cur_t$ | 弃光电量 (kWh) |
| $E_t$ | 时段末储电量 (kWh) | $em_t$ | 紧急购电量 (kWh) |

参数：$E_0=6000$、$E_{\min}=1200$、$E_{\max}=10800$ kWh；$P_{\max}=5000$ kW；
$\eta_c=\eta_d=0.9$；$\overline{ch}=P_{\max}\Delta t=833.33$ kWh。

### 3.2 阶段划分（信息约束）

| 阶段 $s$ | 决策时刻 | 决策区间 | 执行区间 |
|---|---|---|---|
| 0 | 0:00 | 1–144 | 1–36 |
| 1 | 6:00 | 37–144 | 37–72 |
| 2 | 12:00 | 73–144 | 73–108 |
| 3 | 18:00 | 109–144 | 109–144 |

**每段 36 个时段 = 6 小时**，与预报发布时刻严格对齐。
（早期版本误用 4/4/8/8 小时的分段，导致"调整"几乎失效，已修正。）

### 3.3 阶段规划 LP

对阶段 $s$，以该时刻可用的最新预报规划区间 $[a_s,144]$：

$$\min\ \sum_{t=a_s}^{T}\Bigl[c_tA_t+1.5c_t\,d^+_t-0.5c_t\,d^-_t\Bigr]\Delta t$$

$$\text{s.t.}\quad A_t-cur_t+dis_t-ch_t=D_t,\qquad
D_t=\bigl(\hat L_t-F_t^{(s)}\bigr)\Delta t+z\,\sigma_t^{(s)}\Delta t$$

$$E_t=E_{t-1}+\eta_c\,ch_t-\frac{dis_t}{\eta_d},\qquad E_{s,0}=E^{(d)}_0$$

$$E_{\min}\le E_t\le E_{\max},\quad 0\le ch_t,dis_t\le\overline{ch},\quad A_t\ge0,\quad
0\le cur_t\le\bigl(F_t^{(s)}-\hat L_t\bigr)^+\Delta t$$

$$A_t-P_t=d^+_t-d^-_t,\qquad d^\pm_t\ge0$$

> **注意目标函数中 $d^-$ 的系数是 $-0.5c$ 而非 $+0.5c$**——因为"下调"能省下 0.5c 的电费。
> 这一符号若写错，LP 会误判"少买要花钱"，行为完全相反（本文在调试中踩过此坑）。

### 3.4 执行层

计划量 $P$ 与调整量 $A$ 一经确定即锁定；执行时按**实际**负载与光伏，储能实时响应
（跌至下限则触发紧急购电，光伏富余超出储能吸纳能力则弃光）：

$$A_t+V_t^{act}+dis_t+em_t=L_t^{act}+ch_t+cur_t$$

### 3.5 费用口径的线性化

$$c_t\min(P_t,A_t)+0.5c_t(P_t-A_t)^++1.5c_t(A_t-P_t)^+=c_tP_t+1.5c_t\,d^+_t-0.5c_t\,d^-_t$$

即"基础电费 + 偏差结算"的等价形式（L1 罚金）。

---

## 四、求解结果

求解环境：Python 3.10 + scipy 1.15.3（HiGHS）。全年 365 天 × 4 阶段 LP，耗时约 13 秒。

### 4.1 全年汇总

| 指标 | 数值 |
|---|---|
| 计划购电量 | 21 017 931.40 kWh |
| 调整后购电量 | 20 748 295.18 kWh |
| **基础电费** | **12 404 523.36 元** |
| **偏差结算费** | **727 402.30 元** |
| 紧急购电量 | 95 738.34 kWh |
| **紧急购电费** | **464 302.22 元** |
| **总费用** | **13 596 227.88 元** |
| 弃光量 | 1 264 919.04 kWh（消纳率 93%） |

### 4.2 逐日购电量

**图D** 给出全年逐日的计划购电量与调整后购电量。两者的差额（灰色区域）即"调整量"，
其分布反映了光伏预报误差的日间差异。

![图D  全年逐日计划购电量与调整后购电量](figures/q3v2_figD_daily_plan_vs_final.pdf)

### 4.3 弃光与紧急购电

**图E** 给出两者的月度分布：弃光集中在春夏（光伏出力强），紧急购电则分散在少数"预测失准日"。

![图E  弃光电量与紧急购电量的月度分布](figures/q3_fig3_curtail_em_monthly.pdf)

### 4.4 费用构成

**图F** 给出总费用的构成：基础电费占 91.2%、偏差费 5.3%、紧急购电费 3.4%。

![图F  总费用构成](figures/q3_fig6_deviation_cost_structure.pdf)

### 4.5 指定日期逐时段调度

![图G  2025-03-20 逐时段调度](figures/q3_fig5_typical_20250320.pdf)

![图H  2025-06-21 逐时段调度](figures/q3_fig5_typical_20250621.pdf)

### 4.6 结果表

按题目要求，指定日期（2025.3.20 / 6.21 / 9.23 / 12.21）的**计划购电量、调整购电量、
储能充放电量与紧急购电量**均已完整填入 `output/result3.xlsx`（四个工作表，
严格套用附件5 模板，已通过校验 V8a–e）。

---

## 五、关键建模决策

### 5.1 安全裕度 $z$ 的选取

实测扫描（见**图B**）：

| z | 0（无裕度） | **0.30** | 0.50 | 0.8416 | 1.2206 |
|---|---|---|---|---|---|
| 总费用 (万元) | 1 373.62 | **1 359.62** | 1 376.71 | 1 419.83 | 1 475.05 |

**最优 $z=0.30$，节省 139 989.68 元（1.0%）**。

> **与问题2 的对比**：问题2 的最优裕度是 **0.8416**（恰为报童临界分位数 $\Phi^{-1}(4c/5c)$），
> 而问题3 只有 **0.30**。原因是**问题3 已有"多时刻调整"机制部分对冲了不确定性**，
> 安全裕度的边际收益随之下降——**二者是替代关系**。

![图B  安全裕度敏感性](figures/q3v2_figB_margin_sensitivity.pdf)

### 5.2 预报时点数：是否需要引入其他时刻的预报

| 预报时点 | 总费用 (元) | 相对 1 时点 |
|---|---|---|
| 1（仅 0:00） | 15 572 120.87（无裕度口径） | — |
| **4（全部）** | **13 596 227.88** | **省约 197.6 万元（12.7%）** |

**答案：需要。** 节省主要来自紧急购电费下降——只用 0:00 预报时全天购电量一次锁定，
光伏预报误差持续累积，缺额只能靠 5 倍电价的紧急购电填补；引入后续时点后，
可把偏差转为 0.5/1.5 倍的常规结算，**用 0.5–1.5 倍的代价替换 5 倍的代价**。

![图C  预报时点数与总费用](figures/q3v2_figC_slots_vs_cost.pdf)

### 5.3 执行层的选择（一个反直觉的结论）

本文测试过把问题2 的"**日内 LP 闭环执行**"移植到问题3，**结果反而变差**：

| 执行方式 | 偏差费 (元) | 总费用 (元) |
|---|---|---|
| **储能实时响应（现行）** | 891 556 | **13 736 218** |
| 按计划执行（开环） | 566 893 | 15 748 339 |
| 日内 LP 闭环 | **10 257 639** | 22 666 470 |

**原因**：问题3 的执行层会改变储电量轨迹，而**调整层的偏差基准是"当天 0:00 的计划"**——
储电量轨迹一变，计划与调整就双双偏离，偏差费被放大 10 倍以上。
**问题3 的"计划—调整"机制要求执行层与规划层保持耦合**，这与问题2（无调整机制）根本不同。

---

## 六、模型校验

`code/q3_verify.py` → **14 项全部 PASS**：

| 校验项 | 结果 |
|---|---|
| V1 计划购电量与净负荷需求的量级关系 | PASS |
| V2 储能动态 $E_t=E_{t-1}+\eta_c ch\Delta t-dis\Delta t/\eta_d$ | PASS，残差 0.000e+00 |
| V3a–c 储电量界 / 充放功率界 / 紧急购电非负 | PASS |
| V5 执行层能量平衡（含白付项 $w\ge0$） | PASS，负残差 1.8e−12 |
| V6 费用复算 | PASS，12 404 523.36 + 727 402.30 + 464 302.22 = **13 596 227.88 元** |
| V7 弃光 ≤ 光伏富余 | PASS，1 264 919.04 ≤ 3 058 159.92 kWh |
| V8a–e `result3.xlsx` 模板合规 | PASS（4 表 / 表头/行数/数值回读一致） |

---

## 七、结论

1. **问题3 的不确定性有两个来源**：光伏（附件3 预报）与负载（无预报，须 lag-7 外推）；
2. **附件3 的 18:00 预报几乎不含信息**（覆盖区间为夜间、误差为 0），其价值仅在于依据
   白天偏差造成的储能状态重排晚间购电；
3. **安全裕度取 $z=0.30$**，节省 1.0%；**该值远小于问题2 的报童值 0.8416**，
   因为"多时刻调整"与"安全裕度"是替代关系；
4. **需要引入其他时刻的预报**：4 时点比单点省约 197.6 万元（12.7%）；
5. **执行层不宜用日内 LP 闭环**（会破坏"计划—调整"耦合，偏差费放大 10 倍）——
   这与问题2 的结论相反，是两者的结构性差异；
6. 最终全年总费用 **13 596 227.88 元**，14 项校验全部通过，
   `result3.xlsx` 已严格套用附件5 模板导出。

---

## 参考文献

[1] 全国大学生数学建模竞赛组委会. 2026 年高教社杯全国大学生数学建模竞赛 C 题：微网与外部电网电力调控策略[Z]. 2026.

[2] 中国工业与应用数学学会. 全国大学生数学建模竞赛论文格式规范[Z]. 2026.

[3] Porteus E L. Foundations of Stochastic Inventory Theory[M]. Stanford: Stanford University Press, 2002.

[4] Birge J R, Louveaux F. Introduction to Stochastic Programming[M]. 2nd ed. New York: Springer, 2011.

[5] Mayne D Q, Rawlings J B, Rao C V, et al. Constrained model predictive control: Stability and optimality[J]. Automatica, 2000, 36(6): 789-814.

[6] Hyndman R J, Athanasopoulos G. Forecasting: Principles and Practice[M]. 3rd ed. Melbourne: OTexts, 2021.

[7] Antonanzas J, Osorio N, Escobar R, et al. Review of photovoltaic power forecasting[J]. Solar Energy, 2016, 136: 78-111.

[8] Harsha P, Dahleh M. Optimal management and sizing of energy storage under dynamic pricing for the efficient integration of renewable energy[J]. IEEE Transactions on Power Systems, 2015, 30(3): 1164-1181.

[9] Luthander R, Widén J, Nilsson D, et al. Photovoltaic self-consumption in buildings: A review[J]. Applied Energy, 2015, 142: 80-94.

[10] 王成山, 武震, 李鹏. 微电网关键技术研究[J]. 电工技术学报, 2014, 29(2): 1-12.

[11] 国家发展和改革委员会. 关于进一步完善分时电价机制的通知（发改价格〔2021〕1093 号）[Z]. 2021-07-26.

[12] 国家发展和改革委员会, 国家能源局. 关于加快推动新型储能发展的指导意见（发改能源规〔2021〕1051 号）[Z]. 2021-07-15.

[13] Virtanen P, Gommers R, Oliphant T E, et al. SciPy 1.0: fundamental algorithms for scientific computing in Python[J]. Nature Methods, 2020, 17(3): 261-272.

[14] Huangfu Q, Hall J A J. Parallelizing the dual revised simplex method[J]. Mathematical Programming Computation, 2018, 10(1): 119-142.

[15] Dantzig G B. Linear Programming and Extensions[M]. Princeton: Princeton University Press, 1974.

---

## 附录  复现方法

```bash
cd code
python q3_forecast_error.py        # 不确定性分析（σ 表）-> results/q3_sigma_net_slot*.npy
python q3_solve.py --slots 4 --exec rule --cost-mode Y   # 主结果 -> output/result3.xlsx
python q3_verify.py                # 14 项校验 -> ALL PASS
python q3_figures_v2.py            # 生成报告用图
```

环境：Python 3.10 + scipy 1.15.3（HiGHS）+ numpy + pandas + openpyxl + matplotlib + TeX Live 2026。
"""

io.open(os.path.join(R, '问题3_方案A_DeepSeek版_审阅与改进报告.md'), 'w',
        encoding='utf-8').write(MD)
print('已写出报告', len(MD), '字符')

sys.path.insert(0, r'C:\Users\35941\Desktop\cumcm2026C_q3\glm_code')
import md2tex_q3 as M
M.R = R
M.build('问题3_方案A_DeepSeek版_审阅与改进报告.md', '问题3 方案A 审阅与改进')
