# -*- coding: utf-8 -*-
"""
common_q3.py —— 2026 高教社杯 C 题 问题3 公共模块

在问题2 的基础上新增**附件3（光伏预报）**的读取与时间对齐。

附件3 结构（实测）：
    表头：日期 | 预报时刻 | 预报1小时 | 预报2小时 | ... | 预报24小时   （1461 行 = 365 天 × 4 行）
    每天 4 行，预报时刻分别为 0:00 / 6:00 / 12:00 / 18:00；
    "预报k小时" 表示 **发布时刻 + k 小时** 的整点光伏功率预测（k = 1..24）。
    即 6:00 发布的"预报1小时"是 7:00 的预测值，而非 6:00 本身。
    ⚠ DeepSeek 原方案在此处的插值把"预报1小时"对到了 t=0（0:00），整体错位 1 小时。

时段约定（沿用问题1/2）：
    附件1/2/3 的 144 个采样点为 0:10, 0:20, ..., 24:00，采样时刻 = 10 分钟区间右端点，
    时段 t（1-based）覆盖 [10(t-1), 10t) 分钟，t=6 → 1:00，t=144 → 24:00。
    因此整点 k:00（k = 1..24）恰好对应时段 t = 6k。
"""
import os
import pandas as pd
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
DATA_DIR = os.path.join(ROOT, 'data')
FIG_DIR = os.path.join(ROOT, 'figures')
OUT_DIR = os.path.join(ROOT, 'output')
RES_DIR = os.path.join(ROOT, 'results')
for _d in (DATA_DIR, FIG_DIR, OUT_DIR, RES_DIR):
    os.makedirs(_d, exist_ok=True)

SRC1 = r'C:\Users\35941\Desktop\C题\附件\附件1.xlsx'
SRC2 = r'C:\Users\35941\Desktop\C题\附件\附件2.xlsx'
SRC3 = r'C:\Users\35941\Desktop\C题\附件\附件3.xlsx'
TPL_RESULT3 = r'C:\Users\35941\Desktop\C题\附件\附件5\result3.xlsx'

# ---------------- 物理参数（附录1） ----------------
DT = 1.0 / 6.0
NT = 144
E_INIT = 6000.0
E_MIN = 1200.0
E_MAX = 10800.0
P_MAX = 5000.0
ETA_C = 0.9
ETA_D = 0.9

SAVE_START = pd.Timestamp('2025-02-01')
KEY_DATES = [pd.Timestamp('2025-03-20'), pd.Timestamp('2025-06-21'),
             pd.Timestamp('2025-09-23'), pd.Timestamp('2025-12-21')]
TABLE1_CLOCKS = ['10:00', '12:00', '14:00', '16:00', '18:00', '20:00']

# 四个预报发布时刻（0:00/6:00/12:00/18:00）对应的时段划分（1-based，含端点）
# 每段 36 个时段 = 6 小时：0:00-6:00 / 6:00-12:00 / 12:00-18:00 / 18:00-24:00
# 【修正】原值 [1,25,49,97] / [24,48,96,144] 对应 4/4/8/8 小时，与预报发布时刻并不对齐，
#         会使“调整”几乎失去作用（曾据此误判“预报时点越多越贵”）。
SLOT_HOURS = [0, 6, 12, 18]
SLOT_START_T = [1, 37, 73, 109]         # 各阶段负责的时段起点
SLOT_END_T = [36, 72, 108, 144]         # 各阶段负责的时段终点


def fmt_clock(minutes):
    day, rem = divmod(int(minutes), 1440)
    hh, mm = divmod(rem, 60)
    return '%d:%02d' % (hh, mm) + ('+1' if day == 1 else '')


def t_to_interval(t):
    return '%s-%s' % (fmt_clock(10 * (t - 1)), fmt_clock(10 * t))


def clock_to_t(label):
    hh, mm = label.split(':')
    minutes = int(hh) * 60 + int(mm)
    assert minutes % 10 == 0 and 0 <= minutes < 1440, label
    return minutes // 10 + 1


def load_price(path=SRC1):
    df = pd.read_excel(path)
    price = pd.to_numeric(df['电价'], errors='raise').to_numpy(float)
    assert len(price) == NT
    return price


def load_year(sheet):
    df = pd.read_excel(SRC2, sheet_name=sheet)
    dates = pd.to_datetime(df.iloc[:, 0]).to_numpy()
    vals = df.iloc[:, 1:1 + NT].apply(pd.to_numeric, errors='raise').to_numpy(float)
    assert vals.shape == (365, NT), vals.shape
    return dates, vals


def load_forecast(path=SRC3):
    """读取附件3，返回形状 (365, 4, 24) 的预报数组 fc[d, s, k-1] = 第 d 天第 s 个发布时刻
    的"预报k小时"（k=1..24）。日期列只在每天第 1 行出现，需向下填充。
    """
    df = pd.read_excel(path)
    df.columns = ['date', 'slot'] + ['h%d' % k for k in range(1, 25)]
    df['date'] = df['date'].ffill()
    df['date'] = pd.to_datetime(df['date'])
    slots = df['slot'].astype(str).str.strip()
    assert len(df) == 365 * 4, len(df)
    days = pd.unique(df['date'])
    assert len(days) == 365, len(days)
    order = {str(h) + ':00': i for i, h in enumerate(SLOT_HOURS)}
    fc = np.zeros((365, 4, 24))
    day_idx = {d: i for i, d in enumerate(days)}
    for _, row in df.iterrows():
        d = day_idx[row['date']]
        s = order[slots.loc[row.name]]
        fc[d, s, :] = [float(row['h%d' % k]) for k in range(1, 25)]
    return days, fc


def stage_forecast(fc_day, slot_idx, prev_10min=None):
    """返回某阶段可用的 144 个 10 分钟光伏预报值（与附件1/2 的时段对齐）。

    fc_day[s, k-1] 是第 s 个发布时刻（0:00/6:00/12:00/18:00）的"预报 k 小时"，
    即 **发布时刻 + k 小时** 的整点预测，k = 1..24。整点 k:00 对应时段 t = 6k。

    新预报的有效区间是 [发布时刻+1h, 发布时刻+24h]，
    发布时刻之后、1 小时之内的时段（以及更早的时段）沿用上一次预报 prev_10min；
    prev_10min 为 None 时（0:00 阶段）这些时段取 0（夜间光伏为 0）。
    """
    h = SLOT_HOURS[slot_idx]
    t_hour = (h + np.arange(1, 25)) * 6               # 发布时刻+1h .. +24h 的时段号
    y = np.asarray(fc_day[slot_idx], float)
    out = np.zeros(NT) if prev_10min is None else np.array(prev_10min, float)
    t_all = np.arange(1, NT + 1)
    # 【口径 A】新预报自“发布时刻+1h”起生效，之前沿用旧预报（保守）
    mask = t_all >= 6 * (h + 1)
    out[mask] = np.interp(t_all[mask], t_hour, y)
    return np.maximum(0.0, out)


def forecast_to_10min(fc_slot):
    """（保留的简化接口）把单个发布时刻的 24 个整点预报展开为 144 个 10 分钟值。"""
    t_hour = np.arange(1, 25) * 6
    t_all = np.arange(1, NT + 1)
    return np.maximum(0.0, np.interp(t_all, t_hour, np.asarray(fc_slot, float)))


if __name__ == '__main__':
    import sys, io
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
    price = load_price()
    dates, load = load_year('小区负载')
    _, pv = load_year('光伏发电实际功率')
    fdates, fc = load_forecast()
    print('电价范围 [%.4f, %.4f]' % (price.min(), price.max()))
    print('负载范围 [%.1f, %.1f] kW' % (load.min(), load.max()))
    print('光伏实际范围 [%.1f, %.1f] kW' % (pv.min(), pv.max()))
    print('预报数组形状', fc.shape, '  预报范围 [%.1f, %.1f] kW' % (fc.min(), fc.max()))
    # 校验：0:00 预报应覆盖 1:00~24:00 的整点
    d0 = pd.Timestamp('2025-06-21')
    di = int(np.where(pd.to_datetime(fdates) == d0)[0][0])
    print()
    print('以 %s 为例（0:00 预报的前 6 个整点 = 1:00..6:00）：' % d0.date())
    print('  ', np.round(fc[di, 0, :6], 2))
    v10 = forecast_to_10min(fc[di, 0])
    print('  展开到 144 个 10 分钟值后：t=6(1:00)=%.2f  t=12(2:00)=%.2f  t=144(24:00)=%.2f'
          % (v10[5], v10[11], v10[143]))
    print('  实际光伏在同时刻：t=6=%.2f  t=12=%.2f  t=144=%.2f'
          % (pv[di][5], pv[di][11], pv[di][143]))
