# -*- coding: utf-8 -*-
"""
q3_model_v2.py —— 问题3 改善版模型（吸收问题2 的两项发现）

相对原版的改进：
  C1  **执行层改为日内 LP（闭环）**：计划量 P 与调整量 A 均锁定不变，
      但执行时用实际负载/光伏，储能**逐时段最优使用**以最小化 5 倍紧急购电。
      （问题2 实测该做法比"按计划执行"省 5.0%–8.7%）
  C2  **阶段规划加安全裕度**：各阶段的需求取
          D_t = (负载预测 − 该阶段光伏预报)·Δt + z·σ_t·Δt
      其中 σ_t 为该发布时刻**实际覆盖区间**内的净负荷预报残差标准差
      （由 q3_forecast_error.py 实测），z 为安全裕度系数。
      代价不对称（计划偏低→1.5c 或 5c；偏高→仅 0.5c），故正裕度有利。
  C3  沿用原版正确的部分：L1 结算口径 C = c·A + 0.5c|A−P|、6/6/6/6 阶段划分、
      1 月预热、负载 lag-7 外推。

费用（题面口径）：
    F = Σ c_t·A_t·Δt  +  Σ 0.5c_t·|A_t − P_t|·Δt  +  Σ 5c_t·em_t
"""
import os, sys, io
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import numpy as np
from scipy.optimize import linprog
from common_q3 import (DT, NT, E_INIT, E_MIN, E_MAX, P_MAX, ETA_C, ETA_D,
                       SLOT_START_T, SLOT_END_T, SLOT_HOURS, stage_forecast, load_price, load_year,
                       load_forecast)

DE = P_MAX * DT                 # 单时段最大充放电量 (kWh)
BIAS_UP, BIAS_DOWN, EM_K = 1.5, 0.5, 5.0


def lag7_forecast(X, lag=7):
    n = X.shape[0]
    P = np.zeros_like(X)
    for d in range(n):
        P[d] = X[d - lag] if d >= lag else (X[:d].mean(axis=0) if d > 0 else X[d])
    return P


# ==================== 阶段规划 LP ====================
def solve_stage(price, load_pred, fc_pv, prev_A, a, soc_init, z, sigma,
                eta_c=ETA_C, eta_d=ETA_D):
    """规划时段 [a, 144]。变量 7 个/时段：[A, ch, dis, curt, E, d+, d-]。

    prev_A : 上一阶段的调整量（用于 d± 偏差基准）；阶段 0 传 None
    z      : 安全裕度系数；sigma: 逐时段净负荷残差标准差 (kW)
    """
    n = NT - a + 1
    nv = 7 * n
    A, C, D, CU, E, DP, DM = 0, n, 2 * n, 3 * n, 4 * n, 5 * n, 6 * n
    idx = np.arange(a - 1, NT)
    p_price = price[idx]
    p_load = load_pred[idx]
    p_pv = fc_pv[idx]
    p_sig = sigma[idx]
    D_req = (p_load - p_pv) * DT + z * p_sig * DT          # kWh

    c = np.zeros(nv)
    if prev_A is None:
        c[A:A + n] = p_price * DT                          # 阶段 0：min Σc·P
    else:
        # ★ 费用 c·min(P,A) + 0.5c(P−A)⁺ + 1.5c(A−P)⁺ 关于 A 的线性展开为
        #      c·P + 1.5c·d⁺ − 0.5c·d⁻     （P 为常数）
        #   故 d⁺ 系数 +1.5c、d⁻ 系数 −0.5c（下调可净省 0.5c）。
        #   早期版本把 d⁻ 写成 +0.5c，会让 LP 误判“少买要花钱”，行为完全相反。
        c[A:A + n] = p_price * DT                          # 基础 c·A
        c[DP:DP + n] = BIAS_UP * p_price * DT              # +1.5c
        c[DM:DM + n] = -BIAS_DOWN * p_price * DT           # −0.5c

    A_eq, b_eq = [], []
    for k in range(n):                                     # 平衡：A − curt + dis − ch = D_req
        row = np.zeros(nv)
        row[A + k] = 1.0; row[CU + k] = -1.0; row[D + k] = 1.0; row[C + k] = -1.0
        A_eq.append(row); b_eq.append(D_req[k])
    for k in range(n):                                     # 储能动态
        row = np.zeros(nv)
        row[E + k] = 1.0
        if k > 0:
            row[E + k - 1] = -1.0
        row[C + k] = -eta_c; row[D + k] = 1.0 / eta_d
        A_eq.append(row)
        b_eq.append(soc_init if k == 0 else 0.0)
    if prev_A is not None:                                 # A − prev_A = d+ − d-
        p_ref = prev_A[idx]
        for k in range(n):
            row = np.zeros(nv)
            row[A + k] = 1.0; row[DP + k] = -1.0; row[DM + k] = 1.0
            A_eq.append(row); b_eq.append(p_ref[k])

    cur_hi = np.maximum(0.0, np.maximum(0.0, (p_pv - p_load)) * DT)
    bounds = ([(0.0, None)] * n + [(0.0, DE)] * n + [(0.0, DE)] * n
              + [(0.0, float(cur_hi[k])) for k in range(n)]
              + [(E_MIN, E_MAX)] * n + [(0.0, None)] * n + [(0.0, None)] * n)
    res = linprog(c, A_eq=np.array(A_eq), b_eq=np.array(b_eq), bounds=bounds, method='highs')
    if not res.success:
        raise RuntimeError('阶段 LP 失败: ' + res.message + ' (a=%d, soc=%.1f)' % (a, soc_init))
    x = res.x
    return x[A:A + n], x[C:C + n], x[D:D + n], x[CU:CU + n], x[E:E + n]


# ==================== 执行层：日内 LP（闭环） ====================
def execute_intraday_lp(price, L_act, V_act, A_final, E0):
    """A_final（最终购电量）锁定不变；储能逐时段最优使用以最小化 Σ5c·U。

        min Σ 5c·U
        s.t. G − ch + dis − cur = L·Δt − V·Δt
             U ≥ G − A_final, U ≥ 0
             E(t) = E(t−1) + η_c·ch − dis/η_d
    """
    G, C, D, CU, S, U = 0, NT, 2 * NT, 3 * NT, 4 * NT, 5 * NT
    nv = 6 * NT
    c = np.zeros(nv); c[U:U + NT] = EM_K * price
    A_eq, b_eq = [], []
    for t in range(NT):
        row = np.zeros(nv)
        row[G + t] = 1.0; row[C + t] = -1.0; row[D + t] = 1.0; row[CU + t] = -1.0
        A_eq.append(row); b_eq.append(L_act[t] * DT - V_act[t] * DT)
    for t in range(NT):
        row = np.zeros(nv)
        row[S + t] = 1.0
        if t > 0:
            row[S + t - 1] = -1.0
        row[C + t] = -ETA_C; row[D + t] = 1.0 / ETA_D
        A_eq.append(row); b_eq.append(E0 if t == 0 else 0.0)
    A_ub, b_ub = [], []
    for t in range(NT):
        row = np.zeros(nv)
        row[G + t] = 1.0; row[U + t] = -1.0
        A_ub.append(row); b_ub.append(float(A_final[t]))
    bounds = ([(0.0, None)] * NT + [(0.0, DE)] * NT + [(0.0, DE)] * NT
              + [(0.0, float(V_act[t] * DT)) for t in range(NT)]
              + [(E_MIN, E_MAX)] * NT + [(0.0, None)] * NT)
    res = linprog(c, A_ub=np.array(A_ub), b_ub=np.array(b_ub),
                  A_eq=np.array(A_eq), b_eq=np.array(b_eq), bounds=bounds, method='highs')
    if not res.success:
        raise RuntimeError('日内 LP 失败: ' + res.message)
    x = res.x
    return x[U:U + NT], x[C:C + NT], x[D:D + NT], x[CU:CU + NT], x[S:S + NT], float(x[S + NT - 1])


# ==================== 单日 MPC ====================
def run_day(price, load_act, load_pred, pv_act, fc_day, sig_day, soc_init,
            n_slots=4, z=0.0, adj='fixed', exec_mode='intraday'):
    """MPC 两阶段结构（★ 关键设计）：

      阶段 0（0:00）：用 0:00 预报规划**计划购电量 P** 与**储能轨迹**（ch_plan / dis_plan）。
                     储能轨迹一经确定即**不再更改**（它是微网的运行计划）。
      阶段 s>0     ：只按最新预报**修正购电量**，储能轨迹沿用阶段 0 的计划：
                     A_t = D_t^(s) − dis_plan_t + ch_plan_t
                     —— 若让调整层重新优化储能，就会把“套利”误当成“偏差”，
                        导致偏差费虚高（实测会从 1.7M 暴增到 10.3M）。

      执行层：日内 LP（闭环）—— A 锁定，储能逐时段最优使用以最小化 5 倍紧急购电。
    """
    starts = list(SLOT_START_T[:n_slots])
    ends = list(SLOT_END_T[:n_slots])
    ends[-1] = NT
    # ---- 阶段 0：规划 P 与储能轨迹 ----
    fc0 = stage_forecast(fc_day, 0, None)
    P, ch_plan, dis_plan, curt_plan, E_plan = solve_stage(
        price, load_pred, fc0, None, 1, soc_init, z=z, sigma=sig_day[0])
    # ---- 阶段 s>0：调整 ----
    A = P.copy()
    prev_fc = fc0
    for s in range(1, n_slots):
        a = starts[s]
        fc10 = stage_forecast(fc_day, s, prev_fc)
        prev_fc = fc10
        if adj == 'fixed':
            # 储能轨迹不变，只按新预报修正购电量
            D_new = ((load_pred[a - 1:] - fc10[a - 1:]) * DT
                     + z * sig_day[s][a - 1:] * DT)
            A[a - 1:] = np.maximum(0.0, D_new - dis_plan[a - 1:] + ch_plan[a - 1:])
        else:
            # 调整层重新求解 LP（含储能自由度）；★ 偏差基准始终是 0:00 的计划 P
            As, chs, diss, curs, Es = solve_stage(
                price, load_pred, fc10, P, a, soc_init, z=z, sigma=sig_day[s])
            A[a - 1:] = As
    # ---- 执行层 ----
    if exec_mode == 'intraday':
        em, ch, dis, curt, E, soc = execute_intraday_lp(price, load_act, pv_act, A, soc_init)
    else:
        em, ch, dis, curt, E, soc = execute_plan_v1(load_act, pv_act, A,
                                                    ch_plan, dis_plan, soc_init)
    return dict(P=P, A=A, ch=ch, dis=dis, curt=curt, em=em, E=E, e_end=soc)


def execute_plan_v1(L_act, V_act, A_final, ch_plan, dis_plan, E0):
    """按计划执行（原版做法）：储能沿用规划的 ch/dis，偏差由弃光/紧急购电吸收。"""
    em = np.zeros(NT); curt = np.zeros(NT); E = np.zeros(NT)
    bal = A_final + V_act * DT + dis_plan - L_act * DT - ch_plan
    pv_sur = np.maximum(0.0, (V_act - L_act) * DT)
    curt = np.maximum(0.0, np.minimum(bal, pv_sur))
    em = np.maximum(0.0, -bal)
    e = E0
    for t in range(NT):
        e += ch_plan[t] * ETA_C - dis_plan[t] / ETA_D
        E[t] = e
    return em, ch_plan, dis_plan, curt, E, e


# ==================== 全年 ====================
def run(price, L, V, fc, n_slots=4, z=0.0, sig_dir=None, verbose=True,
        adj='fixed', exec_mode='intraday'):
    import pandas as pd
    n = L.shape[0]
    Lp = lag7_forecast(L)
    sig_day = []
    for s in range(4):
        p = os.path.join(sig_dir, 'q3_sigma_net_slot%d.npy' % s)
        sig_day.append(np.load(p) if os.path.exists(p) else np.zeros(NT))
    soc = E_INIT
    recs = []
    for d in range(n):
        r = run_day(price, L[d], Lp[d], V[d], fc[d], sig_day, soc, n_slots=n_slots, z=z,
                     adj=adj, exec_mode=exec_mode)
        soc = float(min(max(r['e_end'], E_MIN), E_MAX))
        recs.append(r)
        if verbose and (d + 1) % 100 == 0:
            print('  已推演 %d / %d 天' % (d + 1, n))
    return recs


def summarize(recs, dates):
    import pandas as pd
    idx = [i for i, d in enumerate(dates) if pd.Timestamp(d) >= pd.Timestamp('2025-02-01')]
    g = lambda k: float(sum(recs[i][k].sum() for i in idx))
    base = dev = emc = 0.0
    price = load_price()
    for i in idx:
        r = recs[i]
        # A / em 已是电量(kWh)，勿再乘 DT
        base += float((np.minimum(r['P'], r['A']) * price).sum())
        d_plus = np.maximum(0.0, r['A'] - r['P'])
        d_minus = np.maximum(0.0, r['P'] - r['A'])
        dev += float((price * (BIAS_DOWN * d_minus + BIAS_UP * d_plus)).sum())
        emc += float((EM_K * price * r['em']).sum())
    return dict(days=len(idx), plan_kWh=g('P'), final_kWh=g('A'),
                base_cost=base, dev_cost=dev, em_cost=emc,
                total_cost=base + dev + emc, em_kWh=g('em'), curt_kWh=g('curt'),
                charge_kWh=g('ch'), discharge_kWh=g('dis'), z=None)


if __name__ == '__main__':
    import argparse, json, time
    ap = argparse.ArgumentParser()
    ap.add_argument('--slots', type=int, default=4, choices=[1, 2, 4])
    ap.add_argument('--z', type=float, default=0.0)
    ap.add_argument('--adj', choices=['fixed', 'lp'], default='fixed',
                    help='fixed=调整层只改购电量（默认）；lp=调整层重新求解含储能')
    ap.add_argument('--exec', choices=['intraday', 'plan'], default='intraday',
                    help='intraday=日内LP闭环（默认）；plan=按计划开环')
    ap.add_argument('--tag', default=None)
    a = ap.parse_args()
    from common_q3 import RES_DIR
    price = load_price()
    dates, L = load_year('小区负载')
    _, V = load_year('光伏发电实际功率')
    _, fc = load_forecast()
    print('改善版：日内 LP 执行 + 安全裕度 z=%.3f | 预报时点 %d' % (a.z, a.slots))
    t0 = time.time()
    recs = run(price, L, V, fc, n_slots=a.slots, z=a.z, sig_dir=RES_DIR,
               adj=a.adj, exec_mode=a.exec)
    s = summarize(recs, dates)
    s['z'] = a.z; s['slots'] = a.slots; s['seconds'] = round(time.time() - t0, 1)
    s['adj'] = a.adj; s['exec_mode'] = a.exec
    print('计划购电 %.0f kWh → 最终 %.0f kWh' % (s['plan_kWh'], s['final_kWh']))
    print('基础 %.2f + 偏差 %.2f + 紧急 %.2f = 总费用 %.2f 元'
          % (s['base_cost'], s['dev_cost'], s['em_cost'], s['total_cost']))
    print('紧急购电 %.0f kWh | 弃光 %.0f kWh | 耗时 %.1f s'
          % (s['em_kWh'], s['curt_kWh'], s['seconds']))
    tag = a.tag or ('v2_slots%d_z%.3f' % (a.slots, a.z))
    os.makedirs(RES_DIR, exist_ok=True)
    json.dump(s, io.open(os.path.join(RES_DIR, 'q3_%s.json' % tag), 'w',
                         encoding='utf-8'), ensure_ascii=False, indent=2)
    print('已写出 results/q3_%s.json' % tag)
