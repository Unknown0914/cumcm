# -*- coding: utf-8 -*-
"""
2026高教社杯C题 问题3：含光伏预报更新与购电调整的微网多阶段优化
依赖: numpy pandas scipy>=1.6 openpyxl    运行: python problem3.py
"""
import numpy as np
import pandas as pd
from scipy.optimize import linprog

# ==================== 1. 全局参数 ====================
T, DT       = 144, 1/6                 # 时段数/时段长(h)
ETA_C, ETA_D = 0.90, 1.00              # 充/放电效率(可改ETA_D=1/0.9做敏感性)
E_INIT, E_MIN, E_MAX = 6000., 1200., 10800.
P_BAR       = 5000. * DT                # 单时段最大充/放电量 kWh
K_RELEASE   = (0, 36, 72, 108)          # 预报发布: 0:00/6:00/12:00/18:00
K_ADJ       = (36, 72, 108)             # 允许调整的发布时刻
KNAME       = {0:'0:00', 36:'6:00', 72:'12:00', 108:'18:00'}
DEV_K, EM_K = 0.5, 5.0                  # 偏差罚金系数 / 紧急购电价格倍数
SPEC_DATES  = ['2025-03-20','2025-06-21','2025-09-23','2025-12-21']
OUT_START   = pd.Timestamp('2025-02-01')

SLOT_LB = []
for i in range(T):                      # 时段标签=结束时刻(与附件1口径一致)
    m = (i+1)*10; h, mm = divmod(m, 60)
    SLOT_LB.append('0:00+1' if h == 24 else f'{h}:{mm:02d}')

# ==================== 2. 数据读取 ====================
def load_all(f1='附件1.xlsx', f2='附件2.xlsx', f3='附件3.xlsx'):
    """★★★ 唯一需按你的附件实际格式修改的函数 ★★★"""
    # 附件1: 电价(每天相同) —— 列: 时间|电价|小区负载|光伏发电预测功率
    price = pd.read_excel(f1)['电价'].to_numpy(float)[:T]
    # 附件2: 两个工作表, 行=日期, 列=0:10..0:00+1 (kW)
    dfL = pd.read_excel(f2, sheet_name='小区负载',        index_col=0)
    dfV = pd.read_excel(f2, sheet_name='光伏发电实际功率', index_col=0)
    L   = dfL.iloc[:, :T].to_numpy(float) * DT            # → kWh
    PV  = dfV.iloc[:, :T].to_numpy(float) * DT
    dates = pd.to_datetime(dfL.index)
    # 附件3: 光伏预报, 假定长表 [日期|发布时刻|+1h|+2h|...|+24h] (kW)
    # 若你的格式不同(如每天一个块/宽表), 只需改此循环
    df3  = pd.read_excel(f3)
    kmap = {'0:00':0, '6:00':36, '12:00':72, '18:00':108}
    dpos = {d.normalize(): i for i, d in enumerate(dates)}
    fc   = {}
    for _, row in df3.iterrows():
        d = pd.Timestamp(row.iloc[0]).normalize()
        k = kmap[str(row.iloc[1])]
        fc[(dpos[d], k)] = row.iloc[2:26].to_numpy(float)
    return price, L, PV, dates, fc

def make_dummy(n_days=60, seed=0):
    """合成数据自测: 验证全流程可跑通、且能复现'调整更优'的定性结论"""
    rng   = np.random.default_rng(seed)
    dates = pd.date_range('2025-01-01', periods=n_days)
    h     = np.arange(T)/6.0
    price = np.where((h>=18)&(h<21), 1.35, np.where((h>=23)|(h<7), 0.42, 0.90))
    baseL = 3200 + 1800*np.exp(-((h-19.5)/4.5)**2) + 800*np.exp(-((h-11)/3.5)**2)
    L  = np.tile(baseL, (n_days,1))/DT + rng.normal(0, 60, (n_days,T))
    pvshape = 6500*np.exp(-((h-12.5)/3.2)**2)
    pvshape = np.where((pvshape<5)|(h<5.5)|(h>19), 0, pvshape)
    PV = np.tile(pvshape,(n_days,1))*rng.uniform(0.45,1.35,(n_days,1))/DT
    fc = {}
    for d in range(n_days):
        for k in K_RELEASE:
            hrs = k/6 + np.arange(1,25)
            tr  = 6500*np.exp(-((hrs-12.5)/3.2)**2)
            tr  = np.where((tr<5)|(hrs<5.5)|(hrs>19), 0, tr)
            sc  = 0.35 - 0.28*k/108          # 发布越晚误差越小
            fc[(d,k)] = tr*rng.uniform(1-sc, 1+sc, 24)
    return price, L, PV, dates, fc

# ==================== 3. LP核心求解器 ====================
def _lp(Ls, Fs, ps, e0, Pref=None):
    """
    求解一个时段块上的LP(4.3/4.4节模型)
    变量布局(每时段7个): [x, ch, dis, curt, E, u, v]
    Pref=None  → 阶段一(无偏差罚金); 否则为阶段二(带偏差罚金)
    返回: x(购电), ch, dis, curt, E(时段末电量)
    """
    m, n = len(Ls), 7*len(Ls)
    c = np.zeros(n); c[0::7] = ps
    if Pref is not None:
        c[5::7] = DEV_K*ps; c[6::7] = DEV_K*ps
    nrow = 3*m if Pref is not None else 2*m
    A = np.zeros((nrow, n)); b = np.zeros(nrow)
    i = np.arange(m)
    # (a) 能量平衡: x + dis - ch - curt = L - F
    A[i,7*i]=1; A[i,7*i+2]=1; A[i,7*i+1]=-1; A[i,7*i+3]=-1; b[i]=Ls-Fs
    # (b) 储能动态: E_i - E_{i-1} - ηc·ch + dis/ηd = 0 (i=0时 = e0)
    r = m+i
    A[r,7*i+4]=1; A[r,7*i+1]=-ETA_C; A[r,7*i+2]=1/ETA_D
    if m > 1: A[r[1:], 7*i[:-1]+4] = -1
    b[r[0]] = e0
    # (c) 偏差约束: x - u + v = P
    if Pref is not None:
        r2 = 2*m+i
        A[r2,7*i]=1; A[r2,7*i+5]=-1; A[r2,7*i+6]=1; b[r2]=Pref
    bounds = [(0,None),(0,P_BAR),(0,P_BAR),(0,None),(E_MIN,E_MAX),(0,None),(0,None)]*m
    res = linprog(c, A_eq=A, b_eq=b, bounds=bounds, method='highs')
    if not res.success: raise RuntimeError('LP失败: '+res.message)
    z = res.x
    return z[0::7], z[1::7], z[2::7], z[3::7], z[4::7]

def fc_slots(fc24, k):
    """k时刻发布的24整点预报(kW) → 当日剩余时段电量(kWh), 线性插值"""
    xp = k/6.0 + np.arange(1, 25)
    mid = (np.arange(k+1, T+1) - 0.5)/6.0
    return np.interp(mid, xp, fc24)*DT

def rt_slot(a, pv, L, e):
    """单时段实时贪心调度(4.5节), 返回 ch,dis,curt,em,e_next"""
    ch = dis = cur = em = 0.0
    g = a + pv - L
    if g >= 0:
        ch = min(g, P_BAR, (E_MAX-e)/ETA_C); cur = g - ch
    else:
        need = -g
        dis = min(need, P_BAR*ETA_D, max(0.0,(e-E_MIN))*ETA_D); em = need - dis
    return ch, dis, cur, em, e + ETA_C*ch - dis/ETA_D

# ==================== 4. 单日推演 ====================
def sim_day(Ld, Vd, price, fcd, e0, adj=K_ADJ):
    F0 = fc_slots(fcd[0], 0)
    P, *_ = _lp(Ld, F0, price, e0)                    # 阶段一: 0:00计划
    A  = P.copy()
    ch=np.zeros(T); dis=np.zeros(T); cur=np.zeros(T); em=np.zeros(T); E=np.zeros(T)
    e  = e0
    for t in range(T):                                # 0-based
        if t in adj:                                  # 阶段二: 6/12/18点调整
            Fk = fc_slots(fcd[t], t)
            A[t:], *_ = _lp(Ld[t:], Fk, price[t:], e, P[t:])
        ch[t],dis[t],cur[t],em[t],e = rt_slot(A[t], Vd[t], Ld[t], e)
        E[t] = e
    cost = {'基础购电费': float((A*price).sum()),
            '偏差结算费': float((DEV_K*price*np.abs(A-P)).sum()),
            '紧急购电费': float((EM_K*price*em).sum())}
    cost['总费用'] = sum(cost.values())
    return dict(P=P,A=A,ch=ch,dis=dis,cur=cur,em=em,E=E,e_end=e,cost=cost)

def run(price, L, PV, fc, dates, adj=K_ADJ):
    e, res = E_INIT, []
    for d in range(len(dates)):
        fcd = {k: fc[(d,k)] for k in K_RELEASE}
        r = sim_day(L[d], PV[d], price, fcd, e, adj=adj)
        e = r['e_end']; res.append(r)
        if (d+1) % 60 == 0: print(f'  已推演 {d+1} 天')
    return res

# ==================== 5. 结果输出 ====================
def em_blocks(em, tol=1e-6):
    """逐时段紧急购电 → 连续时间段块 [(起始,结束,电量)]"""
    out, t = [], 0
    while t < T:
        if em[t] > tol:
            s = t
            while t < T and em[t] > tol: t += 1
            out.append((f'{s//6}:{s%6*10:02d}',
                        f'{t//6}:{t%6*10:02d}', float(em[s:t].sum())))
        else: t += 1
    return out

def write_result3(res, dates, path='result3.xlsx'):
    idx = [i for i,d in enumerate(dates) if pd.Timestamp(d) >= OUT_START]
    dl  = [str(pd.Timestamp(dates[i]).date()) for i in idx]
    dfP = pd.DataFrame([res[i]['P'] for i in idx], index=dl, columns=SLOT_LB)
    dfA = pd.DataFrame([res[i]['A'] for i in idx], index=dl, columns=SLOT_LB)
    dfP.index.name = dfA.index.name = '日期'
    rows = []
    for j,i in enumerate(idx):                       # 充放电量: 4h分块
        r = res[i]; e0 = E_INIT if i==0 else res[i-1]['e_end']
        row = {'日期': dl[j], '0:00储电量': round(e0,4)}
        for b in range(6):
            sl = slice(24*b, 24*b+24)
            row[f'{4*b:02d}:00-{4*b+4:02d}:00充电量'] = round(r['ch'][sl].sum(),4)
            row[f'{4*b:02d}:00-{4*b+4:02d}:00放电量'] = round(r['dis'][sl].sum(),4)
        row['24:00储电量'] = round(r['e_end'],4); rows.append(row)
    dfB = pd.DataFrame(rows)
    rows = []
    for j,i in enumerate(idx):                       # 紧急购电: 连续时段块
        for s,e,q in em_blocks(res[i]['em']):
            rows.append({'日期':dl[j],'紧急购电时间段':f'{s}-{e}',
                         '紧急购电量':round(q,4)})
    dfE = pd.DataFrame(rows, columns=['日期','紧急购电时间段','紧急购电量'])
    with pd.ExcelWriter(path) as w:
        dfP.to_excel(w,'计划购电量'); dfA.to_excel(w,'调整购电量')
        dfB.to_excel(w,'充放电量');   dfE.to_excel(w,'紧急购电量')
    print(f'已输出 {path}')
    return dfP, dfA, dfB, dfE

# ---- 论文表1/2/3生成(指定日期) ----
def paper_table1(res, dates, price, ds):
    i = next(j for j,d in enumerate(dates) if str(pd.Timestamp(d).date())==ds)
    r = res[i]
    sl = [('10:00-10:10',60),('12:00-12:10',72),('14:00-14:10',84),
          ('16:00-16:10',96),('18:00-18:10',108),('20:00-20:10',120)]
    df = pd.DataFrame({'计划购电量P':[r['P'][t] for _,t in sl],
                       '最终购电量A':[r['A'][t] for _,t in sl],
                       '紧急购电量':[r['em'][t] for _,t in sl]}, index=[s for s,_ in sl])
    df.loc['全天合计'] = [r['P'].sum(), r['A'].sum()+r['em'].sum(), r['em'].sum()]
    df['备注'] = '';  df.loc['全天合计','备注'] = f"全天总费用={r['cost']['总费用']:.2f}元"
    return df.round(4)

def paper_table2(res, dates, ds):
    i = next(j for j,d in enumerate(dates) if str(pd.Timestamp(d).date())==ds)
    r = res[i]; e0 = E_INIT if i==0 else res[i-1]['e_end']
    df = pd.DataFrame(index=[f'{4*b:02d}:00-{4*b+4:02d}:00' for b in range(6)])
    df['充电量'] = [round(r['ch'][24*b:24*b+24].sum(),4) for b in range(6)]
    df['放电量'] = [round(r['dis'][24*b:24*b+24].sum(),4) for b in range(6)]
    df.loc['0:00储电量'] = [round(e0,4), '']
    df.loc['24:00储电量'] = [round(r['e_end'],4), '']
    return df

def paper_table3(res, dates, ds):
    i = next(j for j,d in enumerate(dates) if str(pd.Timestamp(d).date())==ds)
    bl = em_blocks(res[i]['em'])
    return pd.DataFrame(bl, columns=['时间段','购电量(舍去)','紧急购电量']).iloc[:,[0,2]] \
             if bl else pd.DataFrame(columns=['时间段','紧急购电量'])

# ==================== 6. 预报误差与情景对比分析 ====================
def fc_error_table(PV, fc, dates):
    """各发布时刻×提前时效 的预报MAE(kW): 佐证'晚发布更准'"""
    kw = PV/DT; tab = {KNAME[k]: np.zeros(24) for k in K_ADJ}
    cnt= {KNAME[k]: np.zeros(24) for k in K_ADJ}
    for d in range(len(dates)):
        for k in K_ADJ:
            for lead in range(1,25):
                hh = int(k/6+lead)
                if hh >= 24: break
                act = kw[d, 6*hh:6*hh+6].mean()
                tab[KNAME[k]][lead-1] += abs(fc[(d,k)][lead-1]-act)
                cnt[KNAME[k]][lead-1] += 1
    df = pd.DataFrame({g: tab[g]/np.maximum(cnt[g],1) for g in tab},
                      index=[f'提前{i}h' for i in range(1,25)])
    df.index.name = '发布时刻→'
    return df.round(2)

def cost_summary(res):
    s = {k: round(sum(r['cost'][k] for r in res),2) for k in res[0]['cost']}
    s['紧急购电量kWh'] = round(sum(r['em'].sum() for r in res),2)
    s['总购电量kWh']   = round(sum(r['A'].sum()+r['em'].sum() for r in res),2)
    return s

def check_energy(res, L, PV, d=0):
    """能量守恒与储能界校验"""
    r = res[d]
    bal = r['A']+PV[d]+r['dis']+r['em']-L[d]-r['ch']-r['cur']
    assert np.abs(bal).max() < 1e-6, '能量不守恒!'
    assert r['E'].min() >= E_MIN-1e-6 and r['E'].max() <= E_MAX+1e-6
    print(f'  第{d+1}天校验通过: 最大平衡残差={np.abs(bal).max():.2e}')

# ==================== 7. 主程序 ====================
if __name__ == '__main__':
    DEMO = True                       # ← 自测用True; 跑真实数据改为False
    if DEMO:
        price, L, PV, dates, fc = make_dummy(90)
    else:
        price, L, PV, dates, fc = load_all()

    # --- 情景对比: 是否/何时引入更新预报 ---
    scen = {'S0 仅0:00计划': (), 'S1 全部调整': K_ADJ,
            'S2 仅6:00': (36,), 'S3 仅12:00': (72,), 'S4 仅18:00': (108,)}
    summary, RES = {}, {}
    for name, adj in scen.items():
        print(f'运行情景: {name} ...')
        RES[name] = run(price, L, PV, fc, dates, adj=set(adj))
        summary[name] = cost_summary(RES[name])
        check_energy(RES[name], L, PV, 0)
    print('\n===== 情景费用对比(元) =====')
    print(pd.DataFrame(summary).T.to_string())

    print('\n===== 预报误差MAE(kW), 节选 =====')
    print(fc_error_table(PV, fc, dates).iloc[[0,2,5,11,17,23]].to_string())

    # --- 输出result3.xlsx(以S1为准) + 指定日期论文表格 ---
    write_result3(RES['S1 全部调整'], dates)
    for ds in SPEC_DATES:
        try:
            print(f'\n--- {ds} 表1 ---'); print(paper_table1(RES['S1 全部调整'],dates,price,ds))
            print(f'--- {ds} 表2 ---'); print(paper_table2(RES['S1 全部调整'],dates,ds))
            print(f'--- {ds} 表3 ---'); print(paper_table3(RES['S1 全部调整'],dates,ds))
        except StopIteration:
            print(f'{ds} 不在数据范围内(合成数据自测时属正常)')
