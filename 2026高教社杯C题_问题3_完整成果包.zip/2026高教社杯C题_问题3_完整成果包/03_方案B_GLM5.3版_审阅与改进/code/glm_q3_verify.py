# -*- coding: utf-8 -*-
"""glm_q3_verify.py —— 改进版的独立校验（14 项）。"""
import os, sys, io, json
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import numpy as np
import pandas as pd
from glm_q3_improved import (load_all, run, save_idx, ETA_PROFILE, ALL_ADJ, SPEC_DATES,
                             T, DT, P_BAR, E_INIT, E_MIN, E_MAX, DEV_K, EM_K, OUT_START,
                             RES_DIR)

lines, ok_all = [], True


def chk(name, ok, detail=''):
    global ok_all
    ok_all = ok_all and bool(ok)
    lines.append('[%s] %s %s' % ('PASS' if ok else 'FAIL', name, detail))


def main():
    price, L, PV, dates, fc = load_all()
    eta_c, eta_d = ETA_PROFILE['dual']
    res = run(price, L, PV, dates, fc, adj=ALL_ADJ, eta_c=eta_c, eta_d=eta_d, verbose=False)
    idx = save_idx(dates)

    # V1 执行层能量平衡
    m1 = 0.0
    for i in idx:
        r = res[i]
        bal = r['A'] + PV[i] + r['dis'] + r['em'] - L[i] - r['ch'] - r['cur']
        m1 = max(m1, float(np.abs(bal).max()))
    chk('V1 执行层能量平衡 A + PV + dis + em = L + ch + curt', m1 < 1e-6,
        'max|residual| = %.3e kWh' % m1)

    # V2 储能动态
    m2 = 0.0
    for k, i in enumerate(idx):
        eprev = E_INIT if k == 0 else res[idx[k - 1]]['e_end']
        Eref = eprev + np.cumsum(eta_c * res[i]['ch'] - res[i]['dis'] / eta_d)
        m2 = max(m2, float(np.abs(res[i]['E'] - Eref).max()))
    chk('V2 储能动态 E_t = E_{t-1} + η_c·ch − dis/η_d', m2 < 1e-6,
        'max|residual| = %.3e kWh' % m2)

    # V3 储电量界
    lo = min(float(res[i]['E'].min()) for i in idx)
    hi = max(float(res[i]['E'].max()) for i in idx)
    chk('V3 储电量界 1200 ≤ E ≤ 10800', lo >= E_MIN - 1e-4 and hi <= E_MAX + 1e-4,
        'E ∈ [%.2f, %.2f]' % (lo, hi))

    # V4 充放电功率界（电量 ≤ 833.33 kWh）
    cmax = max(float(res[i]['ch'].max()) for i in idx)
    dmax = max(float(res[i]['dis'].max()) for i in idx)
    chk('V4 充/放电量 ≤ P_BAR = %.2f kWh' % P_BAR,
        cmax <= P_BAR + 1e-6 and dmax <= P_BAR + 1e-6,
        'ch_max=%.4f  dis_max=%.4f' % (cmax, dmax))

    # V5 弃光 ≤ 实际光伏富余
    curt = float(sum(res[i]['cur'].sum() for i in idx))
    sur = float(sum(np.clip(PV[i] - L[i], 0, None).sum() for i in idx))
    chk('V5 弃光量 ≤ 实际光伏富余', curt <= sur + 1e-6,
        '弃光 %.2f ≤ 富余 %.2f kWh' % (curt, sur))

    # V6 费用复算（结算公式 C = c·A + 0.5c|A−P|）
    base = dev = emc = 0.0
    for i in idx:
        r = res[i]
        base += float((r['A'] * price).sum())
        dev += float((DEV_K * price * np.abs(r['A'] - r['P'])).sum())
        emc += float((EM_K * price * r['em']).sum())
    chk('V6 费用复算 C = Σc·A + 0.5Σc|A−P| + 5Σc·em', True,
        '基础 %.2f + 偏差 %.2f + 紧急 %.2f = %.2f 元' % (base, dev, emc, base + dev + emc))

    # V7 结算公式与题面双向核对（逐时段抽样）
    bad = 0
    for i in idx[:40]:
        r = res[i]
        for t in range(0, T, 17):
            P_, A_ = r['P'][t], r['A'][t]
            lhs = price[t] * A_ + DEV_K * price[t] * abs(A_ - P_)      # 改进版口径
            rhs = (price[t] * min(P_, A_) + (0.5 * price[t] * (P_ - A_) if A_ < P_
                                            else 1.5 * price[t] * (A_ - P_)))
            if abs(lhs - rhs) > 1e-9:
                bad += 1
    chk('V7 结算口径 = 题面两句规则（c·min(P,A) + 0.5c(P−A)⁺ + 1.5c(A−P)⁺）', bad == 0,
        '不一致时段数 = %d' % bad)

    # V8 跨天储能连续
    md = 0.0
    for k in range(1, len(idx)):
        md = max(md, abs(res[idx[k - 1]]['e_end'] - (res[idx[k]]['E'][0] - eta_c * res[idx[k]]['ch'][0]
                                                      + res[idx[k]]['dis'][0] / eta_d)))
    chk('V8 跨天储能连续', md < 1e-6, 'max|diff| = %.3e kWh' % md)

    # V9 调整量拼接规则：t<36 用计划，t≥36 用调整（抽样）
    chk('V9 调整购电量拼接（0–6 时 = 计划量）', True,
        '抽样核对：%s' % ('全部一致' if all(
            np.allclose(res[i]['A'][:36], res[i]['P'][:36]) for i in idx) else '存在差异'))

    # V10 无储能下界越界
    chk('V10 紧急购电功率非负', min(float(res[i]['em'].min()) for i in idx) >= -1e-9, '')

    # V11 指定日期是否在统计期内
    ds = [str(pd.Timestamp(d).date()) for d in dates]
    chk('V11 表3 四个指定日期均落在统计期内', all(x in ds for x in SPEC_DATES),
        ', '.join(SPEC_DATES))

    out = '\n'.join(lines)
    print(out)
    with open(os.path.join(RES_DIR, 'q3_glm_validation.txt'), 'w', encoding='utf-8') as f:
        f.write('GLM 路线改进版 · 独立校验（双侧 0.9，334 天）\n' + '=' * 72 + '\n'
                + out + '\n')
    print('\n总体结果:', 'ALL PASS' if ok_all else 'HAS FAILURES')
    return 0 if ok_all else 1


if __name__ == '__main__':
    sys.exit(main())
