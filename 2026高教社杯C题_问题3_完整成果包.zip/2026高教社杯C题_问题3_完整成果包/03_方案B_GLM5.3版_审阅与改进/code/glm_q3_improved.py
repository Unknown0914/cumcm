# -*- coding: utf-8 -*-
"""
glm_q3_improved.py —— GLM-5.3 问题3 方案的改进版

在保留 GLM 全部正确设计的前提下修正 8 处缺陷：
  C1  结算公式 C = c·A + 0.5c|A−P|  ——  **保留**（这是 GLM 最漂亮的一步，与题面对称、且严格 LP）
  C2  η_d = 1.0（单侧效率）→ 改为主口径 η_c = η_d = 0.9（题面“充放电效率均为 90%”），
      单侧 0.9/1.0 与往返 90% 作为敏感性口径
  C3  规划层弃光 curt 无上界 → 补 0 ≤ curt_t ≤ max(0, F_t − L_t)
  C4  实时调度 dis 上界写成 P_BAR*ETA_D（改口径后会违反 5000 kW 功率限制）→ 修正为 P_BAR
  C5  附件3「日期」列仅每天首行有值导致 pd.Timestamp 崩溃 → ffill
  C6  统计口径混乱（费用按 365 天汇总）→ 统一为 334 天（1 月预热，与 result3.xlsx 一致）
  C7  check_energy 只查第 0 天 → 改为全年 334 天逐时段校验
  C8  无模板合规检查、无“预报时点数”对照实验 → 补齐

用法：
    python glm_q3_improved.py                # 主口径（双侧 0.9），334 天，4 时点
    python glm_q3_improved.py --eta dual|single|roundtrip
    python glm_q3_improved.py --slots 1      # 只用 0:00 预报（附加问题对照）
"""
import os, sys, io, json, argparse, time
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
import numpy as np
import pandas as pd
from scipy.optimize import linprog

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
RES_DIR = os.path.join(ROOT, 'results')
OUT_DIR = os.path.join(ROOT, 'output')
DATA = r'C:\Users\35941\Desktop\C题\附件'

# ==================== 1. 全局参数 ====================
T, DT = 144, 1 / 6
ETA_PROFILE = {
    'dual':      (0.90, 0.90),      # 双侧各 90%（题面字面，主口径）
    'single':    (0.90, 1.00),      # 单侧（GLM 原口径）
    'roundtrip': (0.9 ** 0.5, 0.9 ** 0.5),   # 往返 90%
}
E_INIT, E_MIN, E_MAX = 6000., 1200., 10800.
P_BAR = 5000. * DT                  # 单时段最大充/放电量 kWh
K_RELEASE = (0, 36, 72, 108)
ALL_ADJ = (36, 72, 108)
KNAME = {0: '0:00', 36: '6:00', 72: '12:00', 108: '18:00'}
DEV_K, EM_K = 0.5, 5.0
SPEC_DATES = ['2025-03-20', '2025-06-21', '2025-09-23', '2025-12-21']
OUT_START = pd.Timestamp('2025-02-01')       # 统计与保存起点（334 天）
SLOT_LB = [('0:00+1' if (i + 1) == 144 else '%d:%02d' % divmod((i + 1) * 10, 60))
           for i in range(T)]


# ==================== 2. 数据 ====================
def load_all():
    price = pd.read_excel(os.path.join(DATA, '附件1.xlsx'))['电价'].to_numpy(float)[:T]
    dfL = pd.read_excel(os.path.join(DATA, '附件2.xlsx'), sheet_name='小区负载', index_col=0)
    dfV = pd.read_excel(os.path.join(DATA, '附件2.xlsx'), sheet_name='光伏发电实际功率',
                        index_col=0)
    L = dfL.iloc[:, :T].to_numpy(float) * DT
    PV = dfV.iloc[:, :T].to_numpy(float) * DT
    dates = pd.to_datetime(dfL.index)
    df3 = pd.read_excel(os.path.join(DATA, '附件3.xlsx'))
    df3.iloc[:, 0] = pd.to_datetime(df3.iloc[:, 0]).ffill()      # C5
    kmap = {'0:00': 0, '6:00': 36, '12:00': 72, '18:00': 108}
    dpos = {d.normalize(): i for i, d in enumerate(dates)}
    fc = {}
    for _, row in df3.iterrows():
        fc[(dpos[pd.Timestamp(row.iloc[0]).normalize()], kmap[str(row.iloc[1])])] \
            = row.iloc[2:26].to_numpy(float)
    return price, L, PV, dates, fc


# ==================== 3. LP ====================
def _lp(Ls, Fs, ps, e0, P_ref=None, eta_c=0.9, eta_d=0.9):
    """变量(每时段 7 个): [x, ch, dis, curt, E, u, v]。P_ref=None → 阶段一。"""
    m, n = len(Ls), 7 * len(Ls)
    c = np.zeros(n); c[0::7] = ps
    if P_ref is not None:
        c[5::7] = DEV_K * ps; c[6::7] = DEV_K * ps
    nrow = 3 * m if P_ref is not None else 2 * m
    A = np.zeros((nrow, n)); b = np.zeros(nrow)
    i = np.arange(m)
    A[i, 7 * i] = 1; A[i, 7 * i + 2] = 1; A[i, 7 * i + 1] = -1; A[i, 7 * i + 3] = -1
    b[i] = Ls - Fs
    r = m + i
    A[r, 7 * i + 4] = 1; A[r, 7 * i + 1] = -eta_c; A[r, 7 * i + 2] = 1 / eta_d
    if m > 1:
        A[r[1:], 7 * i[:-1] + 4] = -1
    b[r[0]] = e0
    if P_ref is not None:
        r2 = 2 * m + i
        A[r2, 7 * i] = 1; A[r2, 7 * i + 5] = -1; A[r2, 7 * i + 6] = 1; b[r2] = P_ref
    # C3: 弃光上界取“预报富余”
    cur_hi = np.maximum(0.0, Fs - Ls)
    bounds = []
    for k in range(m):
        bounds += [(0, None), (0, P_BAR), (0, P_BAR), (0, cur_hi[k]),
                   (E_MIN, E_MAX), (0, None), (0, None)]
    res = linprog(c, A_eq=A, b_eq=b, bounds=bounds, method='highs')
    if not res.success:
        raise RuntimeError('LP 失败: ' + res.message)
    z = res.x
    return z[0::7], z[1::7], z[2::7], z[3::7], z[4::7]


def fc_slots(fc24, k):
    """k 时刻发布的 24 整点预报(kW) → 当日剩余时段电量(kWh)。"""
    xp = k / 6.0 + np.arange(1, 25)
    mid = (np.arange(k + 1, T + 1) - 0.5) / 6.0
    return np.interp(mid, xp, fc24) * DT


def rt_slot(a, pv, L, e, eta_c, eta_d):
    """实时贪心调度。C4: 放电电量上界 P_BAR（功率限制），与效率无关。"""
    ch = dis = cur = em = 0.0
    g = a + pv - L
    if g >= 0:
        ch = min(g, P_BAR, (E_MAX - e) / eta_c)
        cur = g - ch
    else:
        need = -g
        dis = min(need, P_BAR, max(0.0, e - E_MIN) * eta_d)
        em = need - dis
    return ch, dis, cur, em, e + eta_c * ch - dis / eta_d


# ==================== 4. 单日 ====================
def sim_day(Ld, Vd, price, fcd, e0, adj=ALL_ADJ, eta_c=0.9, eta_d=0.9):
    F0 = fc_slots(fcd[0], 0)
    P, *_ = _lp(Ld, F0, price, e0, eta_c=eta_c, eta_d=eta_d)
    A = P.copy()
    ch = np.zeros(T); dis = np.zeros(T); cur = np.zeros(T); em = np.zeros(T); E = np.zeros(T)
    e = e0
    for t in range(T):
        if t in adj:
            Fk = fc_slots(fcd[t], t)
            A[t:], *_ = _lp(Ld[t:], Fk, price[t:], e, P[t:], eta_c=eta_c, eta_d=eta_d)
        ch[t], dis[t], cur[t], em[t], e = rt_slot(A[t], Vd[t], Ld[t], e, eta_c, eta_d)
        E[t] = e
    cost = {'base': float((A * price).sum()),
            'dev': float((DEV_K * price * np.abs(A - P)).sum()),
            'em': float((EM_K * price * em).sum())}
    cost['total'] = sum(cost.values())
    return dict(P=P, A=A, ch=ch, dis=dis, cur=cur, em=em, E=E, e_end=e, cost=cost)


def run(price, L, PV, dates, fc, adj=ALL_ADJ, eta_c=0.9, eta_d=0.9, verbose=True):
    e, res = E_INIT, []
    for d in range(len(dates)):
        fcd = {k: fc[(d, k)] for k in K_RELEASE}
        r = sim_day(L[d], PV[d], price, fcd, e, adj=adj, eta_c=eta_c, eta_d=eta_d)
        e = r['e_end']; res.append(r)
        if verbose and (d + 1) % 100 == 0:
            print('  已推演 %d / %d 天' % (d + 1, len(dates)))
    return res


# ==================== 5. 统计（C6：统一 334 天） ====================
def save_idx(dates):
    return [i for i, d in enumerate(dates) if pd.Timestamp(d) >= OUT_START]


def summarize(res, dates):
    idx = save_idx(dates)
    g = lambda k: float(sum(res[i]['cost'][k] for i in idx))
    return {
        'days': len(idx),
        'base_cost': g('base'), 'dev_cost': g('dev'), 'em_cost': g('em'),
        'total_cost': g('total'),
        'plan_kWh': float(sum(res[i]['P'].sum() for i in idx)),
        'final_kWh': float(sum(res[i]['A'].sum() for i in idx)),
        'emergency_kWh': float(sum(res[i]['em'].sum() for i in idx)),
        'curtail_kWh': float(sum(res[i]['cur'].sum() for i in idx)),
        'charge_kWh': float(sum(res[i]['ch'].sum() for i in idx)),
        'discharge_kWh': float(sum(res[i]['dis'].sum() for i in idx)),
        'pv_kWh': float(sum(res[i]['v'].sum() for i in idx)) if 'v' in res[0] else None,
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--eta', choices=list(ETA_PROFILE), default='dual')
    ap.add_argument('--slots', type=int, choices=[1, 2, 4], default=4)
    ap.add_argument('--tag', default=None)
    args = ap.parse_args()

    eta_c, eta_d = ETA_PROFILE[args.eta]
    adj = {1: (), 2: (36,), 4: ALL_ADJ}[args.slots]
    tag = args.tag or ('glm_%s_slots%d' % (args.eta, args.slots))

    os.makedirs(RES_DIR, exist_ok=True); os.makedirs(OUT_DIR, exist_ok=True)
    price, L, PV, dates, fc = load_all()
    print('数据: %d 天 × %d 时段 | 口径 %s (eta_c=%.4f, eta_d=%.4f) | 预报时点 %d'
          % (len(dates), T, args.eta, eta_c, eta_d, args.slots))
    t0 = time.time()
    res = run(price, L, PV, dates, fc, adj=adj, eta_c=eta_c, eta_d=eta_d)
    idx = save_idx(dates)
    for i in idx:
        res[i]['v'] = PV[i]
    s = summarize(res, dates)
    s['eta_profile'] = args.eta
    s['eta_c'], s['eta_d'] = eta_c, eta_d
    s['slots'] = args.slots
    s['seconds'] = round(time.time() - t0, 1)
    print('\n统计期 %d 天（%s ~ %s）' % (s['days'], dates[idx[0]].date(), dates[idx[-1]].date()))
    print('计划购电 %.2f kWh → 最终购电 %.2f kWh' % (s['plan_kWh'], s['final_kWh']))
    print('基础 %.2f + 偏差 %.2f + 紧急 %.2f = 总费用 %.2f 元'
          % (s['base_cost'], s['dev_cost'], s['em_cost'], s['total_cost']))
    print('紧急购电 %.2f kWh | 弃光 %.2f kWh | 充 %.2f / 放 %.2f kWh'
          % (s['emergency_kWh'], s['curtail_kWh'], s['charge_kWh'], s['discharge_kWh']))
    print('耗时 %.1f s' % s['seconds'])
    with open(os.path.join(RES_DIR, 'q3_%s.json' % tag), 'w', encoding='utf-8') as f:
        json.dump(s, f, ensure_ascii=False, indent=2)
    print('已写出 results/q3_%s.json' % tag)
    return s


if __name__ == '__main__':
    main()
