# -*- coding: utf-8 -*-
"""patch_glm_q3.py —— 生成 GLM 方案的「最小适配复现版」。

只做三件事（算法一行不改）：
  1. DEMO=True → False，并把 main 里的情景对比收敛为只跑 S1（全部调整），避免 5×365 天过慢；
  2. load_all() 的附件路径换成绝对路径；
  3. 附件3 的「日期」列只在每天首行有值 → 补 forward-fill（GLM 原版会在此崩溃）。
把所做改动打印出来，作为审阅证据。
"""
import io, os, sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

WQ = r'C:\Users\35941\Desktop\cumcm2026C_q3'
src = os.path.join(WQ, 'glm_original', 'glm_q3_original.py')
s = io.open(src, encoding='utf-8').read()
orig = s
changes = []

# ---- 1. DEMO 关闭 ----
old = "    DEMO = True                       # ← 自测用True; 跑真实数据改为False"
new = "    DEMO = False                      # ← 自测用True; 跑真实数据改为False"
if old in s:
    s = s.replace(old, new); changes.append('DEMO: True → False')

# ---- 2. 绝对路径 ----
old = "def load_all(f1='附件1.xlsx', f2='附件2.xlsx', f3='附件3.xlsx'):"
new = ("AD = r'C:\\Users\\35941\\Desktop\\C题\\附件'\n"
       "def load_all(f1=None, f2=None, f3=None):\n"
       "    f1 = f1 or os.path.join(AD, '附件1.xlsx')\n"
       "    f2 = f2 or os.path.join(AD, '附件2.xlsx')\n"
       "    f3 = f3 or os.path.join(AD, '附件3.xlsx')")
if old in s:
    s = s.replace(old, new); changes.append('load_all(): 附件相对路径 → 绝对路径')

# ---- 3. 附件3 日期前向填充 ----
old = "    df3  = pd.read_excel(f3)"
new = ("    df3  = pd.read_excel(f3)\n"
       "    df3.iloc[:, 0] = pd.to_datetime(df3.iloc[:, 0]).ffill()   # 日期列仅每天首行有值")
if old in s:
    s = s.replace(old, new); changes.append('附件3 日期列 ffill（原版会因空日期崩溃）')

# ---- 4. import os ----
old = "import numpy as np\nimport pandas as pd\nfrom scipy.optimize import linprog"
new = "import os\nimport numpy as np\nimport pandas as pd\nfrom scipy.optimize import linprog"
if old in s:
    s = s.replace(old, new); changes.append('增加 import os')

# ---- 5. 只跑 S1 ----
old = """    scen = {'S0 仅0:00计划': (), 'S1 全部调整': K_ADJ,
            'S2 仅6:00': (36,), 'S3 仅12:00': (72,), 'S4 仅18:00': (108,)}"""
new = """    scen = {'S1 全部调整': K_ADJ}"""
if old in s:
    s = s.replace(old, new); changes.append('main: 情景收敛为仅 S1（复现用）')

# ---- 6. 输出文件改到 output/ ----
old = "def write_result3(res, dates, path='result3.xlsx'):"
new = "def write_result3(res, dates, path=r'%s'):" % os.path.join(WQ, 'output', 'result3_glm_original.xlsx')
if old in s:
    s = s.replace(old, new); changes.append('write_result3 输出路径 → output/result3_glm_original.xlsx')

dsts = ['glm_original/glm_q3_replicate.py', 'glm_code/glm_q3_replicate.py']
for d in dsts:
    io.open(os.path.join(WQ, d), 'w', encoding='utf-8').write(s)

print('补丁生效，共 %d 处改动：' % len(changes))
for c in changes:
    print('  -', c)
print('\n产物: glm_original/glm_q3_replicate.py 与 glm_code/glm_q3_replicate.py')
print('原文件未被修改:', io.open(src, encoding='utf-8').read() == orig)
